package br.com.marconi.discalcmath.Porcentagem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import br.com.marconi.discalcmath.Painel.materias_painel;
import br.com.marconi.discalcmath.R;

public class selecao_porcentagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_porcentagem);

        LinearLayout introducao_porcentagem = (LinearLayout) findViewById(R.id.introducao_funcoes);
        LinearLayout calculo_porcentagem = (LinearLayout) findViewById(R.id.calculo_porcentagem);
        LinearLayout descontos_porcentagem = (LinearLayout) findViewById(R.id.descontos_porcentagem);
        LinearLayout regradetres_porcentagem = (LinearLayout) findViewById(R.id.regradetres_porcentagem);
        LinearLayout dados_porcentagem = (LinearLayout) findViewById(R.id.dados_porcentagem);
        LinearLayout btAvaliarPorcentagem = (LinearLayout) findViewById(R.id.btAvaliarPorcentagem);
        ImageView ImVoltar = (ImageView) findViewById(R.id.imVoltarPorcentagem);

        ImVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_porcentagem.this, materias_painel.class);
                startActivity(intent);
            }
        });


        introducao_porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_porcentagem.this, introducao_porcentagem.class);
                startActivity(intent);
            }
        });

        calculo_porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_porcentagem.this, calculo_porcentagem.class);
                startActivity(intent);
            }
        });

        descontos_porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_porcentagem.this, descontos_porcentagem.class);
                startActivity(intent);
            }
        });

        regradetres_porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_porcentagem.this, regradetres_porcentagem.class);
                startActivity(intent);
            }
        });

        dados_porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_porcentagem.this, dados_porcentagem.class);
                startActivity(intent);
            }
        });

        btAvaliarPorcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_porcentagem.this, avaliar_porcentagem.class);
                startActivity(intent);
            }
        });


    }
}