package br.com.marconi.discalcmath.Grandezas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class direta_grandezas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_direta_grandezas);

        TextView titulo1_grandezas = (TextView) findViewById(R.id.titulo1_grandezas);
        TextView titulo2_grandezas = (TextView) findViewById(R.id.titulo2_grandezas);
        TextView paragrafo1_grandezas = (TextView) findViewById(R.id.paragrafo1_grandezas);
        TextView paragrafo2_grandezas = (TextView) findViewById(R.id.paragrafo2_grandezas);
        TextView paragrafo3_grandezas = (TextView) findViewById(R.id.paragrafo3_grandezas);
        TextView paragrafo4_grandezas = (TextView) findViewById(R.id.paragrafo4_grandezas);
        TextView paragrafo5_grandezas = (TextView) findViewById(R.id.paragrafo5_grandezas);
        TextView paragrafo6_grandezas = (TextView) findViewById(R.id.paragrafo6_grandezas);

        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_grandezas);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_grandezas.setText(Html.fromHtml("<font color='red'>Proporção Direta</font>"));
                    paragrafo1_grandezas.setText(Html.fromHtml("Duas grandezas são <font color='green'>diretamente proporcionais</font> quando a variação de uma implica na variação da outra na mesma proporção<font color='#EA8240'>,</font> ou seja<font color='#EA8240'>,</font> duplicando uma delas<font color='#EA8240'>,</font> a outra também duplica<font color='#EA8240'>;</font> reduzindo pela metade<font color='#EA8240'>,</font> a outra também reduz na mesma quantidade<font color='#EA8240'>...</font> e assim por diante<font color='#EA8240'>.</font>"));
                    paragrafo2_grandezas.setText(Html.fromHtml("Graficamente a variação diretamente proporcional de uma grandeza em relação à outra<font color='#EA8240'>,</font> forma uma reta que passa pela origem<font color='#EA8240'>,</font> pois temos <font color='green'>y</font> <font color='#EA8240'>=</font> <font color='green'>k</font><font color='#EA8240'>.</font><font color='green'>x</font><font color='#EA8240'>,</font> sendo <font color='green'>k</font> uma constante<font color='#EA8240'>.</font>"));
                    paragrafo3_grandezas.setText(Html.fromHtml("Em uma gráfica são feitas impressões de livros escolares<font color='#EA8240'>.</font> Em <font color='blue'>2</font> horas<font color='#EA8240'>,</font> são realizadas <font color='blue'>40</font> impressões<font color='#EA8240'>.</font> Em <font color='blue'>3</font> horas<font color='#EA8240'>,</font> a mesma máquina produz mais <font color='blue'>60</font> impressões<font color='#EA8240'>,</font> em <font color='blue'>4</font> horas<font color='#EA8240'>,</font> <font color='blue'>80</font> impressões<font color='#EA8240'>,</font> e<font color='#EA8240'>,</font> em <font color='blue'>5</font> horas<font color='#EA8240'>,</font> <font color='blue'>100</font> impressões<font color='#EA8240'>.</font>"));
                    paragrafo4_grandezas.setText(Html.fromHtml("A <font color='green'>constante de proporcionalidade</font> entre as grandezas é encontrada pela <font color='green'>razão</font> entre o tempo de trabalho da máquina e o número de cópias realizadas<font color='#EA8240'>.</font>"));

                    titulo2_grandezas.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo5_grandezas.setText(Html.fromHtml("<font color='blue'>2</font><font color='#EA8240'>/</font><font color='blue'>40</font> <font color='#EA8240'>=</font> <font color='blue'>3</font><font color='#EA8240'>/</font><font color='blue'>60</font> <font color='#EA8240'>=</font> <font color='blue'>4</font><font color='#EA8240'>/</font><font color='blue'>80</font> <font color='#EA8240'>=</font> <font color='blue'>5</font><font color='#EA8240'>/</font><font color='blue'>100</font> <font color='#EA8240'>=</font> <font color='blue'>1</font><font color='#EA8240'>/</font><font color='blue'>20</font><font color='#EA8240'>.</font>"));
                    paragrafo6_grandezas.setText(Html.fromHtml("O <font color='green'>quociente</font> dessa sequência <font color='#EA8240'>(</font><font color='blue'>1</font><font color='#EA8240'>/</font><font color='blue'>20</font><font color='#EA8240'>)</font> recebe o nome de <font color='green'>constante de proporcionalidade</font> <font color='#EA8240'>(</font><font color='green'>k</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font> O tempo de trabalho <font color='#EA8240'>(</font><font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>3</font><font color='#EA8240'>,</font> <font color='blue'>4</font> e <font color='blue'>5</font><font color='#EA8240'>)</font> é diretamente proporcional ao número de cópias <font color='#EA8240'>(</font><font color='blue'>40</font><font color='#EA8240'>,</font> <font color='blue'>60</font><font color='#EA8240'>,</font> <font color='blue'>80</font> e <font color='blue'>100</font><font color='#EA8240'>)</font><font color='#EA8240'>,</font> pois ao dobrar o tempo de trabalho o número de cópias também dobra<font color='#EA8240'>.</font>"));

                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_grandezas.setText(Html.fromHtml("Proporção Direta"));
                    paragrafo1_grandezas.setText(Html.fromHtml("Duas grandezas são diretamente proporcionais quando a variação de uma implica na variação da outra na mesma proporção, ou seja, duplicando uma delas, a outra também duplica; reduzindo pela metade, a outra também reduz na mesma quantidade... e assim por diante."));
                    paragrafo2_grandezas.setText(Html.fromHtml("Graficamente a variação diretamente proporcional de uma grandeza em relação à outra forma uma reta que passa pela origem, pois temos y = k.x, sendo k uma constante."));

                    titulo2_grandezas.setText(Html.fromHtml("Exemplo"));
                    paragrafo3_grandezas.setText(Html.fromHtml("Em uma gráfica são feitas impressões de livros escolares. Em 2 horas, são realizadas 40 impressões. Em 3 horas, a mesma máquina produz mais 60 impressões, em 4 horas, 80 impressões, e, em 5 horas, 100 impressões."));
                    paragrafo4_grandezas.setText(Html.fromHtml("A constante de proporcionalidade entre as grandezas é encontrada pela razão entre o tempo de trabalho da máquina e o número de cópias realizadas."));
                    paragrafo5_grandezas.setText(Html.fromHtml("2/40 = 3/60 = 4/80 = 5/100 = 1/20."));
                    paragrafo6_grandezas.setText(Html.fromHtml("O quociente dessa sequência (1/20) recebe o nome de constante de proporcionalidade (k). O tempo de trabalho (2, 3, 4 e 5) é diretamente proporcional ao número de cópias (40, 60, 80 e 100), pois ao dobrar o tempo de trabalho o número de cópias também dobra."));

                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });


        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(direta_grandezas.this, selecao_grandezas_proporcionais.class);
                startActivity(intent);
            }
        });
    }
    }
