package br.com.marconi.discalcmath.Jogo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import br.com.marconi.discalcmath.databinding.ActivityResultadoBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

public class Resultado extends AppCompatActivity {

    ActivityResultadoBinding binding;
    int PONTOS = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityResultadoBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        int respostasCorretas = getIntent().getIntExtra("correto", 0);
        int totalQuestoes = getIntent().getIntExtra("total", 0);

        long pontos = respostasCorretas * PONTOS;



        binding.btReiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Resultado.this, MenuQuiz.class);
                startActivity(intent);
            }
        });


        binding.pontuacao.setText(String.format("%d/%d", respostasCorretas, totalQuestoes));

        binding.moedas.setText(String.valueOf(pontos));

        FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("usuarios")
                    .document(FirebaseAuth.getInstance().getUid())
                    .update("moedas", FieldValue.increment(pontos));


        }
}
