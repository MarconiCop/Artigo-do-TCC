package br.com.marconi.discalcmath.Jogo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import br.com.marconi.discalcmath.Bancos.Questoes;
import br.com.marconi.discalcmath.R;
import br.com.marconi.discalcmath.databinding.ActivityQuiz2Binding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Random;

public class MetodosQuiz extends AppCompatActivity {

    ActivityQuiz2Binding binding;
    ArrayList<Questoes> questoes;
    int index = 0;
    Questoes q;
    CountDownTimer temporizador;
    FirebaseFirestore db;
    int respostaCorreta = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuiz2Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        questoes = new ArrayList<>();
        db = FirebaseFirestore.getInstance();

        final String categoriaId = getIntent().getStringExtra("catId");

        Random random = new Random();
        final int rand = random.nextInt(10);

        db.collection("categorias")
                .document(categoriaId)
                .collection("questoes")
                .whereGreaterThanOrEqualTo("index", rand)
                .orderBy("index")
                .limit(5).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                if (queryDocumentSnapshots.getDocuments().size() < 5) {
                    db.collection("categorias")
                            .document(categoriaId)
                            .collection("questoes")
                            .whereLessThanOrEqualTo("index", rand)
                            .orderBy("index")
                            .limit(5).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {

                            for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                                Questoes qu = snapshot.toObject(Questoes.class);
                                questoes.add(qu);

                            }

                            DefinirProximaQuestao();
                        }

                    });
                } else {
                    for (DocumentSnapshot snapshot : queryDocumentSnapshots) {
                        Questoes qu = snapshot.toObject(Questoes.class);
                        questoes.add(qu);
                    }

                    DefinirProximaQuestao();
                }
            }
        });
        resetarTempo();

    }

    void resetarTempo() {
        temporizador = new CountDownTimer(180000, 1000) {

            @Override
            public void onTick(long l) {
                binding.txtTempo.setText(String.valueOf(l / 1000));
                if((String.valueOf(l / 1000)).equals("0")){
                    binding.opcao1.setEnabled(false);
                    binding.opcao2.setEnabled(false);
                    binding.opcao3.setEnabled(false);
                    binding.opcao4.setEnabled(false);
                }
            }

            @Override
            public void onFinish() {

            }
        };
    }

    void MostrarResposta() {
        if (q.getResposta().equals(binding.opcao1.getText().toString()))
            binding.opcao1.setBackground(getResources().getDrawable(R.drawable.opcao_certa));
        binding.opcao1.setEnabled(false);
        if (q.getResposta().equals(binding.opcao2.getText().toString()))
            binding.opcao2.setBackground(getResources().getDrawable(R.drawable.opcao_certa));
        binding.opcao2.setEnabled(false);
        if (q.getResposta().equals(binding.opcao3.getText().toString()))
            binding.opcao3.setBackground(getResources().getDrawable(R.drawable.opcao_certa));
        binding.opcao3.setEnabled(false);
        if (q.getResposta().equals(binding.opcao4.getText().toString()))
            binding.opcao4.setBackground(getResources().getDrawable(R.drawable.opcao_certa));
        binding.opcao4.setEnabled(false);
    }


    void DefinirProximaQuestao() {
        if (temporizador != null)

            temporizador.cancel();

        temporizador.start();


        if (index < questoes.size()) {
            binding.txtNumeroQuestao.setText(String.format("%d/%d", (index + 1), questoes.size()));
            q = questoes.get(index);
            binding.txtPergunta.setText(q.getQuestao());
            binding.opcao1.setText(q.getOpcao1());
            binding.opcao1.setEnabled(true);
            binding.opcao2.setText(q.getOpcao2());
            binding.opcao2.setEnabled(true);
            binding.opcao3.setText(q.getOpcao3());
            binding.opcao3.setEnabled(true);
            binding.opcao4.setText(q.getOpcao4());
            binding.opcao4.setEnabled(true);
        }
    }

    void VerificarResposta(TextView textView) {
        String opcaoSelecionada = textView.getText().toString();
        if (opcaoSelecionada.equals(q.getResposta())) {
            respostaCorreta++;
            textView.setBackground(getResources().getDrawable(R.drawable.opcao_certa));
            textView.setEnabled(false);
        } else {
            MostrarResposta();
            textView.setBackground(getResources().getDrawable(R.drawable.opcao_errada));

        }
    }


    void Resetar() {
        binding.opcao1.setBackground(getResources().getDrawable(R.drawable.opcao_naoselecionada));
        binding.opcao2.setBackground(getResources().getDrawable(R.drawable.opcao_naoselecionada));
        binding.opcao3.setBackground(getResources().getDrawable(R.drawable.opcao_naoselecionada));
        binding.opcao4.setBackground(getResources().getDrawable(R.drawable.opcao_naoselecionada));

    }

    public void OnClick(View view) {
        switch (view.getId()) {
            case R.id.opcao1:
            case R.id.opcao2:
            case R.id.opcao3:
            case R.id.opcao4:
                if (temporizador != null)
                    temporizador.cancel();


                TextView selecionado = (TextView) view;
                VerificarResposta(selecionado);

                break;
            case R.id.btProxima:
                Resetar();
                if (index <= questoes.size() - 2) {
                    index++;
                    DefinirProximaQuestao();
                } else {
                    Intent intent = new Intent(MetodosQuiz.this, Resultado.class);
                    intent.putExtra("correto", respostaCorreta);
                    intent.putExtra("total", questoes.size());
                    startActivity(intent);
                    Toast.makeText(this, "Questões terminadas.", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.btSair:
                        Intent intent = new Intent(MetodosQuiz.this, MenuQuiz.class);
                        startActivity(intent);


        }
    }


}
