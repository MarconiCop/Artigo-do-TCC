package br.com.marconi.discalcmath.Financas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class juroscomposto_financas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juroscomposto_financas);

        TextView titulo1_financas = (TextView) findViewById(R.id.titulo1_financas);
        TextView paragrafo1_financas = (TextView) findViewById(R.id.paragrafo1_financas);
        TextView paragrafo2_financas = (TextView) findViewById(R.id.paragrafo2_financas);
        TextView paragrafo3_financas = (TextView) findViewById(R.id.paragrafo3_financas);


        TextView fonte_financas = (TextView) findViewById(R.id.fonte_financas);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw_modo_discalculia.isChecked() == true) {
                    titulo1_financas.setText(Html.fromHtml("<font color='red'>Juros Composto</font>"));
                    paragrafo1_financas.setText(Html.fromHtml("O sistema de <font color='green'>juros compostos</font> é chamado de <font color='green'>capitalização acumulada</font><font color='#EA8240'>,</font> pois<font color='#EA8240'>,</font> ao final de cada período os juros que incidem sobre o <font color='green'>capital inicial</font> são incorporados<font color='#EA8240'>.</font>"));
                    paragrafo2_financas.setText(Html.fromHtml("Para calcular o <font color='green'>montante</font> em uma capitalização a juros compostos<font color='#EA8240'>,</font> usamos a seguinte fórmula<font color='#EA8240'>;</font>"));
                    paragrafo3_financas.setText(Html.fromHtml("<font color='green'>Mn</font> <font color='#EA8240'>=</font> <font color='green'>C</font> <font color='#EA8240'>.</font> <font color='#EA8240'>(</font><font color='blue'>1</font><font color='#EA8240'>+</font><font color='green'>i</font><font color='#EA8240'>)</font><font color='#EA8240'>^</font><font color='green'>n</font><font color='#EA8240'>.</font>"));
                    fonte_financas.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if (sw_modo_discalculia.isChecked() == false) {
                    titulo1_financas.setText(Html.fromHtml("Juros Composto"));
                    paragrafo1_financas.setText(Html.fromHtml("O sistema de juros compostos é chamado de capitalização acumulada, pois, ao final de cada período os juros que incidem sobre o capital inicial são incorporados."));
                    paragrafo2_financas.setText(Html.fromHtml("Para calcular o montante em uma capitalização a juros compostos, usamos a seguinte fórmula:"));
                    paragrafo3_financas.setText(Html.fromHtml("Mn = C . (1+i)^n."));

                    fonte_financas.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(juroscomposto_financas.this, selecao_matematica_financeira.class);
                startActivity(intent);
            }
        });
    }
}