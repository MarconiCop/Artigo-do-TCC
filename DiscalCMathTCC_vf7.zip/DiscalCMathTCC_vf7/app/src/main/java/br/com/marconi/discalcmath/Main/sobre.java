package br.com.marconi.discalcmath.Main;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import br.com.marconi.discalcmath.Estatistica.selecao_estatistica;
import br.com.marconi.discalcmath.Painel.materias_painel;
import br.com.marconi.discalcmath.R;

public class sobre extends AppCompatActivity {

    TextView pdp;
    Button voltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sobre);

        pdp = findViewById(R.id.titulo2_sobre);
        voltar = findViewById(R.id.btVoltarLogin2);

        pdp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                gotoUrl("https://marconifrancisco.blogspot.com/2021/05/privacy-policy-para-idioma-portugues.html");
            }
        });


        voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sobre.this, MainActivity.class);
                startActivity(intent);

            }
        });



    }

    private void gotoUrl(String s) {
        Uri uri = Uri.parse(s);
        startActivity(new Intent(getIntent().ACTION_VIEW,uri));
    }
}