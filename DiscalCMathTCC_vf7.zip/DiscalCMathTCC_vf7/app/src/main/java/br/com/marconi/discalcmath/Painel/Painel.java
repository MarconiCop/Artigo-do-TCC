
package br.com.marconi.discalcmath.Painel;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.airbnb.lottie.LottieAnimationView;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.Perfil.ExibirPerfil;
import br.com.marconi.discalcmath.Jogo.MenuQuiz;
import br.com.marconi.discalcmath.Main.MainActivity;
import br.com.marconi.discalcmath.Perfil.Perfil;
import br.com.marconi.discalcmath.Questionario.QuestionarioPainel;
import br.com.marconi.discalcmath.R;

public class Painel extends AppCompatActivity {

    Usuario usuario;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_painel);

        CardView materias = (CardView) findViewById(R.id.cvMaterias);
        CardView questionario = (CardView) findViewById(R.id.cvQuestionario);
        CardView questoes = (CardView) findViewById(R.id.cvQuestoes);
        CardView perfil = (CardView) findViewById(R.id.cvPerfil);
        CardView verperfil = (CardView) findViewById(R.id.cvVerPerfil);
        CardView sair = (CardView) findViewById(R.id.cvSair);
        TextView txtBv = (TextView) findViewById(R.id.txtBv);
        TextView txtPainel = (TextView) findViewById(R.id.txtPainel);
        ImageView imQuest = (ImageView) findViewById(R.id.imQuest);


        materias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Painel.this, materias_painel.class);
                startActivity(intent);
            }
        });

        questoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Painel.this, MenuQuiz.class);
                startActivity(intent);
            }
        });

        perfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Painel.this, Perfil.class);
                startActivity(intent);
            }
        });

        questionario.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Painel.this, QuestionarioPainel.class);
                startActivity(intent);
            }
        });

        verperfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Painel.this, ExibirPerfil.class);
                startActivity(intent);
            }
        });

        sair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finishAffinity();
                Intent intent = new Intent(Painel.this, MainActivity.class);
                startActivity(intent);
            }
        });

        try {
            db = FirebaseFirestore.getInstance();
            db.collection("usuarios")
                    .document(FirebaseAuth.getInstance().getUid())
                    .get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                @Override
                public void onSuccess(DocumentSnapshot documentSnapshot) {
                    usuario = documentSnapshot.toObject(Usuario.class);
                    txtPainel.setText("Bem vindo(a) " + usuario.getNome() + "!");
                    txtBv.setText("Dificuldade: " + usuario.getDificuldade());


                    if (usuario.getDificuldade().equals("BAIXA")) {
                        imQuest.setImageDrawable(ContextCompat.getDrawable(Painel.this, R.drawable.piscando));
                    } else if (usuario.getDificuldade().equals("MÉDIA")) {
                        imQuest.setImageDrawable(ContextCompat.getDrawable(Painel.this, R.drawable.evaluate));
                    } else if (usuario.getDificuldade().equals("ALTA")) {
                        imQuest.setImageDrawable(ContextCompat.getDrawable(Painel.this, R.drawable.sad));
                    }
                }
            });
        } catch (Exception e) {
            Toast.makeText(Painel.this, "Erro ao logar", Toast.LENGTH_SHORT).show();
        }
    }
}