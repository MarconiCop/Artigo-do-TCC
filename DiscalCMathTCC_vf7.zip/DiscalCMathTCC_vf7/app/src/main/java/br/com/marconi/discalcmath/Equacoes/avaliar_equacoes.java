package br.com.marconi.discalcmath.Equacoes;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class avaliar_equacoes extends AppCompatActivity {

    TextView campoAv;
    Button btAvaliar, btVoltar;
    DatabaseReference databaseReference;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    DocumentReference documentReference;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    String currentUserId;
    RatingBar ratingBar;
    Usuario member;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_avaliar_estatistica);


        //DECLARAÇÃO DOS COMPONENTES USADOS
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);
        btAvaliar = (Button) findViewById(R.id.btAvaliar);
        btVoltar = (Button) findViewById(R.id.btVoltarAv);


        //CRIA UM NOVO BANCO
        member = new Usuario();


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        currentUserId = user.getUid();
        documentReference = db.collection("ratings_equacoes").document(currentUserId);
        databaseReference = database.getReference("All Ratings");

        btAvaliar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadData();
            }
        });

        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(avaliar_equacoes.this, selecao_equacoes.class);
                startActivity(intent);
            }
        });

        mostrarDados();


    }

    private void uploadData() {

        float rating = ratingBar.getRating();
        try {
            Map<String, Float> profile = new HashMap<>();
            profile.put("rating", rating);

            member.setRating(rating);

            databaseReference.child(currentUserId).setValue(member);

            documentReference.set(profile)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(avaliar_equacoes.this, "Avaliação salva", Toast.LENGTH_SHORT).show();
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(avaliar_equacoes.this, "Avaliação não salva", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarDados() {

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String currentid = user.getUid();
        DocumentReference reference;
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        campoAv = (TextView) findViewById(R.id.campoAv);

        reference = firestore.collection("ratings_equacoes").document(currentid);
        reference.get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                        if (task.getResult().exists()) {

                            Double campoResult = task.getResult().getDouble("rating");

                            campoAv.setText(String.valueOf(campoResult));
                            ratingBar.setRating(Float.parseFloat(String.valueOf(campoResult)));
                        }
                    }

                });
    }
}