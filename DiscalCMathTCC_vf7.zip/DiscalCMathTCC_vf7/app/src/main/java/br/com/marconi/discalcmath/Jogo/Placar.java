package br.com.marconi.discalcmath.Jogo;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.Adaptadores.ResultadoAdapter;
import br.com.marconi.discalcmath.databinding.FragmentPlacarBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class Placar extends Fragment {


    public Placar() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    FragmentPlacarBinding binding;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentPlacarBinding.inflate(inflater,container,false);

        FirebaseFirestore db = FirebaseFirestore.getInstance();

       final ArrayList<Usuario> usuarios = new ArrayList<>();
       final ResultadoAdapter adapter = new ResultadoAdapter(getContext(),usuarios);


        binding.recyclerView.setAdapter(adapter);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));





        db.collection("usuarios")
                .orderBy("moedas", Query.Direction.DESCENDING).get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                for(DocumentSnapshot snapshot : queryDocumentSnapshots){
                    Usuario usuario = snapshot.toObject(Usuario.class);
                    usuarios.add(usuario);
                }
                adapter.notifyDataSetChanged();

            }
        });

        return binding.getRoot();
    }
}