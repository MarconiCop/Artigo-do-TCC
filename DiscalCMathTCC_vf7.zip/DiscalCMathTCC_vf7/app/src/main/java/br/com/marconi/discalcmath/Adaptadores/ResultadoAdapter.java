package br.com.marconi.discalcmath.Adaptadores;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.R;
import br.com.marconi.discalcmath.databinding.LinhaPlacarBinding;

import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;



public class ResultadoAdapter extends RecyclerView.Adapter<ResultadoAdapter.ResultadoViewHolder> {

    Context context;
    ArrayList<Usuario> usuarios;
    ImageView imageView;
    StorageReference storageReference;
    Uri imageUri;




    public ResultadoAdapter(Context context, ArrayList<Usuario> usuarios) {
        this.context = context;
        this.usuarios = usuarios;
    }

    @NonNull
    @Override
    public ResultadoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.linha_placar,parent,false);


        return new ResultadoViewHolder(view);
    }





    @Override
    public void onBindViewHolder(@NonNull ResultadoViewHolder holder, int position) {
    Usuario usuario = usuarios.get(position);


        imageView = holder.binding.imagemPerfil;


         String url =  usuario.getUrl();
         Picasso.get().load(url).into(imageView);


         holder.binding.nome.setText((usuario.getNome()));
         holder.binding.moedasplacar.setText(String.valueOf(usuario.getMoedas()));
         holder.binding.index.setText(String.format("%d",position+1));


    }


    @Override
    public int getItemCount() {
        return usuarios.size();
    }

    public class ResultadoViewHolder extends RecyclerView.ViewHolder {

        LinhaPlacarBinding binding;
        public ResultadoViewHolder(@NonNull View itemView) {
            super(itemView);
            binding = LinhaPlacarBinding.bind(itemView);


        }
    }
}
