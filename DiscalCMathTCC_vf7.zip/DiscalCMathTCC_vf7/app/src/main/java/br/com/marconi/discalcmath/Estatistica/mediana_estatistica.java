package br.com.marconi.discalcmath.Estatistica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class mediana_estatistica extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mediana_estatistica);

        TextView titulo1_estatistica = (TextView) findViewById(R.id.titulo1_estatistica);
        TextView titulo2_estatistica = (TextView) findViewById(R.id.titulo2_estatistica);
        TextView titulo3_estatistica = (TextView) findViewById(R.id.titulo3_estatistica);
        TextView paragrafo1_estatistica = (TextView) findViewById(R.id.paragrafo1_estatistica);
        TextView paragrafo2_estatistica = (TextView) findViewById(R.id.paragrafo2_estatistica);
        TextView paragrafo3_estatistica = (TextView) findViewById(R.id.paragrafo3_estatistica);
        TextView paragrafo4_estatistica = (TextView) findViewById(R.id.paragrafo4_estatistica);
        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_estatistica);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_estatistica.setText(Html.fromHtml("<font color='red'>Mediana</font>"));
                    paragrafo1_estatistica.setText(Html.fromHtml("A <font color='green'>Mediana</font> <font color='#EA8240'>(</font><font color='green'>Md</font><font color='#EA8240'>)</font> representa o valor central de um conjunto de dados<font color='#EA8240'>.</font> Para encontrar o valor da mediana é necessário colocar os valores em ordem crescente ou decrescente<font color='#EA8240'>.</font>"));

                    titulo2_estatistica.setText(Html.fromHtml("<font color='red'>Conjunto de número par</font>"));
                    paragrafo2_estatistica.setText(Html.fromHtml("Quando o número elementos de um conjunto é <font color='green'>par</font><font color='#EA8240'>,</font> a mediana é encontrada pela média dos dois valores centrais<font color='#EA8240'>.</font> Assim<font color='#EA8240'>,</font> esses valores são somados e divididos por <font color='blue'>2</font><font color='#EA8240'>.</font>"));

                    titulo3_estatistica.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo3_estatistica.setText(Html.fromHtml("Em uma escola<font color='#EA8240'>,</font> o professor de educação física anotou a altura de um grupo de alunos<font color='#EA8240'>.</font> Considerando que os valores medidos foram<font color='#EA8240'>:</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>54</font> <font color='green'>m</font><font color='#EA8240'>;</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>67</font> <font color='green'>m</font><font color='#EA8240'>,</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>50</font> <font color='green'>m</font><font color='#EA8240'>;</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>65</font> <font color='green'>m</font><font color='#EA8240'>;</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>75</font> <font color='green'>m</font><font color='#EA8240'>;</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>69</font> <font color='green'>m</font><font color='#EA8240'>;</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>60</font> <font color='green'>m</font><font color='#EA8240'>;</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>55</font> <font color='green'>m</font> e <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>78</font> <font color='green'>m</font><font color='#EA8240'>.</font>"));
                    paragrafo4_estatistica.setText(Html.fromHtml("Colocando na ordem crescente e como o conjunto é formado por <font color='blue'>9</font> elementos<font color='#EA8240'>,</font> que é um número <font color='green'>ímpar</font><font color='#EA8240'>,</font> então a mediana será igual ao <font color='blue'>5</font><font color='#EA8240'>º</font> elemento<font color='#EA8240'>,</font> ou seja<font color='#EA8240'>:</font> <font color='green'>Md</font> <font color='#EA8240'>=</font> <font color='blue'>1</font><font color='#EA8240'>,</font><font color='blue'>65</font> <font color='green'>m</font><font color='#EA8240'>.</font>"));

                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_estatistica.setText(Html.fromHtml("Mediana"));
                    paragrafo1_estatistica.setText(Html.fromHtml("A Mediana (Md) representa o valor central de um conjunto de dados. Para encontrar o valor da mediana é necessário colocar os valores em ordem crescente ou decrescente."));

                    titulo2_estatistica.setText(Html.fromHtml("Conjunto de número par"));
                    paragrafo2_estatistica.setText(Html.fromHtml("Quando o número elementos de um conjunto é par, a mediana é encontrada pela média dos dois valores centrais. Assim, esses valores são somados e divididos por 2."));

                    titulo3_estatistica.setText(Html.fromHtml("Exemplo"));
                    paragrafo3_estatistica.setText(Html.fromHtml("Em uma escola, o professor de educação física anotou a altura de um grupo de alunos. Considerando que os valores medidos foram: 1,54 m; 1,67 m, 1,50 m; 1,65 m; 1,75 m; 1,69 m; 1,60 m; 1,55 m e 1,78 m."));
                    paragrafo4_estatistica.setText(Html.fromHtml("Colocando na ordem crescente e como o conjunto é formado por 9 elementos, que é um número ímpar, então a mediana será igual ao 5º elemento, ou seja: Md = 1,65 m."));

                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });













        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mediana_estatistica.this, selecao_estatistica.class);
                startActivity(intent);
            }
        });
    }
    }
