package br.com.marconi.discalcmath.Funcoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class logaritmo_funcoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logaritmo_funcoes);

        TextView titulo1_funcoes = (TextView) findViewById(R.id.titulo1_funcoes);
        TextView titulo2_funcoes = (TextView) findViewById(R.id.titulo2_funcoes);
        TextView titulo3_funcoes = (TextView) findViewById(R.id.titulo3_funcoes);
        TextView titulo4_funcoes = (TextView) findViewById(R.id.titulo4_funcoes);
        TextView paragrafo1_funcoes = (TextView) findViewById(R.id.paragrafo1_funcoes);
        TextView paragrafo2_funcoes = (TextView) findViewById(R.id.paragrafo2_funcoes);
        TextView paragrafo3_funcoes = (TextView) findViewById(R.id.paragrafo3_funcoes);
        TextView paragrafo4_funcoes = (TextView) findViewById(R.id.paragrafo4_funcoes);
        TextView paragrafo5_funcoes = (TextView) findViewById(R.id.paragrafo5_funcoes);
        TextView paragrafo6_funcoes = (TextView) findViewById(R.id.paragrafo6_funcoes);
        TextView paragrafo7_funcoes = (TextView) findViewById(R.id.paragrafo7_funcoes);
        TextView fonte_funcoes = (TextView) findViewById(R.id.fonte_funcoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_funcoes.setText(Html.fromHtml("<font color='red'>Função Logarítmica</font>"));
                    titulo2_funcoes.setText(Html.fromHtml("<font color='red'>Exemplos</font>"));
                    titulo3_funcoes.setText(Html.fromHtml("<font color='red'>Domínio</font>"));
                    titulo4_funcoes.setText(Html.fromHtml("<font color='red'>Gráfico</font>"));
                    paragrafo1_funcoes.setText(Html.fromHtml("A <font color='green'>função logarítmica</font> de base <font color='green'>a</font> é definida como <font color='green'>f</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='#EA8240'>log</font> <font color='green'>x</font> na base <font color='green'>a</font><font color='#EA8240'>,</font> com <font color='green'>a</font> real<font color='#EA8240'>,</font> positivo e <font color='green'>a</font> <font color='#EA8240'>≠</font> <font color='blue'>1</font><font color='#EA8240'>.</font> A <font color='green'>função inversa</font> da função logarítmica é a <font color='green'>função exponencial</font><font color='#EA8240'>.</font>"));
                    paragrafo2_funcoes.setText(Html.fromHtml("O <font color='green'>logaritmo</font> de um número é definido como o <font color='green'>expoente</font> ao qual se deve elevar a base <font color='green'>a</font> para obter o número <font color='green'>x</font><font color='#EA8240'>.</font>"));
                    paragrafo3_funcoes.setText(Html.fromHtml(" <font color='green'>f</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='#EA8240'>log</font> <font color='green'>x</font> na base <font color='blue'>3</font>"));
                    paragrafo4_funcoes.setText(Html.fromHtml(" <font color='green'>h</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='#EA8240'>log</font> <font color='green'>x</font> na base <font color='blue'>10</font> <font color='#EA8240'>=</font> <font color='#EA8240'>log</font> <font color='green'>x</font>"));
                    paragrafo5_funcoes.setText(Html.fromHtml("O <font color='green'>domínio</font> de uma função representa os valores de <font color='green'>x</font> onde a função é definida<font color='#EA8240'>.</font> No caso da função logarítmica<font color='#EA8240'>,</font> devemos levar em consideração as condições de existência do logaritmo<font color='#EA8240'>.</font> Portanto<font color='#EA8240'>,</font> o logaritmando deve ser positivo e a base também deve ser positiva e diferente de <font color='blue'>1</font><font color='#EA8240'>.</font>"));
                    paragrafo6_funcoes.setText(Html.fromHtml("De uma forma geral<font color='#EA8240'>,</font> o gráfico da função <font color='green'>y</font> <font color='#EA8240'>=</font> <font color='#EA8240'>log</font> <font color='green'>x</font> na base <font color='green'>a</font> está localizado no <font color='blue'>I</font> e <font color='blue'>IV</font> quadrantes<font color='#EA8240'>,</font> pois a função só é definida para <font color='green'>x</font> <font color='#EA8240'>></font> <font color='blue'>0</font><font color='#EA8240'>.</font>"));
                    paragrafo7_funcoes.setText(Html.fromHtml("Além disso<font color='#EA8240'>,</font> a <font color='green'>curva</font> da função logarítmica não toca o eixo <font color='green'>y</font> e corta o eixo <font color='green'>x</font> no ponto de abscissa igual a <font color='blue'>1</font><font color='#EA8240'>,</font> pois <font color='green'>y</font> <font color='#EA8240'>=</font> <font color='#EA8240'>log</font> <font color='blue'>1</font> na base <font color='green'>a</font> é igual a  <font color='blue'>0</font><font color='#EA8240'>,</font> para qualquer valor de <font color='green'>a</font><font color='#EA8240'>.</font>"));
                    fonte_funcoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_funcoes.setText(Html.fromHtml("Função Logarítmica"));
                    titulo2_funcoes.setText(Html.fromHtml("Exemplos"));
                    titulo3_funcoes.setText(Html.fromHtml("Domínio"));
                    titulo4_funcoes.setText(Html.fromHtml("Gráfico"));
                    paragrafo1_funcoes.setText(Html.fromHtml("A função logarítmica de base a é definida como f (x) = log x na base a, com a real, positivo e a ≠ 1. A função inversa da função logarítmica é a função exponencial."));
                    paragrafo2_funcoes.setText(Html.fromHtml("O logaritmo de um número é definido como o expoente ao qual se deve elevar a base a para obter o número x."));
                    paragrafo3_funcoes.setText(Html.fromHtml("f (x) = log x na base 3"));
                    paragrafo4_funcoes.setText(Html.fromHtml("h (x) = log x na base 10 = log x"));
                    paragrafo5_funcoes.setText(Html.fromHtml("O domínio de uma função representa os valores de x onde a função é definida. No caso da função logarítmica, devemos levar em consideração as condições de existência do logaritmo. Portanto, o logaritmando deve ser positivo e a base também deve ser positiva e diferente de 1."));
                    paragrafo6_funcoes.setText(Html.fromHtml("De uma forma geral, o gráfico da função y = log x na base a está localizado no I e IV quadrantes, pois a função só é definida para x > 0."));
                    paragrafo7_funcoes.setText(Html.fromHtml("Além disso, a curva da função logarítmica não toca o eixo y e corta o eixo x no ponto de abscissa igual a 1, pois y = log 1 na base a é igual a  0, para qualquer valor de a."));
                    fonte_funcoes.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(logaritmo_funcoes.this, selecao_funcoes.class);
                startActivity(intent);
            }
        });
    }
}