package br.com.marconi.discalcmath.Porcentagem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class descontos_porcentagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descontos_porcentagem);

        TextView titulo1_porcentagem = (TextView) findViewById(R.id.titulo1_porcentagem);
        TextView titulo2_porcentagem = (TextView) findViewById(R.id.titulo2_porcentagem);
        TextView paragrafo1_porcentagem = (TextView) findViewById(R.id.paragrafo1_porcentagem);
        TextView paragrafo2_porcentagem = (TextView) findViewById(R.id.paragrafo2_porcentagem);
        TextView paragrafo3_porcentagem = (TextView) findViewById(R.id.paragrafo3_porcentagem);
        TextView paragrafo4_porcentagem = (TextView) findViewById(R.id.paragrafo4_porcentagem);
        TextView paragrafo5_porcentagem = (TextView) findViewById(R.id.paragrafo5_porcentagem);
        TextView paragrafo6_porcentagem = (TextView) findViewById(R.id.paragrafo6_porcentagem);
        TextView paragrafo7_porcentagem = (TextView) findViewById(R.id.paragrafo7_porcentagem);




        TextView fonte_porcentagem = (TextView) findViewById(R.id.fonte_porcentagem);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_porcentagem.setText(Html.fromHtml("<font color='red'>Cálculo de descontos</font>"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("O <font color='green'>cálculo de descontos</font> se dá por calcular o desconto de certo produto ou venda<font color='#EA8240'>.</font>"));
                    paragrafo2_porcentagem.setText(Html.fromHtml("A diferença do cálculo original de porcentagem é que no cálculo do desconto<font color='#EA8240'>,</font> logo após achar o valor do desconto<font color='#EA8240'>,</font> deve-se <font color='green'>subtrair</font> esse valor do valor total<font color='#EA8240'>.</font>"));

                    titulo2_porcentagem.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo3_porcentagem.setText(Html.fromHtml("Na promoção de uma loja de eletrodomésticos<font color='#EA8240'>,</font> um aparelho de som que custava <font color='#EA8240'>R$</font> <font color='blue'>400</font><font color='#EA8240'>,</font><font color='blue'>00</font> teve um desconto de <font color='blue'>12</font><font color='#EA8240'>%</font><font color='#EA8240'>.</font> Quanto o cliente que decidir comprar o equipamento pagará<font color='#EA8240'>?</font>"));
                    paragrafo4_porcentagem.setText(Html.fromHtml("Para descobrir o desconto concedido<font color='#EA8240'>,</font> devemos calcular quanto é <font color='blue'>12</font><font color='#EA8240'>%</font> de <font color='blue'>400</font><font color='#EA8240'>,</font><font color='blue'>00</font> realizando a seguinte operação<font color='#EA8240'>:</font>"));
                    paragrafo5_porcentagem.setText(Html.fromHtml("<font color='blue'>12</font><font color='#EA8240'>%</font> de <font color='blue'>400</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='blue'>12</font><font color='#EA8240'>/</font><font color='blue'>100</font><font color='#EA8240'>)</font><font color='#EA8240'>*</font><font color='blue'>400</font> <font color='#EA8240'>=</font> <font color='blue'>48</font><font color='#EA8240'>.</font>"));
                    paragrafo6_porcentagem.setText(Html.fromHtml("Subtraindo o desconto calculado do valor total do aparelho de som<font color='#EA8240'>,</font> temos o valor final pago pelo cliente<font color='#EA8240'>:</font>"));
                    paragrafo7_porcentagem.setText(Html.fromHtml("<font color='#EA8240'>R$</font> <font color='blue'>400</font><font color='#EA8240'>,</font><font color='blue'>00</font> <font color='#EA8240'>-</font> <font color='#EA8240'>R$</font> <font color='blue'>48</font><font color='#EA8240'>,</font><font color='blue'>00</font> <font color='#EA8240'>=</font> <font color='#EA8240'>R$</font> <font color='blue'>352</font><font color='#EA8240'>,</font><font color='blue'>00</font><font color='#EA8240'>.</font>"));

                    fonte_porcentagem.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_porcentagem.setText(Html.fromHtml("Cálculo de descontos"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("O cálculo de descontos se dá por calcular o desconto de certo produto ou venda."));
                    paragrafo2_porcentagem.setText(Html.fromHtml("A diferença do cálculo original de porcentagem é que no cálculo do desconto, logo após achar o valor do desconto, deve-se subtrair esse valor do valor total."));

                    titulo2_porcentagem.setText(Html.fromHtml("Exemplo"));
                    paragrafo3_porcentagem.setText(Html.fromHtml("Na promoção de uma loja de eletrodomésticos, um aparelho de som que custava R$ 400,00 teve um desconto de 12%. Quanto o cliente que decidir comprar o equipamento pagará?"));
                    paragrafo4_porcentagem.setText(Html.fromHtml("Para descobrir o desconto concedido, devemos calcular quanto é 12% de 400,00 realizando a seguinte operação:"));
                    paragrafo5_porcentagem.setText(Html.fromHtml("12% de 400 = (12/100)*400 = 48."));
                    paragrafo6_porcentagem.setText(Html.fromHtml("Subtraindo o desconto calculado do valor total do aparelho de som, temos o valor final pago pelo cliente:"));
                    paragrafo7_porcentagem.setText(Html.fromHtml("R$ 400,00 - R$ 48,00 = R$ 352,00."));

                    fonte_porcentagem.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });




        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(descontos_porcentagem.this, selecao_porcentagem.class);
                startActivity(intent);
            }
        });
    }
}