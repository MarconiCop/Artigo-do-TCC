package br.com.marconi.discalcmath.Perfil;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import br.com.marconi.discalcmath.Painel.Painel;

import br.com.marconi.discalcmath.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

public class ExibirPerfil extends AppCompatActivity {

    ImageView imageView;
    TextView nameEt, profEt, bioEt, emailEt,  etWeb;
    ImageButton bt_up;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exibir_perfil);

        imageView = findViewById(R.id.iv_f1);
        nameEt = findViewById(R.id.tv_name_f1);
        profEt = findViewById(R.id.tv_prof_f1);
        bioEt = findViewById(R.id.tv_bio_f1);
        emailEt = findViewById(R.id.tv_email_f1);
        etWeb = findViewById(R.id.tv_curso_f1);
        bt_up = findViewById(R.id.bt_upPerfil);

        bt_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ExibirPerfil.this, UpdatePerfil.class);
                startActivity(intent);
            }
        });


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        String currentid = user.getUid();
        DocumentReference reference;
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();

        reference = firestore.collection("usuarios").document(currentid);
        reference.get()
                .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                        if(task.getResult().exists()){


                            String nameResult = task.getResult().getString("nome");
                            String bioResult = task.getResult().getString("bio");
                            String profResult = task.getResult().getString("prof");
                            String emailResult = task.getResult().getString("email");
                            String webResult = task.getResult().getString("web");
                            String url = task.getResult().getString("url");

                            Picasso.get().load(url).into(imageView);
                            nameEt.setText(nameResult);
                            bioEt.setText(bioResult);
                            emailEt.setText(emailResult);
                            etWeb.setText(webResult);
                            profEt.setText(profResult);


                        }else{
                            Intent intent = new Intent(ExibirPerfil.this, Perfil.class);
                            startActivity(intent);
                        }

                    }
                });

        bt_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ExibirPerfil.this, UpdatePerfil.class);
                startActivity(intent);
            }
        });

        Button btVoltarPerfil = (Button) findViewById(R.id.btVoltarPerfil);

        btVoltarPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ExibirPerfil.this, Painel.class);
                startActivity(intent);
            }
        });

    }







}