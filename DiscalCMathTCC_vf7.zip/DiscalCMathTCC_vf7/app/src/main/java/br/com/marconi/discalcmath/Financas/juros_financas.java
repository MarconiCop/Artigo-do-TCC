package br.com.marconi.discalcmath.Financas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class juros_financas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juros_financas);

        TextView titulo1_financas = (TextView) findViewById(R.id.titulo1_financas);
        TextView titulo2_financas = (TextView) findViewById(R.id.titulo2_financas);
        TextView paragrafo1_financas = (TextView) findViewById(R.id.paragrafo1_financas);
        TextView paragrafo2_financas = (TextView) findViewById(R.id.paragrafo2_financas);
        TextView paragrafo3_financas = (TextView) findViewById(R.id.paragrafo3_financas);
        TextView paragrafo4_financas = (TextView) findViewById(R.id.paragrafo4_financas);
        TextView paragrafo5_financas = (TextView) findViewById(R.id.paragrafo5_financas);

        TextView fonte_financas = (TextView) findViewById(R.id.fonte_financas);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw_modo_discalculia.isChecked() == true) {
                    titulo1_financas.setText(Html.fromHtml("<font color='red'>Juros</font>"));
                    titulo2_financas.setText(Html.fromHtml("<font color='red'>Juros Simples</font>"));
                    paragrafo1_financas.setText(Html.fromHtml("O cálculo de <font color='green'>juros</font> pode ser <font color='green'>simples</font> ou <font color='green'>composto</font><font color='#EA8240'>.</font> No <font color='green'>regime de capitalização simples</font><font color='#EA8240'>,</font> a correção é feita sempre sobre o valor do <font color='green'>capital inicial</font><font color='#EA8240'>.</font>"));
                    paragrafo2_financas.setText(Html.fromHtml("Já nos <font color='green'>juros compostos</font><font color='#EA8240'>,</font> a <font color='green'>taxa de juros</font> é aplicada sempre sobre o <font color='green'>montante</font> do período anterior<font color='#EA8240'>.</font> Note que esse último é muito utilizado nas transações comerciais e financeiras<font color='#EA8240'>.</font>"));
                    paragrafo3_financas.setText(Html.fromHtml("Os <font color='green'>juros simples</font> são calculados levando em consideração um determinado período<font color='#EA8240'>.</font> Ele é calculado pela fórmula<font color='#EA8240'>:</font>"));
                    paragrafo4_financas.setText(Html.fromHtml("<font color='green'>J</font> <font color='#EA8240'>=</font> <font color='green'>C</font> <font color='#EA8240'>.</font> <font color='green'>i</font> <font color='#EA8240'>.</font> <font color='green'>n</font>"));
                    paragrafo5_financas.setText(Html.fromHtml("Onde<font color='#EA8240'>:</font> <font color='green'>C</font> é o <font color='green'>capital aplicado</font><font color='#EA8240'>,</font> <font color='green'>i</font> é a <font color='green'>taxa de juros</font> e <font color='green'>n</font> é o  <font color='green'>período</font> que corresponde os juros<font color='#EA8240'>.</font>"));

                    fonte_financas.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if (sw_modo_discalculia.isChecked() == false) {
                    titulo1_financas.setText(Html.fromHtml("Juros"));
                    paragrafo1_financas.setText(Html.fromHtml("O cálculo de juros pode ser simples ou composto. No regime de capitalização simples, a correção é feita sempre sobre o valor do capital inicial."));
                    paragrafo2_financas.setText(Html.fromHtml("Já nos juros compostos, a taxa de juros é aplicada sempre sobre o montante do período anterior. Note que esse último é muito utilizado nas transações comerciais e financeiras."));
                    titulo2_financas.setText(Html.fromHtml("Juros Simples"));
                    paragrafo3_financas.setText(Html.fromHtml("Os juros simples são calculados levando em consideração um determinado período. Ele é calculado pela fórmula:"));
                    paragrafo4_financas.setText(Html.fromHtml("J = C . i . n"));
                    paragrafo5_financas.setText(Html.fromHtml("Onde: C é o capital aplicado, i é a taxa de juros e n é o  período que corresponde os juros."));

                    fonte_financas.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(juros_financas.this, selecao_matematica_financeira.class);
                startActivity(intent);
            }
        });
    }





    }

