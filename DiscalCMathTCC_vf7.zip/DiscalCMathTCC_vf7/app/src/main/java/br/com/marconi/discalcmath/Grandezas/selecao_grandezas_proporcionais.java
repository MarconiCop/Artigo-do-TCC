package br.com.marconi.discalcmath.Grandezas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import br.com.marconi.discalcmath.Painel.materias_painel;
import br.com.marconi.discalcmath.R;

public class selecao_grandezas_proporcionais extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_grandezas_proporcionais);

        LinearLayout introducao_grandezas = (LinearLayout) findViewById(R.id.introducao_funcoes);
        LinearLayout proporcaodireta_grandezas = (LinearLayout) findViewById(R.id.proporcaodireta_grandezas);
        LinearLayout proporcaoindireta_grandezas = (LinearLayout) findViewById(R.id.proporcaoindireta_grandezas);
        LinearLayout btAvaliarGrandezas = (LinearLayout) findViewById(R.id.btAvaliarGrandezas);
        ImageView ImVoltar = (ImageView) findViewById(R.id.imVoltarGrandezas);

        ImVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_grandezas_proporcionais.this, materias_painel.class);
                startActivity(intent);
            }
        });

        introducao_grandezas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_grandezas_proporcionais.this, introducao_grandezas.class);
                startActivity(intent);
            }
        });

        proporcaodireta_grandezas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_grandezas_proporcionais.this, direta_grandezas.class);
                startActivity(intent);
            }
        });

        proporcaoindireta_grandezas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_grandezas_proporcionais.this, indireta_grandezas.class);
                startActivity(intent);
            }
        });

        btAvaliarGrandezas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_grandezas_proporcionais.this, avaliar_grandezas.class);
                startActivity(intent);
            }
        });
    }
}