package br.com.marconi.discalcmath.Questionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.Painel.Painel;
import br.com.marconi.discalcmath.R;

public class discalculia_media extends AppCompatActivity {

    Usuario usuario;
    String currentUserId;
    DocumentReference documentReference;
    DatabaseReference databaseReference;
    FirebaseDatabase database = FirebaseDatabase.getInstance();
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discalculia_media);

        Button btIrPainel = (Button) findViewById(R.id.btIrPainel);
        Button btAvaliarDiscalculia = (Button) findViewById(R.id.btAvaliarDiscalculiaMedia);

        usuario = new Usuario();

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        currentUserId = user.getUid();
        documentReference = db.collection("usuarios").document(currentUserId);
        databaseReference = database.getReference("All dificuldades");

        btAvaliarDiscalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadData();
            }
        });

        btIrPainel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(discalculia_media.this, Painel.class);
                startActivity(intent);
            }
        });
    }

    private void uploadData() {

        TextView dificuldadeBaixa = (TextView) findViewById(R.id.dificuldadeMedia);

        String dificuldade = dificuldadeBaixa.getText().toString();

        try {
            Map<String, Object> profile = new HashMap<>();
            profile.put("dificuldade", dificuldade);

            usuario.setDificuldade(dificuldade);

            databaseReference.child(currentUserId).setValue(usuario);

            documentReference.update(profile)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(discalculia_media.this, "Enviado!", Toast.LENGTH_SHORT).show();
                        }
                    });
        } catch (Exception e) {
            Toast.makeText(discalculia_media.this, "Não enviado!", Toast.LENGTH_SHORT).show();
        }
    }
}