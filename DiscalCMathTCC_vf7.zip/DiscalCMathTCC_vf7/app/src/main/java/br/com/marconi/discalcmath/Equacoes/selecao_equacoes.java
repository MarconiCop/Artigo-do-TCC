package br.com.marconi.discalcmath.Equacoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import br.com.marconi.discalcmath.Painel.materias_painel;
import br.com.marconi.discalcmath.R;

public class selecao_equacoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_equacoes);

        LinearLayout introducao_equacoes = (LinearLayout) findViewById(R.id.introducao_funcoes);
        LinearLayout grau_equacoes = (LinearLayout) findViewById(R.id.grau_equacoes);
        LinearLayout solucao_equacoes = (LinearLayout) findViewById(R.id.solucao_equacoes);
        LinearLayout expressoes_equacoes = (LinearLayout) findViewById(R.id.expressoes_equacoes);
        LinearLayout igualdade_equacoes = (LinearLayout) findViewById(R.id.igualdade_equacoes);
        LinearLayout btAvaliarEquacoes = (LinearLayout) findViewById(R.id.btAvaliarEquacoes);
        ImageView ImVoltar = (ImageView) findViewById(R.id.ImVoltar);

        ImVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_equacoes.this, materias_painel.class);
                startActivity(intent);
            }
        });

        introducao_equacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_equacoes.this, introducao_equacoes.class);
                startActivity(intent);
            }
        });

        grau_equacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_equacoes.this, grau_equacoes.class);
                startActivity(intent);
            }
        });

        solucao_equacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_equacoes.this, solucao_equacoes.class);
                startActivity(intent);
            }
        });

        expressoes_equacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_equacoes.this, expressoes_equacoes.class);
                startActivity(intent);
            }
        });

        igualdade_equacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_equacoes.this, igualdade_equacoes.class);
                startActivity(intent);
            }
        });

        btAvaliarEquacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_equacoes.this, avaliar_equacoes.class);
                startActivity(intent);
            }
        });

    }
}