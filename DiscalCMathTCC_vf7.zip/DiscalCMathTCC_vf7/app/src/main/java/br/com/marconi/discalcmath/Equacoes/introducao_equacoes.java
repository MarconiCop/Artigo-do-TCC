package br.com.marconi.discalcmath.Equacoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class introducao_equacoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introducao_equacoes);

        TextView titulo1_equacoes = (TextView) findViewById(R.id.titulo1_equacoes);
        TextView paragrafo1_equacoes = (TextView) findViewById(R.id.paragrafo1_equacoes);
        TextView paragrafo2_equacoes = (TextView) findViewById(R.id.paragrafo2_equacoes);
        TextView paragrafo3_equacoes = (TextView) findViewById(R.id.paragrafo3_equacoes);
        TextView paragrafo4_equacoes = (TextView) findViewById(R.id.paragrafo4_equacoes);
        TextView fonte_equacoes = (TextView) findViewById(R.id.fonte_equacoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw_modo_discalculia.isChecked() == true) {
                    titulo1_equacoes.setText(Html.fromHtml("<font color='red'>Introdução</font>"));
                    paragrafo1_equacoes.setText(Html.fromHtml("<font color='green'>Equação</font> é uma <font color='green'>expressão algébrica</font> que contém uma <font color='green'>igualdade</font><font color='#EA8240'>.</font>"));
                    paragrafo2_equacoes.setText(Html.fromHtml("Ela foi criada para ajudar as pessoas a encontrarem <font color='green'>soluções</font> para problemas nos quais um número não é conhecido<font color='#EA8240'>.</font>"));
                    paragrafo3_equacoes.setText(Html.fromHtml("Sabendo que a soma de dois números consecutivos é igual a <font color='blue'>11</font><font color='#EA8240'>,</font> por exemplo<font color='#EA8240'>,</font> é possível encontrar esses dois números por meio de equações<font color='#EA8240'>.</font>"));
                    paragrafo4_equacoes.setText(Html.fromHtml("Antes de aprender a resolver equações<font color='#EA8240'>,</font> é preciso compreender o significado da definição dada acima<font color='#EA8240'>.</font>"));
                    fonte_equacoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Brasil Escola<font color='#EA8240'>.</font>"));
                }
                if (sw_modo_discalculia.isChecked() == false) {
                    titulo1_equacoes.setText(Html.fromHtml("Introdução"));
                    paragrafo1_equacoes.setText(Html.fromHtml("Equação é uma expressão algébrica que contém uma igualdade."));
                    paragrafo2_equacoes.setText(Html.fromHtml("Ela foi criada para ajudar as pessoas a encontrarem soluções para problemas nos quais um número não é conhecido."));
                    paragrafo3_equacoes.setText(Html.fromHtml("Sabendo que a soma de dois números consecutivos é igual a 11, por exemplo, é possível encontrar esses dois números por meio de equações."));
                    paragrafo4_equacoes.setText(Html.fromHtml("Antes de aprender a resolver equações, é preciso compreender o significado da definição dada acima."));
                    fonte_equacoes.setText(Html.fromHtml("Fonte: Brasil Escola."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(introducao_equacoes.this, selecao_equacoes.class);
                startActivity(intent);
            }
        });
    }
}
