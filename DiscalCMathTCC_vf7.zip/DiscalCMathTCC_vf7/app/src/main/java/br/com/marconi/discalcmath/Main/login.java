package br.com.marconi.discalcmath.Main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import br.com.marconi.discalcmath.Painel.Painel;
import br.com.marconi.discalcmath.R;
import br.com.marconi.discalcmath.databinding.ActivityLoginBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class login extends AppCompatActivity {

    ActivityLoginBinding binding;
    FirebaseAuth autenticar;
    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        Button btVoltarLogin = (Button) findViewById(R.id.btVoltarLogin);


        autenticar = FirebaseAuth.getInstance();

        dialog = new ProgressDialog(this);
        dialog.setMessage("Logando");

        try {


            binding.btLoginPrincipal.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String email, senha;

                    email = binding.txtUsuarioLogin.getText().toString();
                    senha = binding.txtSenhaLogin.getText().toString();

                    if (!email.equals("") && !senha.equals("")) {

                        dialog.show();

                        autenticar.signInWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                dialog.dismiss();
                                if (task.isSuccessful()) {
                                    Toast.makeText(login.this, "Logado com sucesso!", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(login.this, Painel.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(login.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    } else {
                        Toast.makeText(login.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }catch(Exception e){
            Toast.makeText(login.this, "Erro ao logar!", Toast.LENGTH_SHORT).show();
        }



        btVoltarLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(login.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}