package br.com.marconi.discalcmath.Painel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import br.com.marconi.discalcmath.Equacoes.selecao_equacoes;
import br.com.marconi.discalcmath.Estatistica.selecao_estatistica;
import br.com.marconi.discalcmath.Financas.selecao_matematica_financeira;
import br.com.marconi.discalcmath.Funcoes.selecao_funcoes;
import br.com.marconi.discalcmath.Grandezas.selecao_grandezas_proporcionais;
import br.com.marconi.discalcmath.Porcentagem.selecao_porcentagem;
import br.com.marconi.discalcmath.R;

public class materias_painel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materias_painel);

        LinearLayout Estatistica = (LinearLayout) findViewById(R.id.introducao_funcoes);
        LinearLayout Funcoes = (LinearLayout) findViewById(R.id.Funcoes);
        LinearLayout Grandezas = (LinearLayout) findViewById(R.id.proporcaoindireta_grandezas);
        LinearLayout Porcentagem = (LinearLayout) findViewById(R.id.Porcentagem);
        LinearLayout Financas = (LinearLayout) findViewById(R.id.Financas);
        LinearLayout Equacoes = (LinearLayout) findViewById(R.id.Equacoes);
        ImageView ImVoltar = (ImageView) findViewById(R.id.imVoltarMaterias);

        ImVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(materias_painel.this, Painel.class);
                startActivity(intent);
            }
        });

        Estatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(materias_painel.this, selecao_estatistica.class);
                startActivity(intent);

            }
        });

        Funcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(materias_painel.this, selecao_funcoes.class);
                startActivity(intent);

            }
        });

        Grandezas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(materias_painel.this, selecao_grandezas_proporcionais.class);
                startActivity(intent);

            }
        });

        Porcentagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(materias_painel.this, selecao_porcentagem.class);
                startActivity(intent);

            }
        });

        Financas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(materias_painel.this, selecao_matematica_financeira.class);
                startActivity(intent);

            }
        });

        Equacoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(materias_painel.this, selecao_equacoes.class);
                startActivity(intent);

            }
        });




    }
}