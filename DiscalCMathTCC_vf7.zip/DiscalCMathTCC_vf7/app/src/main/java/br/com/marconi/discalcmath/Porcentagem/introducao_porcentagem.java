package br.com.marconi.discalcmath.Porcentagem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class introducao_porcentagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introducao_porcentagem);

        TextView titulo1_porcentagem = (TextView) findViewById(R.id.titulo1_porcentagem);
        TextView titulo2_porcentagem = (TextView) findViewById(R.id.titulo2_porcentagem);
        TextView paragrafo1_porcentagem = (TextView) findViewById(R.id.paragrafo1_porcentagem);
        TextView paragrafo2_porcentagem = (TextView) findViewById(R.id.paragrafo2_porcentagem);
        TextView paragrafo3_porcentagem = (TextView) findViewById(R.id.paragrafo3_porcentagem);
        TextView paragrafo4_porcentagem = (TextView) findViewById(R.id.paragrafo4_porcentagem);



        TextView fonte_porcentagem = (TextView) findViewById(R.id.fonte_porcentagem);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_porcentagem.setText(Html.fromHtml("<font color='red'>Introdução</font>"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("A <font color='green'>Porcentagem</font> ou <font color='green'>Percentagem</font> representa uma razão cujo <font color='green'>denominador</font> é igual a <font color='blue'>100</font> e indica uma comparação de uma parte com o todo<font color='#EA8240'>.</font>"));
                    paragrafo2_porcentagem.setText(Html.fromHtml("O símbolo <font color='#EA8240'>%</font> é usado para designar a porcentagem<font color='#EA8240'>.</font> Um valor em porcentagem<font color='#EA8240'>,</font> pode ainda ser expresso na forma de <font color='green'>fração centesimal</font> <font color='#EA8240'>(</font>denominador igual a <font color='blue'>100</font><font color='#EA8240'>)</font> ou como um <font color='green'>número decimal</font><font color='#EA8240'>.</font>"));

                    titulo2_porcentagem.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo3_porcentagem.setText(Html.fromHtml("<font color='blue'>30</font><font color='#EA8240'>%</font> <font color='#EA8240'>=</font> <font color='blue'>30</font><font color='#EA8240'>/</font><font color='blue'>100</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>30</font><font color='#EA8240'>.</font>"));

                    paragrafo4_porcentagem.setText(Html.fromHtml("No caso<font color='#EA8240'>,</font> <font color='blue'>30</font><font color='#EA8240'>%</font> é a representação de um número em porcentagem, <font color='blue'>30</font><font color='#EA8240'>/</font><font color='blue'>100</font> é a representação em fração centesimal e <font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>30</font> é a representação em número decimal<font color='#EA8240'>.</font>"));

                    fonte_porcentagem.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_porcentagem.setText(Html.fromHtml("Introdução"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("A Porcentagem ou Percentagem representa uma razão cujo denominador é igual a 100 e indica uma comparação de uma parte com o todo."));
                    paragrafo2_porcentagem.setText(Html.fromHtml("O símbolo % é usado para designar a porcentagem. Um valor em porcentagem, pode ainda ser expresso na forma de fração centesimal (denominador igual a 100) ou como um número decimal."));


                    titulo2_porcentagem.setText(Html.fromHtml("Exemplo"));
                    paragrafo3_porcentagem.setText(Html.fromHtml("30% = 30/100 = 0,30."));
                    paragrafo4_porcentagem.setText(Html.fromHtml("No caso, 30% é a representação de um número em porcentagem, 30/100 é a representação em fração centesimal e 0,30 é a representação em número decimal."));

                    fonte_porcentagem.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });




        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(introducao_porcentagem.this, selecao_porcentagem.class);
                startActivity(intent);
            }
        });
    }
    }
