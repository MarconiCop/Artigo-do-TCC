package br.com.marconi.discalcmath.Financas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class variacao_financas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_variacao_financas);

        TextView titulo1_financas = (TextView) findViewById(R.id.titulo1_financas);
        TextView titulo2_financas = (TextView) findViewById(R.id.titulo2_financas);
        TextView paragrafo1_financas = (TextView) findViewById(R.id.paragrafo1_financas);
        TextView paragrafo2_financas = (TextView) findViewById(R.id.paragrafo2_financas);
        TextView paragrafo3_financas = (TextView) findViewById(R.id.paragrafo3_financas);
        TextView paragrafo4_financas = (TextView) findViewById(R.id.paragrafo4_financas);
        TextView paragrafo5_financas = (TextView) findViewById(R.id.paragrafo5_financas);

        TextView fonte_financas = (TextView) findViewById(R.id.fonte_financas);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_financas.setText(Html.fromHtml("<font color='red'>Variação Percentual</font>"));
                    paragrafo1_financas.setText(Html.fromHtml("Outro conceito associado ao de <font color='green'>porcentagem</font> é o de <font color='green'>variação percentual</font><font color='#EA8240'>,</font> ou seja<font color='#EA8240'>,</font> a variação das <font color='green'>taxas percentuais</font> de acréscimo ou decréscimo<font color='#EA8240'>.</font>"));

                    titulo2_financas.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo2_financas.setText(Html.fromHtml("No início do mês<font color='#EA8240'>,</font> o preço do quilo da carne era de <font color='blue'>25</font> reais<font color='#EA8240'>.</font> No final do mês a carne era vendida por <font color='blue'>28</font> reais o quilo<font color='#EA8240'>.</font>"));
                    paragrafo3_financas.setText(Html.fromHtml("Assim<font color='#EA8240'>,</font> podemos concluir que houve uma variação percentual relacionada com o aumento desse produto<font color='#EA8240'>.</font> Podemos constatar que o aumento foi de <font color='blue'>3</font> reais. Pela <font color='green'>razão</font> dos valores temos<font color='#EA8240'>:</font>"));
                    paragrafo4_financas.setText(Html.fromHtml("<font color='blue'>3</font><font color='#EA8240'>/</font><font color='blue'>25</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>12</font> <font color='#EA8240'>=</font> <font color='blue'>12</font><font color='#EA8240'>%</font><font color='#EA8240'>.</font>"));
                    paragrafo5_financas.setText(Html.fromHtml("Sendo assim<font color='#EA8240'>,</font> podemos concluir que a variação percentual do preço da carne foi de <font color='blue'>12</font><font color='#EA8240'>%</font><font color='#EA8240'>.</font>"));


                    fonte_financas.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_financas.setText(Html.fromHtml("Variação Percentual"));
                    paragrafo1_financas.setText(Html.fromHtml("Outro conceito associado ao de porcentagem é o de variação percentual, ou seja, a variação das taxas percentuais de acréscimo ou decréscimo."));

                    titulo2_financas.setText("Exemplo");
                    paragrafo2_financas.setText(Html.fromHtml("No início do mês, o preço do quilo da carne era de 25 reais. No final do mês a carne era vendida por 28 reais o quilo."));
                    paragrafo3_financas.setText(Html.fromHtml("Assim, podemos concluir que houve uma variação percentual relacionada com o aumento desse produto. Podemos constatar que o aumento foi de 3 reais. Pela razão dos valores temos:"));
                    paragrafo4_financas.setText(Html.fromHtml("3/25 = 0,12 = 12%."));
                    paragrafo5_financas.setText(Html.fromHtml("Sendo assim, podemos concluir que a variação percentual do preço da carne foi de 12%."));

                    fonte_financas.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });




        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(variacao_financas.this, selecao_matematica_financeira.class);
                startActivity(intent);
            }
        });
    }
}