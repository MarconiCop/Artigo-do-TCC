package br.com.marconi.discalcmath.Estatistica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class desviopadrao_estatistica extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desviopadrao_estatistica);

        TextView titulo1_estatistica = (TextView) findViewById(R.id.titulo1_estatistica);
        TextView titulo2_estatistica = (TextView) findViewById(R.id.titulo2_estatistica);
        TextView paragrafo1_estatistica = (TextView) findViewById(R.id.paragrafo1_estatistica);
        TextView paragrafo2_estatistica = (TextView) findViewById(R.id.paragrafo2_estatistica);
        TextView paragrafo3_estatistica = (TextView) findViewById(R.id.paragrafo3_estatistica);
        TextView paragrafo4_estatistica = (TextView) findViewById(R.id.paragrafo4_estatistica);
        TextView paragrafo5_estatistica = (TextView) findViewById(R.id.paragrafo5_estatistica);
        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_estatistica);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_estatistica.setText(Html.fromHtml("<font color='red'>Desvio Padrão</font>"));
                    paragrafo1_estatistica.setText(Html.fromHtml("O <font color='green'>Desvio Padrão</font> é uma medida que expressa o grau de dispersão de um conjunto de dados<font color='#EA8240'>.</font> Ou seja<font color='#EA8240'>,</font> o desvio padrão indica o quanto um conjunto de dados é uniforme<font color='#EA8240'>.</font> Quanto mais próximo de <font color='blue'>0</font> for o desvio padrão<font color='#EA8240'>,</font> mais homogêneo são os dados<font color='#EA8240'>.</font>"));
                    paragrafo2_estatistica.setText(Html.fromHtml("O desvio padrão <font color='#EA8240'>(</font><font color='green'>DP</font><font color='#EA8240'>)</font> é definido como a <font color='green'>raiz quadrada</font> da variância <font color='#EA8240'>(</font><font color='green'>V</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));

                    titulo2_estatistica.setText(Html.fromHtml("<font color='red'>Variância</font>"));
                    paragrafo3_estatistica.setText(Html.fromHtml("<font color='green'>Variância</font> é uma medida de dispersão e é usada também para expressar o quanto um conjunto de dados se desvia da média<font color='#EA8240'>.</font>"));
                    paragrafo4_estatistica.setText(Html.fromHtml("O cálculo da variância se dá por <font color='green'>V</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='#EA8240'>∑</font><font color='#EA8240'>(</font><font color='green'>xn</font><font color='#EA8240'>-</font><font color='green'>m</font><font color='#EA8240'>)</font><font color='blue'>²</font><font color='#EA8240'>)</font><font color='#EA8240'>/</font><font color='green'>n</font><font color='#EA8240'>,</font> onde <font color='green'>n</font> é a quantidade de dados na qual <font color='green'>x</font> deve percorrer e <font color='green'>m</font> é a média do conjunto<font color='#EA8240'>.</font>"));
                    paragrafo5_estatistica.setText(Html.fromHtml("A vantagem de usar o desvio padrão ao invés da variância é que o desvio padrão é expresso na mesma unidade dos dados<font color='#EA8240'>,</font> o que facilita a comparação<font color='#EA8240'>.</font>"));

                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_estatistica.setText(Html.fromHtml("Desvio Padrão"));
                    paragrafo1_estatistica.setText(Html.fromHtml("O desvio padrão é uma medida que expressa o grau de dispersão de um conjunto de dados. Ou seja, o desvio padrão indica o quanto um conjunto de dados é uniforme. Quanto mais próximo de 0 for o desvio padrão, mais homogêneo são os dados."));
                    paragrafo2_estatistica.setText(Html.fromHtml("O desvio padrão (DP) é definido como a raiz quadrada da variância (V)."));

                    titulo2_estatistica.setText(Html.fromHtml("<font color='red'>Variância</font>"));
                    paragrafo3_estatistica.setText(Html.fromHtml("Variância é uma medida de dispersão e é usada também para expressar o quanto um conjunto de dados se desvia da média."));
                    paragrafo4_estatistica.setText(Html.fromHtml("O cálculo da variância se dá por V = (∑(xn-m)²)/n, onde n é a quantidade de dados na qual x deve percorrer e m é a média do conjunto."));
                    paragrafo5_estatistica.setText(Html.fromHtml("A vantagem de usar o desvio padrão ao invés da variância é que o desvio padrão é expresso na mesma unidade dos dados, o que facilita a comparação."));

                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });


        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(desviopadrao_estatistica.this, selecao_estatistica.class);
                startActivity(intent);
            }
        });
    }
}

