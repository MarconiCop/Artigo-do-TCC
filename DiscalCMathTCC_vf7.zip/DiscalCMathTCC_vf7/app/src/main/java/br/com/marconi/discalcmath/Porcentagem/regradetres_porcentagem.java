package br.com.marconi.discalcmath.Porcentagem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class regradetres_porcentagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regradetres_porcentagem);
        TextView titulo1_porcentagem = (TextView) findViewById(R.id.titulo1_porcentagem);
        TextView titulo2_porcentagem = (TextView) findViewById(R.id.titulo2_porcentagem);
        TextView paragrafo1_porcentagem = (TextView) findViewById(R.id.paragrafo1_porcentagem);
        TextView paragrafo2_porcentagem = (TextView) findViewById(R.id.paragrafo2_porcentagem);
        TextView paragrafo3_porcentagem = (TextView) findViewById(R.id.paragrafo3_porcentagem);

        TextView fonte_porcentagem = (TextView) findViewById(R.id.fonte_porcentagem);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_porcentagem.setText(Html.fromHtml("<font color='red'>Regra de três</font>"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("Como mencionado<font color='#EA8240'>,</font> o cálculo da porcentagem pode ser feito através da <font color='green'>regra de três</font><font color='#EA8240'>.</font>"));

                    titulo2_porcentagem.setText(Html.fromHtml("<font color='red'>Exemplo</font> <font color='#EA8240'>(</font><font color='blue'>30</font><font color='#EA8240'>%</font> de <font color='blue'>90</font><font color='#EA8240'>)</font>"));
                    paragrafo2_porcentagem.setText(Html.fromHtml("Para usar a regra de três no problema<font color='#EA8240'>,</font> vamos considerar que <font color='blue'>90</font> corresponde ao todo<font color='#EA8240'>,</font> ou seja <font color='blue'>100</font><font color='#EA8240'>%</font><font color='#EA8240'>.</font> O valor que queremos encontrar chamaremos de <font color='green'>x</font><font color='#EA8240'>.</font> A regra de três será expressa como <font color='blue'>90</font> está para <font color='blue'>100</font><font color='#EA8240'>%</font> e <font color='green'>x</font> está para <font color='blue'>30</font><font color='#EA8240'>%</font><font color='#EA8240'>:</font>"));
                    paragrafo3_porcentagem.setText(Html.fromHtml("<font color='blue'>100</font><font color='#EA8240'>.</font><font color='green'>x</font> <font color='#EA8240'>=</font> <font color='blue'>30</font><font color='#EA8240'>.</font><font color='blue'>90</font><font color='#EA8240'>,</font> logo <font color='green'>x</font><font color='#EA8240'>=</font><font color='blue'>27</font><font color='#EA8240'>.</font>"));


                    fonte_porcentagem.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_porcentagem.setText(Html.fromHtml("Regra de três"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("Como mencionado, o cálculo da porcentagem pode ser feito através da regra de três."));

                    titulo2_porcentagem.setText(Html.fromHtml("Exemplo (30% de 90)"));
                    paragrafo2_porcentagem.setText(Html.fromHtml("Para usar a regra de três no problema, vamos considerar que 90 corresponde ao todo, ou seja 100%. O valor que queremos encontrar chamaremos de x. A regra de três será expressa como 90 está para 100% e x está para 30%:"));
                    paragrafo3_porcentagem.setText(Html.fromHtml("100.x = 30.90, logo x=27."));



                    fonte_porcentagem.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });




        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(regradetres_porcentagem.this, selecao_porcentagem.class);
                startActivity(intent);
            }
        });
    }
    }
