package br.com.marconi.discalcmath.Financas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import br.com.marconi.discalcmath.Painel.materias_painel;
import br.com.marconi.discalcmath.R;

public class selecao_matematica_financeira extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_matematica_financeira);

        LinearLayout introducao_financas = (LinearLayout) findViewById(R.id.introducao_funcoes);
        LinearLayout variacao_financas = (LinearLayout) findViewById(R.id.variacao_financas);
        LinearLayout juros_financas = (LinearLayout) findViewById(R.id.juros_financas);
        LinearLayout juroscomposto_financas = (LinearLayout) findViewById(R.id.juroscomposto_financas);
        LinearLayout montante_financas = (LinearLayout) findViewById(R.id.montante_financas);
        LinearLayout btAvaliarFinancas = (LinearLayout) findViewById(R.id.btAvaliarFinancas);
        ImageView ImVoltar = (ImageView) findViewById(R.id.ImVoltarFinancas);

        ImVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_matematica_financeira.this, materias_painel.class);
                startActivity(intent);
            }
        });

        introducao_financas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_matematica_financeira.this, br.com.marconi.discalcmath.Financas.introducao_financas.class);
                startActivity(intent);
            }
        });

        variacao_financas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_matematica_financeira.this, br.com.marconi.discalcmath.Financas.variacao_financas.class);
                startActivity(intent);
            }
        });

        juros_financas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_matematica_financeira.this, br.com.marconi.discalcmath.Financas.juros_financas.class);
                startActivity(intent);
            }
        });

        juroscomposto_financas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_matematica_financeira.this, br.com.marconi.discalcmath.Financas.juroscomposto_financas.class);
                startActivity(intent);
            }
        });

        montante_financas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_matematica_financeira.this, br.com.marconi.discalcmath.Financas.montante_financas.class);
                startActivity(intent);
            }
        });

        btAvaliarFinancas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_matematica_financeira.this, avaliar_financas.class);
                startActivity(intent);
            }
        });


    }
}