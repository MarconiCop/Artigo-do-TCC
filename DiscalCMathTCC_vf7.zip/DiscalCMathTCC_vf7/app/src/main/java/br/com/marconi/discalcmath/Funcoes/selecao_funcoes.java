package br.com.marconi.discalcmath.Funcoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import br.com.marconi.discalcmath.Painel.materias_painel;
import br.com.marconi.discalcmath.R;

public class selecao_funcoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_funcoes);

        LinearLayout introducao_funcoes = (LinearLayout) findViewById(R.id.introducao_funcoes);
        LinearLayout primeiro_grau_funcoes = (LinearLayout) findViewById(R.id.primeiro_grau_funcoes);
        LinearLayout exponencial_funcoes = (LinearLayout) findViewById(R.id.exponencial_funcoes);
        LinearLayout logaritmo_funcoes = (LinearLayout) findViewById(R.id.logaritmo_funcoes);
        LinearLayout segundo_grau_funcoes = (LinearLayout) findViewById(R.id.segundo_grau_funcoes);
        LinearLayout btAvaliarFuncoes = (LinearLayout) findViewById(R.id.btAvaliarFuncoes);
        ImageView ImVoltar = (ImageView) findViewById(R.id.imVoltarFuncoes);

        ImVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_funcoes.this, materias_painel.class);
                startActivity(intent);
            }
        });


        introducao_funcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_funcoes.this, introducao_funcoes.class);
                startActivity(intent);
            }
        });

        primeiro_grau_funcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_funcoes.this, primeiro_grau_funcoes.class);
                startActivity(intent);
            }
        });

        exponencial_funcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_funcoes.this, exponencial_funcoes.class);
                startActivity(intent);
            }
        });

        logaritmo_funcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_funcoes.this, logaritmo_funcoes.class);
                startActivity(intent);
            }
        });

        segundo_grau_funcoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_funcoes.this, segundo_grau_funcoes.class);
                startActivity(intent);
            }
        });

        btAvaliarFuncoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_funcoes.this, avaliar_funcoes.class);
                startActivity(intent);
            }
        });
    }
}