package br.com.marconi.discalcmath.Grandezas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class indireta_grandezas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_indireta_grandezas);

        TextView titulo1_grandezas = (TextView) findViewById(R.id.titulo1_grandezas);
        TextView titulo2_grandezas = (TextView) findViewById(R.id.titulo2_grandezas);
        TextView paragrafo1_grandezas = (TextView) findViewById(R.id.paragrafo1_grandezas);
        TextView paragrafo2_grandezas = (TextView) findViewById(R.id.paragrafo2_grandezas);
        TextView paragrafo3_grandezas = (TextView) findViewById(R.id.paragrafo3_grandezas);
        TextView paragrafo4_grandezas = (TextView) findViewById(R.id.paragrafo4_grandezas);
        TextView paragrafo5_grandezas = (TextView) findViewById(R.id.paragrafo5_grandezas);
        TextView paragrafo6_grandezas = (TextView) findViewById(R.id.paragrafo6_grandezas);

        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_grandezas);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_grandezas.setText(Html.fromHtml("<font color='red'>Proporção Indireta</font>"));
                    paragrafo1_grandezas.setText(Html.fromHtml("Duas grandezas são <font color='green'>inversamente proporcionais</font> quando o aumento de uma implica na redução da outra<font color='#EA8240'>,</font> ou seja<font color='#EA8240'>,</font> dobrando uma grandeza<font color='#EA8240'>,</font> a correspondente reduz pela metade<font color='#EA8240'>;</font> triplicando uma grandeza<font color='#EA8240'>,</font> a outra reduz para terça parte<font color='#EA8240'>...</font> e assim por diante<font color='#EA8240'>.</font>"));
                    paragrafo2_grandezas.setText(Html.fromHtml("Graficamente a variação inversamente proporcional de uma grandeza em relação à outra forma uma <font color='green'>hipérbole</font><font color='#EA8240'>,</font> pois temos <font color='green'>y</font> <font color='#EA8240'>=</font> <font color='green'>k</font><font color='#EA8240'>/</font><font color='green'>x</font><font color='#EA8240'>,</font> sendo <font color='green'>k</font> uma <font color='green'>constante</font><font color='#EA8240'>.</font>"));

                    titulo2_grandezas.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo3_grandezas.setText(Html.fromHtml("João decidiu contar o tempo que levava indo de casa à escola de bicicleta com diferentes velocidades<font color='#EA8240'>.</font> <font color='blue'>2</font> <font color='green'>minutos</font> em <font color='blue'>30</font> <font color='green'>metros por segundo</font><font color='#EA8240'>,</font> <font color='blue'>4</font> <font color='green'>minutos</font> em <font color='blue'>15</font> <font color='green'>metros por segundo</font><font color='#EA8240'>,</font> <font color='blue'>5</font> <font color='green'>minutos</font> em <font color='blue'>12</font> <font color='green'>metros por segundo</font> e <font color='blue'>1</font> <font color='green'>minuto</font> em <font color='blue'>60</font> <font color='green'>metros por segundo</font><font color='#EA8240'>.</font> "));
                    paragrafo4_grandezas.setText(Html.fromHtml("<font color='blue'>2</font><font color='#EA8240'>.</font><font color='blue'>30</font> <font color='#EA8240'>=</font> <font color='blue'>4</font><font color='#EA8240'>.</font><font color='blue'>15</font> <font color='#EA8240'>=</font> <font color='blue'>5</font><font color='#EA8240'>.</font><font color='blue'>12</font> <font color='#EA8240'>=</font> <font color='blue'>1</font><font color='#EA8240'>.</font><font color='blue'>60</font><font color='#EA8240'>.</font>"));
                    paragrafo5_grandezas.setText(Html.fromHtml("Observe que quando um número de uma sequência dobra<font color='#EA8240'>,</font> o número da sequência correspondente reduz pela metade<font color='#EA8240'>.</font>"));
                    paragrafo6_grandezas.setText(Html.fromHtml("Nesse exemplo<font color='#EA8240'>,</font> a <font color='green'>sequência de tempo</font> <font color='#EA8240'>(</font><font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>,</font> <font color='blue'>5</font> e <font color='blue'>1</font><font color='#EA8240'>)</font> é inversamente proporcional à <font color='green'>velocidade média</font> pedalando <font color='#EA8240'>(</font><font color='blue'>30</font><font color='#EA8240'>,</font> <font color='blue'>15</font><font color='#EA8240'>,</font> <font color='blue'>12</font> e <font color='blue'>60</font><font color='#EA8240'>)</font> e a <font color='green'>constante de proporcionalidade</font> <font color='#EA8240'>(</font><font color='green'>k</font><font color='#EA8240'>)</font> entre essas grandezas é <font color='blue'>60</font><font color='#EA8240'>.</font>"));

                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_grandezas.setText(Html.fromHtml("Proporção Direta"));
                    paragrafo1_grandezas.setText(Html.fromHtml("Duas grandezas são inversamente proporcionais quando o aumento de uma implica na redução da outra, ou seja, dobrando uma grandeza, a correspondente reduz pela metade; triplicando uma grandeza, a outra reduz para terça parte... e assim por diante."));
                    paragrafo2_grandezas.setText(Html.fromHtml("Graficamente a variação inversamente proporcional de uma grandeza em relação à outra forma uma hipérbole, pois temos y = k/x, sendo k uma constante."));

                    titulo2_grandezas.setText(Html.fromHtml("Exemplo"));
                    paragrafo3_grandezas.setText(Html.fromHtml("João decidiu contar o tempo que levava indo de casa à escola de bicicleta com diferentes velocidades. 2 minutos em 30 metros por segundo, 4 minutos em 15 metros por segundo, 5 minutos em 12 metros por segundo e 1 minuto em 60 metros por segundo. "));
                    paragrafo4_grandezas.setText(Html.fromHtml("2.30 = 4.15 = 5.12 = 1.60."));
                    paragrafo5_grandezas.setText(Html.fromHtml("Observe que quando um número de uma sequência dobra, o número da sequência correspondente reduz pela metade."));
                    paragrafo6_grandezas.setText(Html.fromHtml("Nesse exemplo, a sequência de tempo (2, 4, 5 e 1) é inversamente proporcional à velocidade média pedalando (30, 15, 12 e 60) e a constante de proporcionalidade (k) entre essas grandezas é 60."));

                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });




        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(indireta_grandezas.this, selecao_grandezas_proporcionais.class);
                startActivity(intent);
            }
        });
    }
}
