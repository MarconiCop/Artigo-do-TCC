package br.com.marconi.discalcmath.Jogo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.Fragmentos.HomeFragment;
import br.com.marconi.discalcmath.Painel.Painel;

import br.com.marconi.discalcmath.Perfil.ExibirPerfil;
import br.com.marconi.discalcmath.Perfil.Perfil;
import br.com.marconi.discalcmath.R;
import br.com.marconi.discalcmath.databinding.ActivityQuizBinding;

import me.ibrahimsn.lib.OnItemSelectedListener;

public class MenuQuiz extends AppCompatActivity {

    ActivityQuizBinding binding;
    Usuario usuario;
    FirebaseFirestore db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityQuizBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());


        db = FirebaseFirestore.getInstance();

        db.collection("usuarios")
                .document(FirebaseAuth.getInstance().getUid())
                .get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                usuario = documentSnapshot.toObject(Usuario.class);
              if(usuario.getUrl()==null){
                  Intent intent = new Intent(MenuQuiz.this, Perfil.class);
                  startActivity(intent);
              }
            }});















        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.conteudo, new HomeFragment());
        transaction.commit();

       binding.imVoltarQuestoes.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(MenuQuiz.this, Painel.class);
               startActivity(intent);
           }
       });


        binding.bottomBar.setOnItemSelectedListener(new OnItemSelectedListener() {
            @Override
            public boolean onItemSelect(int i) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                switch (i) {
                    case 0:
                        transaction.replace(R.id.conteudo, new HomeFragment());
                        transaction.commit();
                        break;
                    case 1:
                        transaction.replace(R.id.conteudo, new Placar());
                        transaction.commit();
                        break;
                    case 2:
                        transaction.replace(R.id.conteudo, new Niveis());
                        transaction.commit();
                        break;
                }
                return false;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.home_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.wallet) {
            Toast.makeText(this, "Carteira foi selecionada", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }
}