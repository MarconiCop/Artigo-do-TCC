package br.com.marconi.discalcmath.Equacoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class grau_equacoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grau_equacoes);

        TextView titulo1_equacoes = (TextView) findViewById(R.id.titulo1_equacoes);
        TextView titulo2_equacoes = (TextView) findViewById(R.id.titulo2_equacoes);
        TextView paragrafo1_equacoes = (TextView) findViewById(R.id.paragrafo1_equacoes);
        TextView paragrafo2_equacoes = (TextView) findViewById(R.id.paragrafo2_equacoes);
        TextView paragrafo3_equacoes = (TextView) findViewById(R.id.paragrafo3_equacoes);
        TextView fonte_equacoes = (TextView) findViewById(R.id.fonte_equacoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw_modo_discalculia.isChecked() == true) {
                    titulo1_equacoes.setText(Html.fromHtml("<font color='red'>Grau</font>"));
                    titulo2_equacoes.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo1_equacoes.setText(Html.fromHtml("O <font color='green'>grau</font> de uma equação está relacionado com a quantidade de <font color='green'>incógnitas</font> que ela possui<font color='#EA8240'>.</font> Dizemos que uma equação é de <font color='green'>grau</font> <font color='blue'>1</font> quando o maior <font color='green'>expoente</font> das suas incógnitas é <font color='blue'>1</font><font color='#EA8240'>.</font> Uma equação possui <font color='green'>grau</font> <font color='blue'>2</font> quando o maior <font color='green'>expoente</font> das suas incógnitas é <font color='blue'>2</font> e assim por diante<font color='#EA8240'>.</font>"));
                    paragrafo2_equacoes.setText(Html.fromHtml("O grau também pode ser dado pelo <font color='green'>produto</font> de incógnitas diferentes<font color='#EA8240'>.</font> Por exemplo<font color='#EA8240'>:</font> a equação <font color='green'>xy</font> <font color='#EA8240'>+</font> <font color='blue'>2</font> <font color='#EA8240'>=</font> <font color='green'>y</font> é uma equação de grau <font color='blue'>2</font> porque possui um produto entre duas incógnitas de expoente <font color='blue'>1</font><font color='#EA8240'>.</font>"));
                    paragrafo3_equacoes.setText(Html.fromHtml("O grau de uma equação determina quantas <font color='green'>soluções</font> a equação possui<font color='#EA8240'>.</font> Desse modo<font color='#EA8240'>,</font> uma equação de grau <font color='blue'>1</font> possui apenas <font color='blue'>1</font> resultado <font color='#EA8240'>(</font>um valor possível para a incógnita<font color='#EA8240'>)</font><font color='#EA8240'>;</font> uma equação de grau <font color='blue'>2</font> possui dois resultados e assim sucessivamente<font color='#EA8240'>.</font>"));
                    fonte_equacoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Brasil Escola<font color='#EA8240'>.</font>"));
                }
                if (sw_modo_discalculia.isChecked() == false) {
                    titulo1_equacoes.setText(Html.fromHtml("Grau"));
                    titulo2_equacoes.setText(Html.fromHtml("Exemplo"));
                    paragrafo1_equacoes.setText(Html.fromHtml("O grau de uma equação está relacionado com a quantidade de incógnitas que ela possui. Dizemos que uma equação é de grau 1 quando o maior expoente das suas incógnitas é 1. Uma equação possui grau 2 quando o maior expoente das suas incógnitas é 2 e assim por diante."));
                    paragrafo2_equacoes.setText(Html.fromHtml("O grau também pode ser dado pelo produto de incógnitas diferentes. Por exemplo: a equação xy + 2 = y é uma equação de grau 2 porque possui um produto entre duas incógnitas de expoente 1."));
                    paragrafo3_equacoes.setText(Html.fromHtml("O grau de uma equação determina quantas soluções a equação possui. Desse modo, uma equação de grau 1 possui apenas 1 resultado (um valor possível para a incógnita); uma equação de grau 2 possui dois resultados e assim sucessivamente."));
                    fonte_equacoes.setText(Html.fromHtml("Fonte: Brasil Escola."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(grau_equacoes.this, selecao_equacoes.class);
                startActivity(intent);
            }
        });
    }
}
