package br.com.marconi.discalcmath.Estatistica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class media_estatistica extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_estatistica);

        TextView titulo1_estatistica = (TextView) findViewById(R.id.titulo1_estatistica);
        TextView titulo2_estatistica = (TextView) findViewById(R.id.titulo2_estatistica);
        TextView titulo3_estatistica = (TextView) findViewById(R.id.titulo3_estatistica);
        TextView paragrafo1_estatistica = (TextView) findViewById(R.id.paragrafo1_estatistica);
        TextView paragrafo2_estatistica = (TextView) findViewById(R.id.paragrafo2_estatistica);
        TextView paragrafo3_estatistica = (TextView) findViewById(R.id.paragrafo3_estatistica);
        TextView paragrafo4_estatistica = (TextView) findViewById(R.id.paragrafo4_estatistica);
        TextView paragrafo5_estatistica = (TextView) findViewById(R.id.paragrafo5_estatistica);
        TextView paragrafo6_estatistica = (TextView) findViewById(R.id.paragrafo6_estatistica);
        TextView paragrafo7_estatistica = (TextView) findViewById(R.id.paragrafo7_estatistica);
        TextView paragrafo8_estatistica = (TextView) findViewById(R.id.paragrafo8_estatistica);
        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_estatistica);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_estatistica.setText(Html.fromHtml("<font color='red'>Média</font>"));
                    paragrafo1_estatistica.setText(Html.fromHtml("A <font color='green'>Média aritmética</font> de um conjunto de dados é obtida somando todos os valores e dividindo o valor encontrado pelo número de dados desse conjunto<font color='#EA8240'>.</font>"));
                    paragrafo2_estatistica.setText(Html.fromHtml("É muito utilizada em <font color='green'>estatística</font> como uma medida de tendência central<font color='#EA8240'>.</font>"));
                    paragrafo3_estatistica.setText(Html.fromHtml("Pode ser <font color='green'>simples</font><font color='#EA8240'>,</font> onde todos os valores possuem a mesma importância<font color='#EA8240'>,</font> ou <font color='green'>ponderada</font><font color='#EA8240'>,</font> quando considera <font color='green'>pesos</font> diferentes aos dados<font color='#EA8240'>.</font>"));


                    titulo2_estatistica.setText(Html.fromHtml("<font color='red'>Média Simples</font>"));
                    paragrafo4_estatistica.setText(Html.fromHtml("Esse tipo de média funciona de forma mais adequada quando os valores são relativamente uniformes<font color='#EA8240'>.</font>"));
                    paragrafo5_estatistica.setText(Html.fromHtml("Por ser sensível aos dados<font color='#EA8240'>,</font> nem sempre fornece os resultados mais adequados<font color='#EA8240'>.</font> Isso porque todos os dados possuem a mesma importância <font color='#EA8240'>(</font>peso<font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo6_estatistica.setText(Html.fromHtml("A fórmula é <font color='green'>M</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='blue'>1</font> <font color='#EA8240'>+</font> <font color='green'>x</font><font color='blue'>2</font> <font color='#EA8240'>+</font> <font color='green'>x</font><font color='blue'>3</font> <font color='#EA8240'>+</font> <font color='#EA8240'>.</font><font color='#EA8240'>.</font><font color='#EA8240'>.</font> <font color='#EA8240'>+</font> <font color='green'>xn</font><font color='#EA8240'>)</font><font color='#EA8240'>/</font><font color='#EA8240'>n</font> na qual <font color='green'>M</font> é a média<font color='#EA8240'>,</font> todo <font color='green'>x</font> é um valor dos dados e <font color='green'>n</font> é o número de dados<font color='#EA8240'>.</font> "));

                    titulo3_estatistica.setText(Html.fromHtml("<font color='red'>Média Ponderada</font>"));
                    paragrafo7_estatistica.setText(Html.fromHtml("A <font color='green'>média aritmética ponderada</font> é calculada multiplicando cada valor do conjunto de dados pelo seu peso<font color='#EA8240'>.</font> Depois<font color='#EA8240'>,</font> encontra-se a soma desses valores que será dividida pela soma dos pesos<font color='#EA8240'>.</font>"));
                    paragrafo8_estatistica.setText(Html.fromHtml("A fórmula é <font color='green'>M</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='green'>p</font><font color='blue'>1</font><font color='green'>x</font><font color='blue'>1</font> <font color='#EA8240'>+</font> <font color='green'>p</font><font color='blue'>2</font><font color='green'>x</font><font color='blue'>2</font> <font color='#EA8240'>+</font> <font color='green'>p</font><font color='blue'>3</font><font color='green'>x</font><font color='blue'>3</font> <font color='#EA8240'>+</font> <font color='#EA8240'>.</font><font color='#EA8240'>.</font><font color='#EA8240'>.</font> <font color='#EA8240'>+</font> <font color='green'>pnxn</font><font color='#EA8240'>)</font><font color='#EA8240'>/</font><font color='green'>p</font><font color='blue'>1</font> <font color='#EA8240'>+</font> <font color='green'>p</font><font color='blue'>2</font> <font color='#EA8240'>+</font> <font color='#EA8240'>.</font><font color='#EA8240'>.</font><font color='#EA8240'>.</font> <font color='#EA8240'>+</font> <font color='green'>pn</font><font color='#EA8240'>,</font> na qual <font color='green'>M</font> é a média<font color='#EA8240'>,</font> todo <font color='green'>x</font> é um valor dos dados e <font color='green'>p</font> é o peso dos dados<font color='#EA8240'>.</font>"));

                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));



                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_estatistica.setText(Html.fromHtml("Média"));
                    paragrafo1_estatistica.setText(Html.fromHtml("A Média aritmética de um conjunto de dados é obtida somando todos os valores e dividindo o valor encontrado pelo número de dados desse conjunto."));
                    paragrafo2_estatistica.setText(Html.fromHtml("É muito utilizada em estatística como uma medida de tendência central."));
                    paragrafo3_estatistica.setText(Html.fromHtml("Pode ser simples, onde todos os valores possuem a mesma importância, ou ponderada, quando considera pesos diferentes aos dados."));

                    titulo2_estatistica.setText(Html.fromHtml("Média Simples"));
                    paragrafo4_estatistica.setText(Html.fromHtml("Esse tipo de média funciona de forma mais adequada quando os valores são relativamente uniformes."));
                    paragrafo5_estatistica.setText(Html.fromHtml("Por ser sensível aos dados, nem sempre fornece os resultados mais adequados. Isso porque todos os dados possuem a mesma importância (peso)."));
                    paragrafo6_estatistica.setText(Html.fromHtml("A fórmula é M = (x1 + x2 + x3 + ... +xn)/n, na qual M é a média, todo x é um valor dos dados e n é o número de dados."));


                    titulo3_estatistica.setText(Html.fromHtml("Média Ponderada"));
                    paragrafo7_estatistica.setText(Html.fromHtml("A média aritmética ponderada é calculada multiplicando cada valor do conjunto de dados pelo seu peso. Depois, encontra-se a soma desses valores que será dividida pela soma dos pesos."));
                    paragrafo8_estatistica.setText(Html.fromHtml("A fórmula é M= (p1x1 + p2x2 + p3x3 + ... +pNxN)/p1 + p2 + ... + pn, na qual M é a média, todo x é um valor dos dados e p é o peso dos dados "));

                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }





            }
        });










        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(media_estatistica.this, selecao_estatistica.class);
                startActivity(intent);
            }
        });
    }
}