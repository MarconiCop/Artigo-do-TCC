package br.com.marconi.discalcmath.Funcoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class primeiro_grau_funcoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_primeiro_grau_funcoes);

        TextView titulo1_funcoes = (TextView) findViewById(R.id.titulo1_funcoes);
        TextView titulo2_funcoes = (TextView) findViewById(R.id.titulo2_funcoes);
        TextView titulo3_funcoes = (TextView) findViewById(R.id.titulo3_funcoes);
        TextView titulo4_funcoes = (TextView) findViewById(R.id.titulo3_funcoes);
        TextView paragrafo1_funcoes = (TextView) findViewById(R.id.paragrafo1_funcoes);
        TextView paragrafo2_funcoes = (TextView) findViewById(R.id.paragrafo2_funcoes);
        TextView paragrafo3_funcoes = (TextView) findViewById(R.id.paragrafo3_funcoes);
        TextView paragrafo4_funcoes = (TextView) findViewById(R.id.paragrafo4_funcoes);
        TextView paragrafo5_funcoes = (TextView) findViewById(R.id.paragrafo5_funcoes);
        TextView paragrafo6_funcoes = (TextView) findViewById(R.id.paragrafo6_funcoes);
        TextView paragrafo7_funcoes = (TextView) findViewById(R.id.paragrafo7_funcoes);
        TextView paragrafo8_funcoes = (TextView) findViewById(R.id.paragrafo8_funcoes);
        TextView paragrafo9_funcoes = (TextView) findViewById(R.id.paragrafo9_funcoes);
        TextView paragrafo10_funcoes = (TextView) findViewById(R.id.paragrafo10_funcoes);
        TextView fonte_funcoes = (TextView) findViewById(R.id.fonte_funcoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_funcoes.setText(Html.fromHtml("<font color='red'>Função do 1º grau</font>"));
                    titulo2_funcoes.setText(Html.fromHtml("<font color='red'>Gráfico de uma Função do 1º grau</font>"));
                    titulo3_funcoes.setText(Html.fromHtml("<font color='red'>Coeficiente Linear e Angular</font>"));
                    titulo4_funcoes.setText(Html.fromHtml("<font color='red'>Função Crescente e Decrescente</font>"));
                    paragrafo1_funcoes.setText(Html.fromHtml("A <font color='green'>função afim</font><font color='#EA8240'>,</font> também chamada de <font color='green'>função do 1º grau</font><font color='#EA8240'>,</font> é uma função <font color='green'>f</font> <font color='#EA8240'>:</font> <font color='green'>ℝ</font> <font color='#EA8240'>→</font><font color='green'>ℝ</font><font color='#EA8240'>,</font> definida como <font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='green'>ax</font> <font color='#EA8240'>+</font> <font color='green'>b</font><font color='#EA8240'>,</font> sendo <font color='green'>a</font> e <font color='green'>b</font> números reais<font color='#EA8240'>.</font> As funções <font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='green'>x</font> <font color='#EA8240'>+</font> <font color='blue'>5</font><font color='#EA8240'>,</font> <font color='green'>g</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='blue'>3</font><font color='#EA8240'>√</font><font color='blue'>3</font><font color='green'>x</font> <font color='#EA8240'>-</font> <font color='blue'>8</font> e <font color='green'>h</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='blue'>1</font><font color='#EA8240'>/</font><font color='blue'>2</font> <font color='green'>x</font> são exemplos de funções afim<font color='#EA8240'>.</font>"));
                    paragrafo2_funcoes.setText(Html.fromHtml("Neste tipo de função<font color='#EA8240'>,</font> o número <font color='green'>a</font> é chamado de <font color='green'>coeficiente de x</font> e representa a <font color='green'>taxa de crescimento</font> ou <font color='green'>taxa de variação</font> da função<font color='#EA8240'>.</font> Já o número <font color='green'>b</font> é chamado de <font color='green'>termo constante</font><font color='#EA8240'>.</font>"));
                    paragrafo3_funcoes.setText(Html.fromHtml("O gráfico de uma função polinomial do 1º grau é uma <font color='green'>reta oblíqua</font> aos eixos <font color='green'>Ox</font> e <font color='green'>Oy</font><font color='#EA8240'>.</font> Desta forma<font color='#EA8240'>,</font> para construirmos seu gráfico basta encontrarmos pontos que satisfaçam a função<font color='#EA8240'>.</font>"));
                    paragrafo4_funcoes.setText(Html.fromHtml("Para facilitar os cálculos podemos<font color='#EA8240'>,</font> por exemplo<font color='#EA8240'>,</font> escolher os pontos <font color='#EA8240'>(</font><font color='blue'>0</font><font color='#EA8240'>,</font><font color='green'>y</font><font color='#EA8240'>)</font> e <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>,</font><font color='blue'>0</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font> Nestes pontos<font color='#EA8240'>,</font> a reta da função corta o eixo <font color='green'>Ox</font> e <font color='green'>Oy</font> respectivamente<font color='#EA8240'>.</font>"));
                    paragrafo5_funcoes.setText(Html.fromHtml("Como o gráfico de uma função afim é uma reta<font color='#EA8240'>,</font> o <font color='green'>coeficiente a de x</font> é também chamado de <font color='green'>coeficiente angular</font><font color='#EA8240'>.</font> Esse valor representa a <font color='green'>inclinação</font> da reta em relação ao eixo <font color='green'>Ox</font><font color='#EA8240'>.</font> O termo constante <font color='green'>b</font> é chamado de <font color='green'>coeficiente linear</font> e representa o <font color='green'>ponto</font> onde a reta corta o eixo <font color='green'>Oy</font><font color='#EA8240'>.</font> Pois sendo <font color='green'>x</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>,</font> temos<font color='#EA8240'>:</font>"));
                    paragrafo6_funcoes.setText(Html.fromHtml("<font color='green'>y</font> <font color='#EA8240'>=</font> <font color='green'>a</font><font color='#EA8240'>.</font><font color='blue'>0</font> <font color='#EA8240'>+</font> <font color='green'>b</font> <font color='#EA8240'>⇒</font> <font color='green'>y</font> <font color='#EA8240'>=</font> <font color='green'>b</font>"));
                    paragrafo7_funcoes.setText(Html.fromHtml("Quando uma função afim apresentar o coeficiente angular igual a zero <font color='#EA8240'>(</font><font color='green'>a</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>)</font> a função será chamada de <font color='green'>constante</font><font color='#EA8240'>.</font> Neste caso<font color='#EA8240'>,</font> o seu gráfico será uma <font color='green'>reta paralela</font> ao eixo <font color='green'>Ox</font><font color='#EA8240'>.</font>"));
                    paragrafo8_funcoes.setText(Html.fromHtml("Temos ainda que<font color='#EA8240'>,</font> quando o coeficiente linear é igual a zero <font color='#EA8240'>(</font><font color='green'>b</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>)</font><font color='#EA8240'>,</font> a função afim é chamada de <font color='green'>função linear</font><font color='#EA8240'>.</font> Por exemplo as funções <font color='green'>f</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='blue'>2</font><font color='green'>x</font> e <font color='green'>g</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='#EA8240'>-</font> <font color='blue'>3</font><font color='green'>x</font> são funções lineares<font color='#EA8240'>.</font> O gráfico das funções lineares são <font color='green'>retas inclinadas</font> que passam pela <font color='green'>origem</font> <font color='#EA8240'>(</font><font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>0</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo9_funcoes.setText(Html.fromHtml("Uma função é <font color='green'>crescente</font> quando ao atribuirmos valores cada vez maiores para <font color='green'>x</font><font color='#EA8240'>,</font> o resultado da <font color='green'>f</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> será também cada vez maior<font color='#EA8240'>.</font> Já a função <font color='green'>decrescente</font> é aquela que ao atribuirmos valores cada vez maiores para <font color='green'>x</font><font color='#EA8240'>,</font> o resultado da <font color='green'>f</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> será cada vez menor<font color='#EA8240'>.</font>"));
                    paragrafo10_funcoes.setText(Html.fromHtml("Para identificar se uma função afim é crescente ou decrescente<font color='#EA8240'>,</font> basta verificar o valor do seu coeficiente angular<font color='#EA8240'>.</font> Se o coeficiente angular for <font color='green'>positivo</font><font color='#EA8240'>,</font> ou seja<font color='#EA8240'>,</font> <font color='green'>a</font> é maior que zero<font color='#EA8240'>,</font> a função será crescente<font color='#EA8240'>.</font> Ao contrário<font color='#EA8240'>,</font> se <font color='green'>a</font> for <font color='green'>negativo</font><font color='#EA8240'>,</font> a função será decrescente<font color='#EA8240'>.</font>"));
                    fonte_funcoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_funcoes.setText(Html.fromHtml("Função do 1º grau"));
                    titulo2_funcoes.setText(Html.fromHtml("Gráfico de uma Função do 1º grau"));
                    titulo3_funcoes.setText(Html.fromHtml("Coeficiente Linear e Angular"));
                    titulo4_funcoes.setText(Html.fromHtml("Função Crescente e Decrescente"));
                    paragrafo1_funcoes.setText(Html.fromHtml("A função afim, também chamada de função do 1º grau, é uma função f : ℝ→ℝ, definida como f(x) = ax + b, sendo a e b números reais. As funções f(x) = x + 5, g(x) = 3√3x - 8 e h(x) = 1/2 x são exemplos de funções afim."));
                    paragrafo2_funcoes.setText(Html.fromHtml("Neste tipo de função, o número a é chamado de coeficiente de x e representa a taxa de crescimento ou taxa de variação da função. Já o número b é chamado de termo constante."));
                    paragrafo3_funcoes.setText(Html.fromHtml("O gráfico de uma função polinomial do 1º grau é uma reta oblíqua aos eixos Ox e Oy. Desta forma, para construirmos seu gráfico basta encontrarmos pontos que satisfaçam a função."));
                    paragrafo4_funcoes.setText(Html.fromHtml("Para facilitar os cálculos podemos, por exemplo, escolher os pontos (0,y) e (x,0). Nestes pontos, a reta da função corta o eixo Ox e Oy respectivamente."));
                    paragrafo5_funcoes.setText(Html.fromHtml("Como o gráfico de uma função afim é uma reta, o coeficiente a de x é também chamado de coeficiente angular. Esse valor representa a inclinação da reta em relação ao eixo Ox. O termo constante b é chamado de coeficiente linear e representa o ponto onde a reta corta o eixo Oy. Pois sendo x = 0, temos:"));
                    paragrafo6_funcoes.setText(Html.fromHtml("y = a.0 + b ⇒ y = b"));
                    paragrafo7_funcoes.setText(Html.fromHtml("Quando uma função afim apresentar o coeficiente angular igual a zero (a = 0) a função será chamada de constante. Neste caso, o seu gráfico será uma reta paralela ao eixo Ox."));
                    paragrafo8_funcoes.setText(Html.fromHtml("Temos ainda que, quando o coeficiente linear é igual a zero (b = 0), a função afim é chamada de função linear. Por exemplo as funções f (x) = 2x e g (x) = - 3x são funções lineares. O gráfico das funções lineares são retas inclinadas que passam pela origem (0,0)."));
                    paragrafo9_funcoes.setText(Html.fromHtml("Uma função é crescente quando ao atribuirmos valores cada vez maiores para x, o resultado da f (x) será também cada vez maior. Já a função decrescente é aquela que ao atribuirmos valores cada vez maiores para x, o resultado da f (x) será cada vez menor."));
                    paragrafo10_funcoes.setText(Html.fromHtml("Para identificar se uma função afim é crescente ou decrescente, basta verificar o valor do seu coeficiente angular. Se o coeficiente angular for positivo, ou seja, a é maior que zero, a função será crescente. Ao contrário, se a for negativo, a função será decrescente."));
                    fonte_funcoes.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(primeiro_grau_funcoes.this, selecao_funcoes.class);
                startActivity(intent);
            }
        });
    }
}