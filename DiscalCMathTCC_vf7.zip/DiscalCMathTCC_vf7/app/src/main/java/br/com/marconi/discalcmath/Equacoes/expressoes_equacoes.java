package br.com.marconi.discalcmath.Equacoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class expressoes_equacoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_expressoes_equacoes);

        TextView titulo1_equacoes = (TextView) findViewById(R.id.titulo1_equacoes);
        TextView titulo2_equacoes = (TextView) findViewById(R.id.titulo2_equacoes);
        TextView paragrafo1_equacoes = (TextView) findViewById(R.id.paragrafo1_equacoes);
        TextView paragrafo2_equacoes = (TextView) findViewById(R.id.paragrafo2_equacoes);
        TextView paragrafo3_equacoes = (TextView) findViewById(R.id.paragrafo3_equacoes);
        TextView paragrafo4_equacoes = (TextView) findViewById(R.id.paragrafo4_equacoes);
        TextView paragrafo5_equacoes = (TextView) findViewById(R.id.paragrafo5_equacoes);
        TextView paragrafo6_equacoes = (TextView) findViewById(R.id.paragrafo6_equacoes);

        TextView fonte_equacoes = (TextView) findViewById(R.id.fonte_equacoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw_modo_discalculia.isChecked() == true) {
                    titulo1_equacoes.setText(Html.fromHtml("<font color='red'>Expressões Algébricas</font>"));
                    titulo2_equacoes.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo1_equacoes.setText(Html.fromHtml("<font color='green'>Expressões Algébricas</font> são um conjunto de <font color='green'>operações</font> matemáticas básicas aplicadas a números conhecidos e a números desconhecidos<font color='#EA8240'>.</font> Para representar esses números desconhecidos<font color='#EA8240'>,</font> são utilizadas <font color='green'>letras</font><font color='#EA8240'>.</font>"));
                    paragrafo2_equacoes.setText(Html.fromHtml("É mais comum utilizar as letras <font color='green'>x</font> e <font color='green'>y</font><font color='#EA8240'>,</font> mas isso não significa que elas são as únicas<font color='#EA8240'>.</font> Em alguns casos<font color='#EA8240'>,</font> são utilizadas letras do alfabeto grego e até símbolos diversos<font color='#EA8240'>.</font>"));
                    paragrafo3_equacoes.setText(Html.fromHtml("<font color='blue'>1</font><font color='#EA8240'>)</font> <font color='blue'>12</font><font color='green'>x</font><font color='blue'>²</font> <font color='#EA8240'>+</font> <font color='blue'>16</font><font color='green'>y</font> <font color='#EA8240'>+</font> <font color='blue'>4</font><font color='green'>ab</font>"));
                    paragrafo4_equacoes.setText(Html.fromHtml("<font color='blue'>2</font><font color='#EA8240'>)</font> <font color='green'>x</font> <font color='#EA8240'>+</font> <font color='green'>y</font>"));
                    paragrafo5_equacoes.setText(Html.fromHtml("<font color='blue'>3</font><font color='#EA8240'>)</font> <font color='blue'>4</font> <font color='#EA8240'>+</font> <font color='blue'>7</font><font color='green'>a</font>"));
                    paragrafo6_equacoes.setText(Html.fromHtml("Todas essas expressões possuem letras representando números e números sendo somados e multiplicados<font color='#EA8240'>.</font>"));
                    fonte_equacoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Brasil Escola<font color='#EA8240'>.</font>"));
                }
                if (sw_modo_discalculia.isChecked() == false) {
                    titulo1_equacoes.setText(Html.fromHtml("Expressões Algébricas"));
                    titulo2_equacoes.setText(Html.fromHtml("Exemplo"));
                    paragrafo1_equacoes.setText(Html.fromHtml("Expressões algébricas são um conjunto de operações matemáticas básicas aplicadas a números conhecidos e a números desconhecidos. Para representar esses números desconhecidos, são utilizadas letras."));
                    paragrafo2_equacoes.setText(Html.fromHtml("É mais comum utilizar as letras x e y, mas isso não significa que elas são as únicas. Em alguns casos, são utilizadas letras do alfabeto grego e até símbolos diversos."));
                    paragrafo3_equacoes.setText(Html.fromHtml("1) 12x² + 16y + 4ab"));
                    paragrafo4_equacoes.setText(Html.fromHtml("2) x + y"));
                    paragrafo5_equacoes.setText(Html.fromHtml("3) 4 + 7a"));
                    paragrafo6_equacoes.setText(Html.fromHtml("Todas essas expressões possuem letras representando números e números sendo somados e multiplicados."));
                    fonte_equacoes.setText(Html.fromHtml("Fonte: Brasil Escola."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(expressoes_equacoes.this, selecao_equacoes.class);
                startActivity(intent);
            }
        });
    }
}
