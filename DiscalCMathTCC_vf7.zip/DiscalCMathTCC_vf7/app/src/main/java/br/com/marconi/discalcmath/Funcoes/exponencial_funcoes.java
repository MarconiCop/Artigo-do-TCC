package br.com.marconi.discalcmath.Funcoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class exponencial_funcoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exponencial_funcoes);

        TextView titulo1_funcoes = (TextView) findViewById(R.id.titulo1_funcoes);
        TextView titulo2_funcoes = (TextView) findViewById(R.id.titulo2_funcoes);
        TextView titulo3_funcoes = (TextView) findViewById(R.id.titulo3_funcoes);
        TextView paragrafo1_funcoes = (TextView) findViewById(R.id.paragrafo1_funcoes);
        TextView paragrafo2_funcoes = (TextView) findViewById(R.id.paragrafo2_funcoes);
        TextView paragrafo3_funcoes = (TextView) findViewById(R.id.paragrafo3_funcoes);
        TextView paragrafo4_funcoes = (TextView) findViewById(R.id.paragrafo4_funcoes);
        TextView paragrafo5_funcoes = (TextView) findViewById(R.id.paragrafo5_funcoes);
        TextView paragrafo6_funcoes = (TextView) findViewById(R.id.paragrafo6_funcoes);
        TextView paragrafo7_funcoes = (TextView) findViewById(R.id.paragrafo7_funcoes);
        TextView paragrafo8_funcoes = (TextView) findViewById(R.id.paragrafo8_funcoes);
        TextView paragrafo9_funcoes = (TextView) findViewById(R.id.paragrafo9_funcoes);
        TextView paragrafo10_funcoes = (TextView) findViewById(R.id.paragrafo10_funcoes);
        TextView fonte_funcoes = (TextView) findViewById(R.id.fonte_funcoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_funcoes.setText(Html.fromHtml("<font color='red'>Função Exponencial</font>"));
                    titulo2_funcoes.setText(Html.fromHtml("<font color='red'>Exemplos</font>"));
                    titulo3_funcoes.setText(Html.fromHtml("<font color='red'>Tipo de gráficos e funções</font>"));
                    paragrafo1_funcoes.setText(Html.fromHtml("<font color='green'>Função Exponencial</font> é aquela que a <font color='green'>variável</font> está no <font color='green'>expoente</font> e cuja <font color='green'>base</font> é sempre maior que zero e diferente de um<font color='#EA8240'>.</font>"));
                    paragrafo2_funcoes.setText(Html.fromHtml("Essas restrições são necessárias<font color='#EA8240'>,</font> pois <font color='blue'>1</font> elevado a qualquer número resulta em <font color='blue'>1</font><font color='#EA8240'>.</font> Assim<font color='#EA8240'>,</font> em vez de exponencial<font color='#EA8240'>,</font> estaríamos diante de uma <font color='green'>função constante</font><font color='#EA8240'>.</font>"));
                    paragrafo3_funcoes.setText(Html.fromHtml("Além disso<font color='#EA8240'>,</font> a base não pode ser negativa<font color='#EA8240'>,</font> nem igual a zero<font color='#EA8240'>,</font> pois para alguns expoentes a função não estaria definida<font color='#EA8240'>.</font>"));
                    paragrafo4_funcoes.setText(Html.fromHtml("Por exemplo<font color='#EA8240'>,</font> a base igual a <font color='#EA8240'>-</font> <font color='blue'>3</font> e o expoente igual a <font color='blue'>1</font><font color='#EA8240'>/</font><font color='blue'>2</font><font color='#EA8240'>.</font> Como no conjunto dos números reais não existe raiz quadrada de número negativo<font color='#EA8240'>,</font> não existiria imagem da função para esse valor<font color='#EA8240'>.</font>"));
                    paragrafo5_funcoes.setText(Html.fromHtml("<font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='blue'>4</font><font color='#EA8240'>^</font><font color='green'>x</font>"));
                    paragrafo6_funcoes.setText(Html.fromHtml("<font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>1</font><font color='#EA8240'>)</font><font color='#EA8240'>^</font><font color='green'>x</font>"));
                    paragrafo7_funcoes.setText(Html.fromHtml("<font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='blue'>2</font><font color='#EA8240'>/</font><font color='blue'>3</font><font color='#EA8240'>)</font><font color='#EA8240'>^</font><font color='green'>x</font>"));
                    paragrafo8_funcoes.setText(Html.fromHtml("Nos exemplos acima<font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>,</font> <font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>1</font> e <font color='blue'>2</font><font color='#EA8240'>/</font><font color='blue'>3</font> são as bases<font color='#EA8240'>,</font> enquanto <font color='green'>x</font> é o expoente<font color='#EA8240'>.</font>"));
                    paragrafo9_funcoes.setText(Html.fromHtml("O gráfico desta função passa pelo ponto <font color='#EA8240'>(</font><font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>1</font><font color='#EA8240'>)</font><font color='#EA8240'>,</font> pois todo número elevado a zero é igual a <font color='blue'>1</font><font color='#EA8240'>.</font> Além disso<font color='#EA8240'>,</font> a <font color='green'>curva exponencial</font> não toca no eixo <font color='green'>x</font><font color='#EA8240'>.</font> Na função exponencial a base é sempre maior que zero<font color='#EA8240'>,</font> portanto a função terá sempre <font color='green'>imagem</font> positiva<font color='#EA8240'>.</font> Assim sendo<font color='#EA8240'>,</font> não apresenta pontos nos quadrantes <font color='blue'>III</font> e <font color='blue'>IV</font> <font color='#EA8240'>(</font>imagem negativa<font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo10_funcoes.setText(Html.fromHtml("A função exponencial pode ser <font color='green'>crescente</font> ou <font color='green'>decrescente</font><font color='#EA8240'>.</font> Será crescente quando a base for maior que <font color='blue'>1</font><font color='#EA8240'>.</font> Por exemplo<font color='#EA8240'>,</font> a função <font color='green'>y</font> <font color='#EA8240'>=</font> <font color='blue'>2</font><font color='green'>x</font> é uma função crescente<font color='#EA8240'>.</font> Por sua vez<font color='#EA8240'>,</font> as funções cujas bases são valores maiores que zero e menores que <font color='blue'>1</font><font color='#EA8240'>,</font> são decrescentes<font color='#EA8240'>.</font>"));
                    fonte_funcoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_funcoes.setText(Html.fromHtml("Função Exponencial"));
                    titulo2_funcoes.setText(Html.fromHtml("Exemplos"));
                    titulo3_funcoes.setText(Html.fromHtml("Tipo de gráficos e funções"));
                    paragrafo1_funcoes.setText(Html.fromHtml("Função Exponencial é aquela que a variável está no expoente e cuja base é sempre maior que zero e diferente de um."));
                    paragrafo2_funcoes.setText(Html.fromHtml("Essas restrições são necessárias, pois 1 elevado a qualquer número resulta em 1. Assim, em vez de exponencial, estaríamos diante de uma função constante."));
                    paragrafo3_funcoes.setText(Html.fromHtml("Além disso, a base não pode ser negativa, nem igual a zero, pois para alguns expoentes a função não estaria definida."));
                    paragrafo4_funcoes.setText(Html.fromHtml("Por exemplo, a base igual a - 3 e o expoente igual a 1/2. Como no conjunto dos números reais não existe raiz quadrada de número negativo, não existiria imagem da função para esse valor."));
                    paragrafo5_funcoes.setText(Html.fromHtml("f(x) = 4^x"));
                    paragrafo6_funcoes.setText(Html.fromHtml("f(x) = (0,1)^x"));
                    paragrafo7_funcoes.setText(Html.fromHtml("f(x) = (2/3)^x"));
                    paragrafo8_funcoes.setText(Html.fromHtml("Nos exemplos acima, 4, 0,1 e 2/3 são as bases, enquanto x é o expoente."));
                    paragrafo9_funcoes.setText(Html.fromHtml("O gráfico desta função passa pelo ponto (0,1), pois todo número elevado a zero é igual a 1. Além disso, a curva exponencial não toca no eixo x. Na função exponencial a base é sempre maior que zero, portanto a função terá sempre imagem positiva. Assim sendo, não apresenta pontos nos quadrantes III e IV (imagem negativa)."));
                    paragrafo10_funcoes.setText(Html.fromHtml("A função exponencial pode ser crescente ou decrescente. Será crescente quando a base for maior que 1. Por exemplo, a função y = 2x é uma função crescente. Por sua vez, as funções cujas bases são valores maiores que zero e menores que 1, são decrescentes."));
                    fonte_funcoes.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(exponencial_funcoes.this, selecao_funcoes.class);
                startActivity(intent);
            }
        });
    }
}