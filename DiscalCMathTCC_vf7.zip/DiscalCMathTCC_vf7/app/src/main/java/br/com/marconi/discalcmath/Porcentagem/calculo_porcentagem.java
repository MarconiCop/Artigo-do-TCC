package br.com.marconi.discalcmath.Porcentagem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class calculo_porcentagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculo_porcentagem);

        TextView titulo1_porcentagem = (TextView) findViewById(R.id.titulo1_porcentagem);
        TextView titulo2_porcentagem = (TextView) findViewById(R.id.titulo2_porcentagem);
        TextView paragrafo1_porcentagem = (TextView) findViewById(R.id.paragrafo1_porcentagem);
        TextView paragrafo2_porcentagem = (TextView) findViewById(R.id.paragrafo2_porcentagem);
        TextView paragrafo3_porcentagem = (TextView) findViewById(R.id.paragrafo3_porcentagem);
        TextView paragrafo4_porcentagem = (TextView) findViewById(R.id.paragrafo4_porcentagem);
        TextView paragrafo5_porcentagem = (TextView) findViewById(R.id.paragrafo5_porcentagem);
        TextView paragrafo6_porcentagem = (TextView) findViewById(R.id.paragrafo6_porcentagem);
        TextView paragrafo7_porcentagem = (TextView) findViewById(R.id.paragrafo7_porcentagem);
        TextView paragrafo8_porcentagem = (TextView) findViewById(R.id.paragrafo8_porcentagem);
        TextView paragrafo9_porcentagem = (TextView) findViewById(R.id.paragrafo9_porcentagem);



        TextView fonte_porcentagem = (TextView) findViewById(R.id.fonte_porcentagem);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_porcentagem.setText(Html.fromHtml("<font color='red'>Cálculo</font>"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("Podemos utilizar diversas formas para <font color='green'>calcular</font> a porcentagem<font color='#EA8240'>.</font> Abaixo apresentamos <font color='green'>três</font> formas distintas<font color='#EA8240'>:</font> <font color='green'>regra de três</font><font color='#EA8240'>,</font> <font color='green'>transformação</font> da porcentagem em <font color='green'>fração</font> com <font color='green'>denominador</font> igual a <font color='blue'>100</font> e <font color='green'>transformação</font> da porcentagem em <font color='green'>número decimal</font><font color='#EA8240'>.</font>"));
                    paragrafo2_porcentagem.setText(Html.fromHtml("Devemos escolher a forma mais adequada de acordo com o problema que queremos resolver<font color='#EA8240'>.</font>"));

                    titulo2_porcentagem.setText(Html.fromHtml("<font color='red'>Exemplo</font> <font color='#EA8240'>(</font><font color='blue'>30</font><font color='#EA8240'>%</font> de <font color='blue'>90</font><font color='#EA8240'>)</font>"));

                    paragrafo5_porcentagem.setText(Html.fromHtml("Para resolver usando frações<font color='#EA8240'>,</font> primeiro temos que transformar a porcentagem em uma fração com denominador igual a <font color='blue'>100</font><font color='#EA8240'>:</font>"));
                    paragrafo6_porcentagem.setText(Html.fromHtml("<font color='blue'>30</font><font color='#EA8240'>%</font> <font color='#EA8240'>=</font> <font color='blue'>30</font><font color='#EA8240'>/</font><font color='blue'>100</font> <font color='#EA8240'>=</font> <font color='blue'>3</font><font color='#EA8240'>/</font><font color='blue'>10</font><font color='#EA8240'>,</font> logo<font color='#EA8240'>,</font> <font color='#EA8240'>(</font><font color='blue'>3</font><font color='#EA8240'>/</font><font color='blue'>10</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font><font color='blue'>90</font> <font color='#EA8240'>=</font> <font color='blue'>27</font><font color='#EA8240'>.</font>"));

                    paragrafo7_porcentagem.setText(Html.fromHtml("Podemos ainda transformar a porcentagem em número decimal<font color='#EA8240'>:</font>"));
                    paragrafo8_porcentagem.setText(Html.fromHtml("<font color='blue'>30</font><font color='#EA8240'>%</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>3</font><font color='#EA8240'>.</font> Logo<font color='#EA8240'>,</font> <font color='blue'>0</font><font color='#EA8240'>,</font><font color='blue'>3</font><font color='#EA8240'>.</font><font color='blue'>90</font> <font color='#EA8240'>=</font> <font color='blue'>27</font><font color='#EA8240'>.</font>"));

                    paragrafo9_porcentagem.setText(Html.fromHtml("O resultado é o mesmo nas três formas<font color='#EA8240'>,</font> ou seja<font color='#EA8240'>,</font> <font color='blue'>30</font><font color='#EA8240'>%</font> de <font color='blue'>90</font> corresponde a <font color='blue'>27</font><font color='#EA8240'>.</font>"));

                    fonte_porcentagem.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_porcentagem.setText(Html.fromHtml("Cálculo"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("Podemos utilizar diversas formas para calcular a porcentagem. Abaixo apresentamos três formas distintas: regra de três, transformação da porcentagem em fração com denominador igual a 100 e transformação da porcentagem em número decimal."));
                    paragrafo2_porcentagem.setText(Html.fromHtml("Devemos escolher a forma mais adequada de acordo com o problema que queremos resolver."));


                    titulo2_porcentagem.setText(Html.fromHtml("Exemplo (30% de 90)"));


                    paragrafo5_porcentagem.setText(Html.fromHtml("Para resolver usando frações, primeiro temos que transformar a porcentagem em uma fração com denominador igual a 100:"));
                    paragrafo6_porcentagem.setText(Html.fromHtml("30% = 30/100 = 3/10, logo, (3/10).90 = 27."));

                    paragrafo7_porcentagem.setText(Html.fromHtml("Podemos ainda transformar a porcentagem em número decimal:"));
                    paragrafo8_porcentagem.setText(Html.fromHtml("30% = 0,3. Logo, 0,3.90 = 27."));
                    paragrafo9_porcentagem.setText(Html.fromHtml("O resultado é o mesmo nas três formas, ou seja, 30% de 90 corresponde a 27."));

                    fonte_porcentagem.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });




        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(calculo_porcentagem.this, selecao_porcentagem.class);
                startActivity(intent);
            }
        });
    }
    }
