package br.com.marconi.discalcmath.Funcoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class introducao_funcoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introducao_funcoes);

        TextView titulo1_funcoes = (TextView) findViewById(R.id.titulo1_funcoes);
        TextView titulo2_funcoes = (TextView) findViewById(R.id.titulo2_funcoes);
        TextView titulo3_funcoes = (TextView) findViewById(R.id.titulo3_funcoes);
        TextView paragrafo1_funcoes = (TextView) findViewById(R.id.paragrafo1_funcoes);
        TextView paragrafo2_funcoes = (TextView) findViewById(R.id.paragrafo2_funcoes);
        TextView paragrafo3_funcoes = (TextView) findViewById(R.id.paragrafo3_funcoes);
        TextView paragrafo4_funcoes = (TextView) findViewById(R.id.paragrafo4_funcoes);
        TextView paragrafo5_funcoes = (TextView) findViewById(R.id.paragrafo5_funcoes);
        TextView paragrafo6_funcoes = (TextView) findViewById(R.id.paragrafo6_funcoes);
        TextView paragrafo7_funcoes = (TextView) findViewById(R.id.paragrafo7_funcoes);
        TextView paragrafo8_funcoes = (TextView) findViewById(R.id.paragrafo8_funcoes);
        TextView paragrafo9_funcoes = (TextView) findViewById(R.id.paragrafo9_funcoes);
        TextView paragrafo10_funcoes = (TextView) findViewById(R.id.paragrafo10_funcoes);
        TextView paragrafo11_funcoes = (TextView) findViewById(R.id.paragrafo11_funcoes);
        TextView fonte_funcoes = (TextView) findViewById(R.id.fonte_funcoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_funcoes.setText(Html.fromHtml("<font color='red'>Introdução</font>"));
                    titulo2_funcoes.setText(Html.fromHtml("<font color='red'>Representação das funções</font>"));
                    titulo3_funcoes.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo1_funcoes.setText(Html.fromHtml("Na Matemática<font color='#EA8240'>,</font> <font color='green'>função</font> corresponde a uma associação dos <font color='green'>elementos</font> de dois <font color='green'>conjuntos</font><font color='#EA8240'>,</font> ou seja<font color='#EA8240'>,</font> a função indica como os elementos estão relacionados<font color='#EA8240'>.</font>"));
                    paragrafo2_funcoes.setText(Html.fromHtml("Por exemplo<font color='#EA8240'>,</font> uma função de <font color='green'>A</font> em <font color='green'>B</font> significa associar cada elemento pertencente ao conjunto <font color='green'>A</font> a um único elemento que compõe o conjunto <font color='green'>B</font><font color='#EA8240'>,</font> sendo assim<font color='#EA8240'>,</font> um valor de <font color='green'>A</font> não pode estar ligado a dois valores de <font color='green'>B</font><font color='#EA8240'>.</font>"));
                    paragrafo3_funcoes.setText(Html.fromHtml("Notação para função<font color='#EA8240'>:</font> <font color='green'>f</font><font color='#EA8240'>:</font> <font color='green'>A</font> <font color='#EA8240'>→</font> <font color='green'>B</font> <font color='#EA8240'>(</font>lê-se<font color='#EA8240'>:</font> <font color='green'>f</font> de <font color='green'>A</font> em <font color='green'>B</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo4_funcoes.setText(Html.fromHtml("Em uma função <font color='green'>f</font><font color='#EA8240'>:</font> <font color='green'>A</font> <font color='#EA8240'>→</font> <font color='green'>B</font> o conjunto <font color='green'>A</font> é chamado de <font color='green'>domínio</font> <font color='#EA8240'>(</font><font color='green'>D</font><font color='#EA8240'>)</font> e o conjunto <font color='green'>B</font> recebe o nome de <font color='green'>contradomínio</font> <font color='#EA8240'>(</font><font color='green'>CD</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo5_funcoes.setText(Html.fromHtml("Um elemento de <font color='green'>B</font> relacionado a um elemento de <font color='green'>A</font> recebe o nome de <font color='green'>imagem</font> pela função<font color='#EA8240'>.</font> Agrupando todas as imagens de <font color='green'>B</font> temos um conjunto imagem<font color='#EA8240'>,</font> que é um subconjunto do controdomínio<font color='#EA8240'>.</font>"));
                    paragrafo6_funcoes.setText(Html.fromHtml("Observe os conjuntos <font color='green'>A</font> <font color='#EA8240'>=</font> <font color='#EA8240'>{</font><font color='blue'>1</font><font color='#EA8240'>,</font> <font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>3</font><font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>}</font> e <font color='green'>B</font> <font color='#EA8240'>=</font> <font color='#EA8240'>{</font><font color='blue'>1</font><font color='#EA8240'>,</font> 2<font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>3</font><font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>,</font> <font color='blue'>5</font><font color='#EA8240'>,</font> <font color='blue'>6</font><font color='#EA8240'>,</font> <font color='blue'>7</font><font color='#EA8240'>,</font> <font color='blue'>8</font><font color='#EA8240'>}</font><font color='#EA8240'>,</font> com a função que determina a relação entre os elementos <font color='green'>f</font><font color='#EA8240'>:</font> <font color='green'>A</font> <font color='#EA8240'>→</font> <font color='green'>B</font> é <font color='green'>x</font> <font color='#EA8240'>→</font> <font color='blue'>2</font><font color='green'>x</font><font color='#EA8240'>.</font> Sendo assim<font color='#EA8240'>,</font> <font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='blue'>2</font><font color='green'>x</font> e cada <font color='green'>x</font> do conjunto <font color='green'>A</font> é transformado em <font color='blue'>2</font><font color='green'>x</font> no conjunto <font color='green'>B</font><font color='#EA8240'>.</font>"));
                    paragrafo7_funcoes.setText(Html.fromHtml("Note que o conjunto de <font color='green'>A</font> <font color='#EA8240'>{</font><font color='blue'>1</font><font color='#EA8240'>,</font> <font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>3</font><font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>}</font> são as entradas<font color='#EA8240'>,</font> multiplicar por <font color='blue'>2</font> é a função e os valores de <font color='green'>B</font> <font color='#EA8240'>{</font><font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>,</font> <font color='blue'>6</font><font color='#EA8240'>,</font> <font color='blue'>8</font><font color='#EA8240'>}</font><font color='#EA8240'>,</font> que se ligam aos elementos de <font color='green'>A</font> são os valores de saída<font color='#EA8240'>.</font>"));
                    paragrafo8_funcoes.setText(Html.fromHtml("Portanto<font color='#EA8240'>,</font> para essa função<font color='#EA8240'>:</font>"));
                    paragrafo9_funcoes.setText(Html.fromHtml("O domínio é <font color='#EA8240'>{</font><font color='blue'>1</font><font color='#EA8240'>,</font> <font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>3</font><font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>}</font>"));
                    paragrafo10_funcoes.setText(Html.fromHtml("O contradomínio é <font color='#EA8240'>{</font><font color='blue'>1</font><font color='#EA8240'>,</font> <font color='blue'>2</font><font color='#EA8240'>,</font> <font color='blue'>3</font><font color='#EA8240'>,</font> <font color='blue'>4</font><font color='#EA8240'>,</font> <font color='blue'>5</font><font color='#EA8240'>,</font> <font color='blue'>6</font><font color='#EA8240'>,</font> <font color='blue'>7</font><font color='#EA8240'>,</font> <font color='blue'>8</font><font color='#EA8240'>}</font>"));
                    paragrafo11_funcoes.setText(Html.fromHtml("O conjunto imagem é <font color='#EA8240'>{</font><font color='blue'>1</font><font color='#EA8240'>,</font> <font color='blue'>5</font><font color='#EA8240'>,</font> <font color='blue'>8</font><font color='#EA8240'>}</font>"));
                    fonte_funcoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_funcoes.setText(Html.fromHtml("Introdução"));
                    titulo2_funcoes.setText(Html.fromHtml("Representação das funções"));
                    titulo3_funcoes.setText(Html.fromHtml("Exemplo"));
                    paragrafo1_funcoes.setText(Html.fromHtml("Na Matemática, função corresponde a uma associação dos elementos de dois conjuntos, ou seja, a função indica como os elementos estão relacionados."));
                    paragrafo2_funcoes.setText(Html.fromHtml("Por exemplo, uma função de A em B significa associar cada elemento pertencente ao conjunto A a um único elemento que compõe o conjunto B, sendo assim, um valor de A não pode estar ligado a dois valores de B."));
                    paragrafo3_funcoes.setText(Html.fromHtml("Notação para função: f: A → B (lê-se: f de A em B)."));
                    paragrafo4_funcoes.setText(Html.fromHtml("Em uma função f: A → B o conjunto A é chamado de domínio (D) e o conjunto B recebe o nome de contradomínio (CD)."));
                    paragrafo5_funcoes.setText(Html.fromHtml("Um elemento de B relacionado a um elemento de A recebe o nome de imagem pela função. Agrupando todas as imagens de B temos um conjunto imagem, que é um subconjunto do controdomínio."));
                    paragrafo6_funcoes.setText(Html.fromHtml("Observe os conjuntos A = {1, 2, 3, 4} e B = {1, 2, 3, 4, 5, 6, 7, 8}, com a função que determina a relação entre os elementos f: A → B é x → 2x. Sendo assim, f(x) = 2x e cada x do conjunto A é transformado em 2x no conjunto B."));
                    paragrafo7_funcoes.setText(Html.fromHtml("Note que o conjunto de A {1, 2, 3, 4} são as entradas, multiplicar por 2 é a função e os valores de B {2, 4, 6, 8}, que se ligam aos elementos de A, são os valores de saída."));
                    paragrafo8_funcoes.setText(Html.fromHtml("Portanto, para essa função:"));
                    paragrafo9_funcoes.setText(Html.fromHtml("O domínio é {1, 2, 3, 4}"));
                    paragrafo10_funcoes.setText(Html.fromHtml("O contradomínio é {1, 2, 3, 4, 5, 6, 7, 8}"));
                    paragrafo11_funcoes.setText(Html.fromHtml("O conjunto imagem é {1, 5, 8}"));
                    fonte_funcoes.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(introducao_funcoes.this, selecao_funcoes.class);
                startActivity(intent);
            }
        });
    }
}