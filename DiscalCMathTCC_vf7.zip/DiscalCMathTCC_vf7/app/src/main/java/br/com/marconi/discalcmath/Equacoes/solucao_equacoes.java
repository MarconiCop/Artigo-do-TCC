package br.com.marconi.discalcmath.Equacoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class solucao_equacoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solucao_equacoes);

        TextView titulo1_equacoes = (TextView) findViewById(R.id.titulo1_equacoes);
        TextView titulo2_equacoes = (TextView) findViewById(R.id.titulo2_equacoes);
        TextView titulo3_equacoes = (TextView) findViewById(R.id.titulo3_equacoes);
        TextView paragrafo1_equacoes = (TextView) findViewById(R.id.paragrafo1_equacoes);
        TextView paragrafo2_equacoes = (TextView) findViewById(R.id.paragrafo2_equacoes);
        TextView paragrafo3_equacoes = (TextView) findViewById(R.id.paragrafo3_equacoes);
        TextView paragrafo4_equacoes = (TextView) findViewById(R.id.paragrafo4_equacoes);
        TextView paragrafo5_equacoes = (TextView) findViewById(R.id.paragrafo5_equacoes);
        TextView paragrafo6_equacoes = (TextView) findViewById(R.id.paragrafo6_equacoes);
        TextView paragrafo7_equacoes = (TextView) findViewById(R.id.paragrafo7_equacoes);
        TextView paragrafo8_equacoes = (TextView) findViewById(R.id.paragrafo8_equacoes);
        TextView paragrafo9_equacoes = (TextView) findViewById(R.id.paragrafo9_equacoes);
        TextView paragrafo10_equacoes = (TextView) findViewById(R.id.paragrafo10_equacoes);
        TextView paragrafo11_equacoes = (TextView) findViewById(R.id.paragrafo11_equacoes);
        TextView paragrafo12_equacoes = (TextView) findViewById(R.id.paragrafo12_equacoes);
        TextView paragrafo13_equacoes = (TextView) findViewById(R.id.paragrafo13_equacoes);
        TextView paragrafo14_equacoes = (TextView) findViewById(R.id.paragrafo14_equacoes);
        TextView paragrafo15_equacoes = (TextView) findViewById(R.id.paragrafo15_equacoes);
        TextView fonte_equacoes = (TextView) findViewById(R.id.fonte_equacoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw_modo_discalculia.isChecked() == true) {
                    titulo1_equacoes.setText(Html.fromHtml("<font color='red'>Solução</font>"));
                    titulo2_equacoes.setText(Html.fromHtml("<font color='red'>Regras</font>"));
                    titulo3_equacoes.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo1_equacoes.setText(Html.fromHtml("Uma das estratégias de <font color='green'>resolução</font> de uma equação faz uso do pensamento<font color='#EA8240'>.</font> Repare que<font color='#EA8240'>,</font> observando as duas equações <font color='#EA8240'>(</font><font color='green'>x</font> <font color='#EA8240'>-</font> <font color='blue'>14</font> <font color='#EA8240'>=</font> <font color='blue'>8</font> e <font color='green'>x</font> <font color='#EA8240'>=</font> <font color='blue'>8</font> <font color='#EA8240'>+</font> <font color='blue'>14</font><font color='#EA8240'>)</font><font color='#EA8240'>,</font> é possível imaginar que o número <font color='blue'>14</font> trocou de lado da <font color='green'>igualdade</font> com um efeito colateral<font color='#EA8240'>:</font> trocou o seu sinal de <font color='green'>negativo</font> para <font color='green'>positivo</font><font color='#EA8240'>.</font>"));
                    paragrafo2_equacoes.setText(Html.fromHtml("<font color='green'>Regra</font> <font color='blue'>1</font> <font color='#EA8240'>-</font> Do lado direito da igualdade<font color='#EA8240'>,</font> só permanecem números que não possuem <font color='green'>incógnita</font><font color='#EA8240'>;</font> do lado esquerdo<font color='#EA8240'>,</font> apenas números que possuem<font color='#EA8240'>;</font>"));
                    paragrafo3_equacoes.setText(Html.fromHtml("<font color='green'>Regra</font> <font color='blue'>2</font> <font color='#EA8240'>-</font> Para trocar números de lado<font color='#EA8240'>,</font> possuindo ou não incógnita<font color='#EA8240'>,</font> é necessário trocar o sinal deles<font color='#EA8240'>;</font>"));
                    paragrafo4_equacoes.setText(Html.fromHtml("<font color='green'>Regra</font> <font color='blue'>3</font> <font color='#EA8240'>-</font> Feitos os passos <font color='blue'>1</font> e <font color='blue'>2</font><font color='#EA8240'>,</font> realize os cálculos que forem possíveis<font color='#EA8240'>.</font> Lembre-se de que os números que possuem incógnita podem ser somados se a incógnita for a mesma<font color='#EA8240'>.</font> Para isso<font color='#EA8240'>,</font> some apenas o número que as acompanha<font color='#EA8240'>;</font>"));
                    paragrafo5_equacoes.setText(Html.fromHtml("<font color='green'>Regra</font> <font color='blue'>4</font> <font color='#EA8240'>-</font> Ao final<font color='#EA8240'>,</font> deve-se isolar a incógnita<font color='#EA8240'>.</font> Para isso<font color='#EA8240'>,</font> o número que a acompanha deverá ser passado para o lado direito da equação dividindo os seus componentes<font color='#EA8240'>;</font>"));
                    paragrafo6_equacoes.setText(Html.fromHtml("<font color='green'>Regra</font> <font color='blue'>5</font> <font color='#EA8240'>-</font> Se for necessário trocar de lado um número que está no <font color='green'>denominador</font> de uma <font color='green'>fração</font><font color='#EA8240'>,</font> ele deverá passar para o outro lado multiplicando<font color='#EA8240'>.</font>"));
                    paragrafo7_equacoes.setText(Html.fromHtml("Qual o valor de <font color='green'>x</font> na equação <font color='blue'>4</font><font color='green'>x</font> <font color='#EA8240'>+</font> <font color='blue'>4</font> <font color='#EA8240'>=</font> <font color='blue'>2</font><font color='green'>x</font> <font color='#EA8240'>-</font> <font color='blue'>8</font><font color='#EA8240'>?</font>"));
                    paragrafo8_equacoes.setText(Html.fromHtml("<font color='green'>Solução</font><font color='#EA8240'>:</font> Seguindo a primeira e segunda regras<font color='#EA8240'>,</font> obteremos a seguinte linha de raciocínio<font color='#EA8240'>:</font>"));
                    paragrafo9_equacoes.setText(Html.fromHtml("<font color='blue'>4</font><font color='green'>x</font> <font color='#EA8240'>+</font> <font color='blue'>4</font> <font color='#EA8240'>=</font> <font color='blue'>2</font><font color='green'>x</font> <font color='#EA8240'>-</font> <font color='blue'>8</font>"));
                    paragrafo10_equacoes.setText(Html.fromHtml("<font color='blue'>4</font><font color='green'>x</font> <font color='#EA8240'>-</font> <font color='blue'>2</font><font color='green'>x</font> <font color='#EA8240'>=</font> <font color='#EA8240'>-</font><font color='blue'>8</font> <font color='#EA8240'>-</font> <font color='blue'>4</font>"));
                    paragrafo11_equacoes.setText(Html.fromHtml("Agora<font color='#EA8240'>,</font> realize a terceira regra para obter<font color='#EA8240'>:</font>"));
                    paragrafo12_equacoes.setText(Html.fromHtml("<font color='blue'>2</font><font color='green'>x</font> <font color='#EA8240'>=</font> <font color='#EA8240'>-</font> <font color='blue'>12</font>"));
                    paragrafo13_equacoes.setText(Html.fromHtml("Por fim<font color='#EA8240'>,</font> realize a <font color='green'>regra</font> <font color='blue'>4</font><font color='#EA8240'>:</font>"));
                    paragrafo14_equacoes.setText(Html.fromHtml("<font color='green'>x</font> <font color='#EA8240'>=</font> <font color='#EA8240'>-</font><font color='blue'>12</font><font color='#EA8240'>/</font><font color='blue'>2</font> <font color='#EA8240'>=</font> <font color='#EA8240'>-</font><font color='blue'>6</font>"));
                    paragrafo15_equacoes.setText(Html.fromHtml("Portanto<font color='#EA8240'>,</font> o valor de <font color='green'>x</font> é <font color='#EA8240'>-</font> <font color='blue'>6</font><font color='#EA8240'>.</font>"));
                    fonte_equacoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Brasil Escola<font color='#EA8240'>.</font>"));
                }
                if (sw_modo_discalculia.isChecked() == false) {
                    titulo1_equacoes.setText(Html.fromHtml("Solução"));
                    titulo2_equacoes.setText(Html.fromHtml("Regras"));
                    titulo3_equacoes.setText(Html.fromHtml("Exemplo"));
                    paragrafo1_equacoes.setText(Html.fromHtml("Uma das estratégias de resolução de uma equação faz uso do pensamento. Repare que, observando as duas equações (x – 14 = 8 e x = 8 + 14), é possível imaginar que o número 14 trocou de lado da igualdade com um efeito colateral: trocou o seu sinal de negativo para positivo."));
                    paragrafo2_equacoes.setText(Html.fromHtml("Regra 1 – Do lado direito da igualdade, só permanecem números que não possuem incógnita; do lado esquerdo, apenas números que possuem;"));
                    paragrafo3_equacoes.setText(Html.fromHtml("Regra 2 – Para trocar números de lado, possuindo ou não incógnita, é necessário trocar o sinal deles;"));
                    paragrafo4_equacoes.setText(Html.fromHtml("Regra 3 – Feitos os passos 1 e 2, realize os cálculos que forem possíveis. Lembre-se de que os números que possuem incógnita podem ser somados se a incógnita for a mesma. Para isso, some apenas o número que as acompanha;"));
                    paragrafo5_equacoes.setText(Html.fromHtml("Regra 4 – Ao final, deve-se isolar a incógnita. Para isso, o número que a acompanha deverá ser passado para o lado direito da equação dividindo os seus componentes;"));
                    paragrafo6_equacoes.setText(Html.fromHtml("Regra 5 – Se for necessário trocar de lado um número que está no denominador de uma fração, ele deverá passar para o outro lado multiplicando."));
                    paragrafo7_equacoes.setText(Html.fromHtml("Qual o valor de x na equação 4x + 4 = 2x – 8?"));
                    paragrafo8_equacoes.setText(Html.fromHtml("Solução: Seguindo a primeira e segunda regras, obteremos a seguinte linha de raciocínio:"));
                    paragrafo9_equacoes.setText(Html.fromHtml("4x + 4 = 2x – 8"));
                    paragrafo10_equacoes.setText(Html.fromHtml("4x – 2x = – 8 – 4"));
                    paragrafo11_equacoes.setText(Html.fromHtml("Agora, realize a terceira regra para obter:"));
                    paragrafo12_equacoes.setText(Html.fromHtml("2x = – 12"));
                    paragrafo13_equacoes.setText(Html.fromHtml("Por fim, realize a regra 4:"));
                    paragrafo14_equacoes.setText(Html.fromHtml("x = –12/2 = -6"));
                    paragrafo15_equacoes.setText(Html.fromHtml("Portanto, o valor de x é – 6."));
                    fonte_equacoes.setText(Html.fromHtml("Fonte: Brasil Escola."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(solucao_equacoes.this, selecao_equacoes.class);
                startActivity(intent);
            }
        });
    }
}
