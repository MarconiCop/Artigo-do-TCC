package br.com.marconi.discalcmath.Grandezas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class introducao_grandezas extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introducao_grandezas);

        TextView titulo1_grandezas = (TextView) findViewById(R.id.titulo1_grandezas);
        TextView titulo2_grandezas = (TextView) findViewById(R.id.titulo2_grandezas);
        TextView paragrafo1_grandezas = (TextView) findViewById(R.id.paragrafo1_grandezas);
        TextView paragrafo2_grandezas = (TextView) findViewById(R.id.paragrafo2_grandezas);
        TextView paragrafo3_grandezas = (TextView) findViewById(R.id.paragrafo3_grandezas);

        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_grandezas);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_grandezas.setText(Html.fromHtml("<font color='red'>Introdução</font>"));
                    paragrafo1_grandezas.setText(Html.fromHtml("Uma <font color='green'>grandeza</font> é definida como algo que pode ser medido ou calculado<font color='#EA8240'>,</font> seja velocidade<font color='#EA8240'>,</font> área ou volume de um material<font color='#EA8240'>,</font> e é útil para comparar com outras medidas<font color='#EA8240'>,</font> muitas vezes de mesma unidade<font color='#EA8240'>,</font> representando uma razão<font color='#EA8240'>.</font>"));

                    titulo2_grandezas.setText(Html.fromHtml("<font color='red'>Proporção</font>"));
                    paragrafo2_grandezas.setText(Html.fromHtml("A <font color='green'>proporção</font> é uma relação de igualdade entre <font color='green'>razões</font> e<font color='#EA8240'>,</font> assim<font color='#EA8240'>,</font> apresenta a comparação de duas grandezas em diferentes situações<font color='#EA8240'>.</font> Na proporção <font color='#EA8240'>(</font><font color='green'>a</font><font color='#EA8240'>/</font><font color='green'>b</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='green'>c</font><font color='#EA8240'>/</font><font color='green'>d</font><font color='#EA8240'>)</font><font color='#EA8240'>,</font> a igualdade entre <font color='green'>a</font><font color='#EA8240'>,</font> <font color='green'>b</font><font color='#EA8240'>,</font> <font color='green'>c</font> e <font color='green'>d</font> é lida da seguinte forma<font color='#EA8240'>:</font> <font color='green'>a</font> está para <font color='green'>b</font><font color='#EA8240'>,</font> assim como <font color='green'>c</font> está para <font color='green'>d</font><font color='#EA8240'>.</font> "));
                    paragrafo3_grandezas.setText(Html.fromHtml("A relação entre as grandezas podem ocorrer de maneira <font color='green'>diretamente</font> ou <font color='green'>inversamente</font> proporcional<font color='#EA8240'>.</font>"));


                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_grandezas.setText(Html.fromHtml("Introdução"));
                    paragrafo1_grandezas.setText(Html.fromHtml("Uma grandeza é definida como algo que pode ser medido ou calculado, seja velocidade, área ou volume de um material, e é útil para comparar com outras medidas, muitas vezes de mesma unidade, representando uma razão."));

                    titulo2_grandezas.setText(Html.fromHtml("Proporção"));
                    paragrafo2_grandezas.setText(Html.fromHtml("A proporção é uma relação de igualdade entre razões e, assim, apresenta a comparação de duas grandezas em diferentes situações. Na proporção (a/b) = (c/d), a igualdade entre a, b, c e d é lida da seguinte forma: a está para b, assim como c está para d. "));
                    paragrafo3_grandezas.setText(Html.fromHtml("A relação entre as grandezas podem ocorrer de maneira diretamente ou inversamente proporcional."));

                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }


            }
        });


        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(introducao_grandezas.this, selecao_grandezas_proporcionais.class);
                startActivity(intent);
            }
        });
    }
}
