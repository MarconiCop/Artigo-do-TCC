package br.com.marconi.discalcmath.Bancos;

public class Usuario {
    private String email,senha, numeroid; //Criar Conta
    String nome, uid, prof, url;    //Criar perfil
    private long moedas = 0;   //Moedas Iniciais
    float rating;               //Avaliar
    String dificuldade = "--";

    public Usuario() {
    }

    public Usuario(String nome, String email, String senha, String numeroid) { // Pega apenas os dados de Criar Conta
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.numeroid = numeroid;
    }


    public Usuario(String name, String uid, String prof, String url, float rating) { // Pega os demais nomes
        this.nome = name;
        this.uid = uid;
        this.prof = prof;
        this.url = url;
        this.rating = rating;
    }


    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getNumeroid() {
        return numeroid;
    }

    public void setNumeroid(String numeroid) {
        this.numeroid = numeroid;
    }

    public long getMoedas() {
        return moedas;
    }

    public void setMoedas(long moedas) {
        this.moedas = moedas;
    }


    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getProf() {
        return prof;
    }

    public void setProf(String prof) {
        this.prof = prof;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public  float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public String getDificuldade() {
        return dificuldade;
    }

    public void setDificuldade(String dificuldade) {
        this.dificuldade = dificuldade;
    }
}
