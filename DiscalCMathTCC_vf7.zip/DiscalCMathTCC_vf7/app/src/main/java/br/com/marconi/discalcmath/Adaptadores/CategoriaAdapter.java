package br.com.marconi.discalcmath.Adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import br.com.marconi.discalcmath.Bancos.CategoriaModelo;
import br.com.marconi.discalcmath.Jogo.MetodosQuiz;
import br.com.marconi.discalcmath.R;

import java.util.ArrayList;

public class CategoriaAdapter extends RecyclerView.Adapter<CategoriaAdapter.CategoriaViewHolder> {

    Context context;
    ArrayList<CategoriaModelo> categoriamodelos;

    public CategoriaAdapter(Context context, ArrayList<CategoriaModelo> categoriaModelos){

        this.context = context;
        this.categoriamodelos = categoriaModelos;

    }

    @NonNull
    @Override
    public CategoriaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_category,null);

        return new CategoriaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoriaViewHolder holder, int position) {
            CategoriaModelo modelo = categoriamodelos.get(position);

            holder.textView.setText(modelo.getCategoriaNome());
            Glide.with(context)
                    .load(modelo.getCategoriaImagem())
                    .into(holder.imageView);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(context, MetodosQuiz.class);
                    intent.putExtra("catId",modelo.getCategoriaId());
                    context.startActivity(intent);
                }
            });

    }

    @Override
    public int getItemCount() {
        return categoriamodelos.size();
    }

    public class CategoriaViewHolder extends RecyclerView.ViewHolder{

        ImageView imageView;
        TextView textView;

        public CategoriaViewHolder(@NonNull View itemView){
            super(itemView);
            imageView = itemView.findViewById(R.id.imagem);
            textView = itemView.findViewById(R.id.categoria);
        }

    }
}
