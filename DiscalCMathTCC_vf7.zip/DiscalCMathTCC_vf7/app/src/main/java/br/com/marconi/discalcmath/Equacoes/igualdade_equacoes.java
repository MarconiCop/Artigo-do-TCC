package br.com.marconi.discalcmath.Equacoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class igualdade_equacoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igualdade_equacoes);

        TextView titulo1_equacoes = (TextView) findViewById(R.id.titulo1_equacoes);
        TextView titulo2_equacoes = (TextView) findViewById(R.id.titulo2_equacoes);
        TextView paragrafo1_equacoes = (TextView) findViewById(R.id.paragrafo1_equacoes);
        TextView paragrafo2_equacoes = (TextView) findViewById(R.id.paragrafo2_equacoes);
        TextView paragrafo3_equacoes = (TextView) findViewById(R.id.paragrafo3_equacoes);
        TextView paragrafo4_equacoes = (TextView) findViewById(R.id.paragrafo4_equacoes);
        TextView paragrafo5_equacoes = (TextView) findViewById(R.id.paragrafo5_equacoes);
        TextView paragrafo6_equacoes = (TextView) findViewById(R.id.paragrafo6_equacoes);
        TextView paragrafo7_equacoes = (TextView) findViewById(R.id.paragrafo7_equacoes);
        TextView paragrafo8_equacoes = (TextView) findViewById(R.id.paragrafo8_equacoes);
        TextView paragrafo9_equacoes = (TextView) findViewById(R.id.paragrafo9_equacoes);
        TextView paragrafo10_equacoes = (TextView) findViewById(R.id.paragrafo10_equacoes);
        TextView paragrafo11_equacoes = (TextView) findViewById(R.id.paragrafo11_equacoes);
        TextView fonte_equacoes = (TextView) findViewById(R.id.fonte_equacoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (sw_modo_discalculia.isChecked() == true) {
                    titulo1_equacoes.setText(Html.fromHtml("<font color='red'>Igualdade</font>"));
                    titulo2_equacoes.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo1_equacoes.setText(Html.fromHtml("Toda <font color='green'>expressão algébrica</font> que possuir uma <font color='green'>igualdade</font> em sua composição será chamada de <font color='green'>equação</font><font color='#EA8240'>.</font> Observe alguns exemplos<font color='#EA8240'>:</font>"));
                    paragrafo2_equacoes.setText(Html.fromHtml("<font color='blue'>1</font><font color='#EA8240'>)</font> <font color='green'>x</font> <font color='#EA8240'>+</font> <font color='blue'>2</font> <font color='#EA8240'>=</font> <font color='blue'>7</font>"));
                    paragrafo3_equacoes.setText(Html.fromHtml("<font color='blue'>2</font><font color='#EA8240'>)</font> <font color='blue'>12</font><font color='green'>x</font><font color='blue'>²</font> <font color='#EA8240'>+</font> <font color='blue'>16</font><font color='green'>y</font> <font color='#EA8240'>+</font> <font color='blue'>4</font><font color='green'>ab</font> <font color='#EA8240'>=</font> <font color='blue'>7</font>"));
                    paragrafo4_equacoes.setText(Html.fromHtml("<font color='blue'>3</font><font color='#EA8240'>)</font> <font color='blue'>1</font><font color='#EA8240'>:</font><font color='green'>x</font> <font color='#EA8240'>=</font> <font color='blue'>3</font>"));
                    paragrafo5_equacoes.setText(Html.fromHtml("A igualdade é o que permite encontrar os <font color='green'>resultados</font> de uma equação<font color='#EA8240'>.</font> É a igualdade que relaciona uma operação matemática aplicada em alguns números com o seu resultado<font color='#EA8240'>.</font> Portanto<font color='#EA8240'>,</font> a igualdade é peça fundamental ao procurar os resultados de uma equação<font color='#EA8240'>.</font>"));
                    paragrafo6_equacoes.setText(Html.fromHtml("Dada a equação <font color='green'>x</font> <font color='#EA8240'>-</font> <font color='blue'>14</font> <font color='#EA8240'>=</font> <font color='blue'>8</font><font color='#EA8240'>,</font> qual é o valor de <font color='green'>x</font><font color='#EA8240'>?</font>"));
                    paragrafo7_equacoes.setText(Html.fromHtml("Sabemos que <font color='green'>x</font> é um número que<font color='#EA8240'>,</font> subtraído por <font color='blue'>14</font><font color='#EA8240'>,</font> tem <font color='blue'>8</font> como resultado<font color='#EA8240'>.</font> Observe que é possível pensar em um resultado “de cabeça” ou pensar em uma <font color='green'>estratégia</font> para resolver essa equação<font color='#EA8240'>.</font> A estratégia pode ser obtida da seguinte maneira<font color='#EA8240'>:</font> Se <font color='green'>x</font> é um número que<font color='#EA8240'>,</font> subtraído de <font color='blue'>14</font><font color='#EA8240'>,</font> resulta em <font color='blue'>8</font><font color='#EA8240'>,</font> então<font color='#EA8240'>,</font> para encontrar <font color='green'>x</font><font color='#EA8240'>,</font> basta somar <font color='blue'>14</font> com <font color='blue'>8</font><font color='#EA8240'>.</font> Desse modo<font color='#EA8240'>,</font> podemos escrever a seguinte linha de raciocínio<font color='#EA8240'>:</font>"));
                    paragrafo8_equacoes.setText(Html.fromHtml("<font color='green'>x</font> <font color='#EA8240'>-</font> <font color='blue'>14</font> <font color='#EA8240'>=</font> <font color='blue'>8</font>"));
                    paragrafo9_equacoes.setText(Html.fromHtml("<font color='green'>x</font> <font color='#EA8240'>=</font> <font color='blue'>8</font> <font color='#EA8240'>+</font> <font color='blue'>14</font>"));
                    paragrafo10_equacoes.setText(Html.fromHtml("<font color='green'>x</font> <font color='#EA8240'>=</font> <font color='blue'>22</font>"));
                    paragrafo11_equacoes.setText(Html.fromHtml("Somando <font color='blue'>14</font> e <font color='blue'>8</font>, teremos <font color='blue'>22</font> como resultado<font color='#EA8240'>.</font>"));
                    fonte_equacoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Brasil Escola<font color='#EA8240'>.</font>"));
                }
                if (sw_modo_discalculia.isChecked() == false) {
                    titulo1_equacoes.setText(Html.fromHtml("Igualdade"));
                    titulo2_equacoes.setText(Html.fromHtml("Exemplo"));
                    paragrafo1_equacoes.setText(Html.fromHtml("Toda expressão algébrica que possuir uma igualdade em sua composição será chamada de equação. Observe alguns exemplos:"));
                    paragrafo2_equacoes.setText(Html.fromHtml("1) x + 2 = 7"));
                    paragrafo3_equacoes.setText(Html.fromHtml("2) 12x² + 16y + 4ab = 7"));
                    paragrafo4_equacoes.setText(Html.fromHtml("3) 1:x = 3"));
                    paragrafo5_equacoes.setText(Html.fromHtml("A igualdade é o que permite encontrar os resultados de uma equação. É a igualdade que relaciona uma operação matemática aplicada em alguns números com o seu resultado. Portanto, a igualdade é peça fundamental ao procurar os resultados de uma equação."));
                    paragrafo6_equacoes.setText(Html.fromHtml("Dada a equação x – 14 = 8, qual é o valor de x?"));
                    paragrafo7_equacoes.setText(Html.fromHtml("Sabemos que x é um número que, subtraído por 14, tem 8 como resultado. Observe que é possível pensar em um resultado “de cabeça” ou pensar em uma estratégia para resolver essa equação. A estratégia pode ser obtida da seguinte maneira: Se x é um número que, subtraído de 14, resulta em 8, então, para encontrar x, basta somar 14 com 8. Desse modo, podemos escrever a seguinte linha de raciocínio:"));
                    paragrafo8_equacoes.setText(Html.fromHtml("x – 14 = 8"));
                    paragrafo9_equacoes.setText(Html.fromHtml("x = 8 + 14"));
                    paragrafo10_equacoes.setText(Html.fromHtml("x = 22"));
                    paragrafo11_equacoes.setText(Html.fromHtml("Somando 14 e 8, teremos 22 como resultado."));
                    fonte_equacoes.setText(Html.fromHtml("Fonte: Brasil Escola."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(igualdade_equacoes.this, selecao_equacoes.class);
                startActivity(intent);
            }
        });
    }
}