package br.com.marconi.discalcmath.Funcoes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class segundo_grau_funcoes extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segundo_grau_funcoes);

        TextView titulo1_funcoes = (TextView) findViewById(R.id.titulo1_funcoes);
        TextView titulo2_funcoes = (TextView) findViewById(R.id.titulo2_funcoes);
        TextView titulo3_funcoes = (TextView) findViewById(R.id.titulo3_funcoes);
        TextView titulo4_funcoes = (TextView) findViewById(R.id.titulo4_funcoes);
        TextView titulo5_funcoes = (TextView) findViewById(R.id.titulo5_funcoes);
        TextView titulo6_funcoes = (TextView) findViewById(R.id.titulo6_funcoes);
        TextView paragrafo1_funcoes = (TextView) findViewById(R.id.paragrafo1_funcoes);
        TextView paragrafo2_funcoes = (TextView) findViewById(R.id.paragrafo2_funcoes);
        TextView paragrafo3_funcoes = (TextView) findViewById(R.id.paragrafo3_funcoes);
        TextView paragrafo4_funcoes = (TextView) findViewById(R.id.paragrafo4_funcoes);
        TextView paragrafo5_funcoes = (TextView) findViewById(R.id.paragrafo5_funcoes);
        TextView paragrafo6_funcoes = (TextView) findViewById(R.id.paragrafo6_funcoes);
        TextView paragrafo7_funcoes = (TextView) findViewById(R.id.paragrafo7_funcoes);
        TextView paragrafo8_funcoes = (TextView) findViewById(R.id.paragrafo8_funcoes);
        TextView paragrafo9_funcoes = (TextView) findViewById(R.id.paragrafo9_funcoes);
        TextView paragrafo10_funcoes = (TextView) findViewById(R.id.paragrafo10_funcoes);
        TextView paragrafo11_funcoes = (TextView) findViewById(R.id.paragrafo11_funcoes);
        TextView paragrafo12_funcoes = (TextView) findViewById(R.id.paragrafo12_funcoes);
        TextView paragrafo13_funcoes = (TextView) findViewById(R.id.paragrafo13_funcoes);
        TextView paragrafo14_funcoes = (TextView) findViewById(R.id.paragrafo14_funcoes);
        TextView paragrafo15_funcoes = (TextView) findViewById(R.id.paragrafo15_funcoes);
        TextView paragrafo16_funcoes = (TextView) findViewById(R.id.paragrafo16_funcoes);
        TextView paragrafo17_funcoes = (TextView) findViewById(R.id.paragrafo17_funcoes);
        TextView paragrafo18_funcoes = (TextView) findViewById(R.id.paragrafo18_funcoes);
        TextView fonte_funcoes = (TextView) findViewById(R.id.fonte_funcoes);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_funcoes.setText(Html.fromHtml("<font color='red'>Função de Segundo Grau</font>"));
                    titulo2_funcoes.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    titulo3_funcoes.setText(Html.fromHtml("<font color='red'>Raízes da Função</font>"));
                    titulo4_funcoes.setText(Html.fromHtml("<font color='red'>Como resolver?</font>"));
                    titulo5_funcoes.setText(Html.fromHtml("<font color='red'>Condições do Delta</font>"));
                    titulo6_funcoes.setText(Html.fromHtml("<font color='red'>Gráfico</font>"));
                    paragrafo1_funcoes.setText(Html.fromHtml("A <font color='green'>função quadrática</font><font color='#EA8240'>,</font> também chamada de <font color='green'>função polinomial</font> de <font color='blue'>2</font><font color='#EA8240'>º</font> grau<font color='#EA8240'>,</font> é uma função representada pela seguinte expressão<font color='#EA8240'>:</font>"));
                    paragrafo2_funcoes.setText(Html.fromHtml("<font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='green'>ax</font><font color='blue'>²</font> <font color='#EA8240'>+</font> <font color='green'>bx</font> <font color='#EA8240'>+</font> <font color='green'>c</font><font color='#EA8240'>,</font> onde <font color='green'>a</font><font color='#EA8240'>,</font> <font color='green'>b</font> e <font color='green'>c</font> são números reais e <font color='green'>a</font> <font color='#EA8240'>≠</font> <font color='blue'>0</font><font color='#EA8240'>.</font>"));
                    paragrafo3_funcoes.setText(Html.fromHtml("<font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='blue'>2</font><font color='green'>x</font><font color='blue'>²</font> <font color='#EA8240'>+</font> <font color='blue'>3</font><font color='green'>x</font> <font color='#EA8240'>+</font> <font color='blue'>5</font><font color='#EA8240'>,</font> sendo<font color='#EA8240'>:</font>"));
                    paragrafo4_funcoes.setText(Html.fromHtml("<font color='green'>a</font> <font color='#EA8240'>=</font> <font color='blue'>2</font>"));
                    paragrafo5_funcoes.setText(Html.fromHtml("<font color='green'>b</font> <font color='#EA8240'>=</font> <font color='blue'>3</font>"));
                    paragrafo6_funcoes.setText(Html.fromHtml("<font color='green'>c</font> <font color='#EA8240'>=</font> <font color='blue'>5</font>"));
                    paragrafo7_funcoes.setText(Html.fromHtml("Nesse caso<font color='#EA8240'>,</font> o <font color='green'>polinômio</font> da função quadrática é de grau <font color='blue'>2</font><font color='#EA8240'>,</font> pois é o maior <font color='green'>expoente</font> da <font color='green'>variável</font><font color='#EA8240'>.</font>"));
                    paragrafo8_funcoes.setText(Html.fromHtml("As <font color='green'>raízes</font> ou <font color='green'>zeros</font> da função do segundo grau representam aos valores de <font color='green'>x</font> tais que <font color='green'>f</font><font color='#EA8240'>(</font><font color='green'>x</font><font color='#EA8240'>)</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>.</font> As raízes da função são determinadas pela resolução da <font color='green'>equação de segundo grau</font><font color='#EA8240'>.</font>"));
                    paragrafo9_funcoes.setText(Html.fromHtml("Para resolver a equação do <font color='blue'>2</font><font color='#EA8240'>º</font> grau podemos utilizar vários métodos<font color='#EA8240'>,</font> sendo um dos mais utilizados é aplicando a <font color='green'>Fórmula de Bhaskara</font><font color='#EA8240'>,</font> ou seja<font color='#EA8240'>:</font>"));
                    paragrafo10_funcoes.setText(Html.fromHtml("<font color='green'>Delta</font> <font color='#EA8240'>=</font> <font color='green'>b</font><font color='blue'>²</font> <font color='#EA8240'>-</font> <font color='blue'>4</font><font color='#EA8240'>.</font><font color='green'>a</font><font color='#EA8240'>.</font><font color='green'>c</font>"));
                    paragrafo11_funcoes.setText(Html.fromHtml("<font color='green'>x</font> <font color='#EA8240'>=</font> <font color='#EA8240'>(</font><font color='#EA8240'>-</font><font color='green'>b</font> <font color='#EA8240'>+</font><font color='#EA8240'>-</font> <font color='#EA8240'>√</font><font color='green'>Delta</font><font color='#EA8240'>)</font><font color='#EA8240'>/</font><font color='blue'>2</font><font color='#EA8240'>.</font><font color='green'>a</font>"));
                    paragrafo12_funcoes.setText(Html.fromHtml("<font color='blue'>1</font><font color='#EA8240'>ª</font> <font color='green'>Passo</font><font color='#EA8240'>:</font> Identificar os coeficientes <font color='green'>a</font><font color='#EA8240'>,</font> <font color='green'>b</font> e <font color='green'>c</font><font color='#EA8240'>.</font>"));
                    paragrafo13_funcoes.setText(Html.fromHtml("<font color='blue'>2</font><font color='#EA8240'>ª</font> <font color='green'>Passo</font><font color='#EA8240'>:</font> Calcular o <font color='green'>delta</font><font color='#EA8240'>.</font>"));
                    paragrafo14_funcoes.setText(Html.fromHtml("<font color='blue'>3</font><font color='#EA8240'>ª</font> <font color='green'>Passo</font><font color='#EA8240'>:</font> Calcular as <font color='green'>raízes</font><font color='#EA8240'>.</font>"));
                    paragrafo15_funcoes.setText(Html.fromHtml("Se <font color='#EA8240'>Δ</font> <font color='#EA8240'>></font> <font color='blue'>0</font><font color='#EA8240'>,</font> a função terá duas <font color='green'>raízes reais</font> e <font color='green'>distintas</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='blue'>1</font> <font color='#EA8240'>≠</font> <font color='green'>x</font><font color='blue'>2</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo16_funcoes.setText(Html.fromHtml("Se <font color='#EA8240'>Δ</font> <font color='green'>menor que</font> <font color='blue'>0</font><font color='#EA8240'>,</font> a função não terá uma <font color='green'>raiz real</font><font color='#EA8240'>.</font>"));
                    paragrafo17_funcoes.setText(Html.fromHtml("Se <font color='#EA8240'>Δ</font> <font color='#EA8240'>=</font> <font color='blue'>0</font><font color='#EA8240'>,</font> a função terá duas <font color='green'>raízes reais</font> e <font color='green'>iguais</font> <font color='#EA8240'>(</font><font color='green'>x</font><font color='blue'>1</font> <font color='#EA8240'>=</font> <font color='green'>x</font><font color='blue'>2</font><font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo18_funcoes.setText(Html.fromHtml("O gráfico das funções do <font color='blue'>2</font><font color='#EA8240'>º</font> grau são <font color='green'>curvas</font> que recebem o nome de <font color='green'>parábolas</font><font color='#EA8240'>.</font> Diferente das funções do <font color='blue'>1</font><font color='#EA8240'>º</font> grau<font color='#EA8240'>,</font> onde conhecendo dois pontos é possível traçar o gráfico<font color='#EA8240'>,</font> nas funções quadráticas são necessários conhecer vários pontos<font color='#EA8240'>.</font>"));
                    fonte_funcoes.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_funcoes.setText(Html.fromHtml("Função de Segundo Grau"));
                    titulo2_funcoes.setText(Html.fromHtml("Exemplo"));
                    titulo3_funcoes.setText(Html.fromHtml("Raízes da Função"));
                    titulo4_funcoes.setText(Html.fromHtml("Como resolver?"));
                    titulo5_funcoes.setText(Html.fromHtml("Condições do Delta"));
                    titulo6_funcoes.setText(Html.fromHtml("Gráfico"));
                    paragrafo1_funcoes.setText(Html.fromHtml("A função quadrática, também chamada de função polinomial de 2º grau, é uma função representada pela seguinte expressão:"));
                    paragrafo2_funcoes.setText(Html.fromHtml("f(x) = ax² + bx + c, onde a, b e c são números reais e a ≠ 0."));
                    paragrafo3_funcoes.setText(Html.fromHtml("f(x) = 2x2 + 3x + 5, sendo:"));
                    paragrafo4_funcoes.setText(Html.fromHtml("a = 2"));
                    paragrafo5_funcoes.setText(Html.fromHtml("b = 3"));
                    paragrafo6_funcoes.setText(Html.fromHtml("c = 5"));
                    paragrafo7_funcoes.setText(Html.fromHtml("Nesse caso, o polinômio da função quadrática é de grau 2, pois é o maior expoente da variável."));
                    paragrafo8_funcoes.setText(Html.fromHtml("As raízes ou zeros da função do segundo grau representam aos valores de x tais que f(x) = 0. As raízes da função são determinadas pela resolução da equação de segundo grau."));
                    paragrafo9_funcoes.setText(Html.fromHtml("Para resolver a equação do 2º grau podemos utilizar vários métodos, sendo um dos mais utilizados é aplicando a Fórmula de Bhaskara, ou seja:"));
                    paragrafo10_funcoes.setText(Html.fromHtml("Delta = b² - 4.a.c"));
                    paragrafo11_funcoes.setText(Html.fromHtml("x = (-b +- √Delta)/2.a"));
                    paragrafo12_funcoes.setText(Html.fromHtml("1º Passo: Identificar os coeficientes a, b e c."));
                    paragrafo13_funcoes.setText(Html.fromHtml("2º Passo: Calcular o delta."));
                    paragrafo14_funcoes.setText(Html.fromHtml("3º Passo: Calcular as raízes."));
                    paragrafo15_funcoes.setText(Html.fromHtml("Se Δ > 0, a função terá duas raízes reais e distintas (x1 ≠ x2)."));
                    paragrafo16_funcoes.setText(Html.fromHtml("Se Δ menor que 0 , a função não terá uma raiz real."));
                    paragrafo17_funcoes.setText(Html.fromHtml("Se Δ = 0, a função terá duas raízes reais e iguais (x1 = x2)."));
                    paragrafo18_funcoes.setText(Html.fromHtml("O gráfico das funções do 2º grau são curvas que recebem o nome de parábolas. Diferente das funções do 1º grau, onde conhecendo dois pontos é possível traçar o gráfico, nas funções quadráticas são necessários conhecer vários pontos."));
                    fonte_funcoes.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }
            }
        });

        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(segundo_grau_funcoes.this, selecao_funcoes.class);
                startActivity(intent);
            }
        });
    }
}