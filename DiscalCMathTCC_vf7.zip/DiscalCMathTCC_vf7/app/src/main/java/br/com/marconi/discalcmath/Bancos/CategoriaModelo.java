package br.com.marconi.discalcmath.Bancos;

public class CategoriaModelo {

    private String categoriaId, categoriaNome, categoriaImagem;


    public CategoriaModelo(String categoriaId, String categoriaNome, String categoriaImagem) {
        this.categoriaId = categoriaId;
        this.categoriaNome = categoriaNome;
        this.categoriaImagem = categoriaImagem;
    }

    public CategoriaModelo(){}

    public String getCategoriaId() {
        return categoriaId;
    }

    public void setCategoriaId(String categoriaId) {
        this.categoriaId = categoriaId;
    }



    public String getCategoriaNome() {
        return categoriaNome;
    }

    public void setCategoriaNome(String categoriaNome) {
        this.categoriaNome = categoriaNome;
    }

    public String getCategoriaImagem() {
        return categoriaImagem;
    }

    public void setCategoriaImagem(String categoriaImagem) {
        this.categoriaImagem = categoriaImagem;
    }
}
