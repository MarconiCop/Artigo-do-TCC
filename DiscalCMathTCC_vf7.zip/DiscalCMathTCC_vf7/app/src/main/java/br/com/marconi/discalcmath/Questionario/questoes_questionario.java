package br.com.marconi.discalcmath.Questionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

import br.com.marconi.discalcmath.R;

public class questoes_questionario extends AppCompatActivity {

    //DECLARAR CONTADOR

    int contador = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questoes_questionario);

        //DECLARAR CAMPOS DE PERGUNTA

        Button btConferir = (Button) findViewById(R.id.btConferir);
        CheckBox cb1 = (CheckBox) findViewById(R.id.cb1);
        CheckBox cb2 = (CheckBox) findViewById(R.id.cb2);
        CheckBox cb3 = (CheckBox) findViewById(R.id.cb3);
        CheckBox cb4 = (CheckBox) findViewById(R.id.cb4);
        CheckBox cb5 = (CheckBox) findViewById(R.id.cb5);
        CheckBox cb6 = (CheckBox) findViewById(R.id.cb6);
        Button btv = (Button) findViewById(R.id.btVoltar);

        btv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(questoes_questionario.this, QuestionarioPainel.class);
                startActivity(intent);
            }
        });

        btConferir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                if (contador == 0 || contador == 1 || contador == 2) {
                    Intent intent = new Intent(questoes_questionario.this, DiscalculiaBaixa.class);
                    startActivity(intent);
                }
                if (contador == 3 || contador == 4) {
                    Intent intent = new Intent(questoes_questionario.this, discalculia_media.class);
                    startActivity(intent);
                }
                if (contador == 5 || contador == 6) {
                    Intent intent = new Intent(questoes_questionario.this, discalculia_alta.class);
                    startActivity(intent);
                }
            }

        });
    }


    public void onClickCheckBox(View view) {
        boolean checked = ((CheckBox) view).isChecked();

        switch (view.getId()) {
            case R.id.cb1:
                if (checked) {
                    contador++;
                    break;
                }
            case R.id.cb2:
                if (checked) {
                    contador++;
                    break;
                }
            case R.id.cb3:
                if (checked) {
                    contador++;
                    break;
                }
            case R.id.cb4:
                if (checked) {
                    contador++;
                    break;
                }
            case R.id.cb5:
                if (checked) {
                    contador++;
                    break;
                }
            case R.id.cb6:
                if (checked) {
                    contador++;
                    break;
                }
        }

    }
}



