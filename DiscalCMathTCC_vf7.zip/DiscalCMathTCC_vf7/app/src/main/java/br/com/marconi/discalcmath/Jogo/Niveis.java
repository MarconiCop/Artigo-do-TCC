package br.com.marconi.discalcmath.Jogo;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.databinding.FragmentCarteiraBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;


public class Niveis extends Fragment {


    public Niveis() {

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    FragmentCarteiraBinding binding;
    FirebaseFirestore db;
    Usuario usuario;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding = FragmentCarteiraBinding.inflate(inflater, container, false);
        db = FirebaseFirestore.getInstance();

        db.collection("usuarios")
                .document(FirebaseAuth.getInstance().getUid())
                .get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
            @Override
            public void onSuccess(DocumentSnapshot documentSnapshot) {
                usuario = documentSnapshot.toObject(Usuario.class);


                binding.moedasAtuais.setText(String.valueOf(usuario.getMoedas()));




                if (usuario.getMoedas() >= 100) {
                    binding.ProgressoComum.setProgress(10);
                    binding.ProgressoComum.getProgress();
                }

                if (usuario.getMoedas() >= 200) {
                    binding.ProgressoComum.setProgress(20);
                    binding.ProgressoIncomum.setProgress(10);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoIncomum.getProgress();
                }
                if (usuario.getMoedas() >= 300) {
                    binding.ProgressoComum.setProgress(30);
                    binding.ProgressoRaro.setProgress(10);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoRaro.getProgress();
                }

                if (usuario.getMoedas() >= 400) {
                    binding.ProgressoComum.setProgress(40);
                    binding.ProgressoIncomum.setProgress(20);
                    binding.ProgressoEpico.setProgress(10);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoEpico.getProgress();
                }

                if (usuario.getMoedas() >= 500) {
                    binding.ProgressoComum.setProgress(50);
                    binding.ProgressoLendario.setProgress(10);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoLendario.getProgress();
                }

                if (usuario.getMoedas() >= 600) {
                    binding.ProgressoComum.setProgress(60);
                    binding.ProgressoIncomum.setProgress(30);
                    binding.ProgressoRaro.setProgress(20);
                    binding.ProgressoMitico.setProgress(10);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoRaro.getProgress();
                    binding.ProgressoMitico.getProgress();
                }
                if (usuario.getMoedas() >= 700) {
                    binding.ProgressoComum.setProgress(70);

                    binding.ProgressoComum.getProgress();
                }

                if (usuario.getMoedas() >= 800) {
                    binding.ProgressoComum.setProgress(80);
                    binding.ProgressoIncomum.setProgress(40);
                    binding.ProgressoEpico.setProgress(20);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoEpico.getProgress();
                }

                if (usuario.getMoedas() >= 900) {
                    binding.ProgressoComum.setProgress(90);
                    binding.ProgressoRaro.setProgress(30);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoRaro.getProgress();
                }

                if (usuario.getMoedas() >= 1000) {
                    binding.ProgressoComum.setProgress(100);
                    binding.ProgressoIncomum.setProgress(50);
                    binding.ProgressoLendario.setProgress(20);

                    binding.ProgressoComum.getProgress();
                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoLendario.getProgress();
                }

                if (usuario.getMoedas() >= 1200) {
                    binding.ProgressoIncomum.setProgress(60);
                    binding.ProgressoRaro.setProgress(40);
                    binding.ProgressoEpico.setProgress(30);
                    binding.ProgressoMitico.setProgress(20);

                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoRaro.getProgress();
                    binding.ProgressoEpico.getProgress();
                    binding.ProgressoMitico.getProgress();
                }

                if (usuario.getMoedas() >= 1400) {
                    binding.ProgressoIncomum.setProgress(70);

                    binding.ProgressoIncomum.getProgress();
                }

                if (usuario.getMoedas() >= 1500) {
                    binding.ProgressoRaro.setProgress(50);
                    binding.ProgressoLendario.setProgress(30);

                    binding.ProgressoRaro.getProgress();
                    binding.ProgressoLendario.getProgress();
                }

                if (usuario.getMoedas() >= 1600) {
                    binding.ProgressoIncomum.setProgress(80);
                    binding.ProgressoEpico.setProgress(40);

                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoEpico.getProgress();

                }
                if (usuario.getMoedas() >= 1800) {
                    binding.ProgressoIncomum.setProgress(90);
                    binding.ProgressoRaro.setProgress(60);
                    binding.ProgressoMitico.setProgress(30);

                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoRaro.getProgress();
                    binding.ProgressoMitico.getProgress();
                }

                if (usuario.getMoedas() >= 2000) {
                    binding.ProgressoIncomum.setProgress(100);
                    binding.ProgressoEpico.setProgress(50);
                    binding.ProgressoLendario.setProgress(40);

                    binding.ProgressoIncomum.getProgress();
                    binding.ProgressoEpico.getProgress();
                    binding.ProgressoLendario.getProgress();

                }

                if (usuario.getMoedas() >= 2100) {
                    binding.ProgressoRaro.setProgress(70);

                    binding.ProgressoRaro.getProgress();
                }

                if (usuario.getMoedas() >= 2400) {
                    binding.ProgressoRaro.setProgress(80);
                    binding.ProgressoEpico.setProgress(60);
                    binding.ProgressoMitico.setProgress(40);

                    binding.ProgressoRaro.getProgress();
                    binding.ProgressoEpico.getProgress();
                    binding.ProgressoMitico.getProgress();
                }

                if(usuario.getMoedas() >= 2500){
                    binding.ProgressoLendario.setProgress(50);

                    binding.ProgressoLendario.getProgress();
                }

                if (usuario.getMoedas() >= 2700) {
                    binding.ProgressoRaro.setProgress(90);

                    binding.ProgressoRaro.getProgress();
                }

                if (usuario.getMoedas() >= 2800) {
                    binding.ProgressoEpico.setProgress(70);

                    binding.ProgressoEpico.getProgress();

                }

                if (usuario.getMoedas() >= 3000) {
                    binding.ProgressoRaro.setProgress(100);
                    binding.ProgressoLendario.setProgress(60);
                    binding.ProgressoMitico.setProgress(50);


                    binding.ProgressoRaro.getProgress();
                    binding.ProgressoLendario.getProgress();
                    binding.ProgressoMitico.getProgress();
                }

                if (usuario.getMoedas() >= 3200) {
                    binding.ProgressoEpico.setProgress(80);

                    binding.ProgressoEpico.getProgress();

                }

                if(usuario.getMoedas() >= 3500){
                    binding.ProgressoLendario.setProgress(70);

                    binding.ProgressoLendario.getProgress();
                }

                if (usuario.getMoedas() >= 3600) {
                    binding.ProgressoEpico.setProgress(90);
                    binding.ProgressoMitico.setProgress(60);

                    binding.ProgressoEpico.getProgress();
                    binding.ProgressoMitico.getProgress();

                }

                if (usuario.getMoedas() >= 4000) {
                    binding.ProgressoEpico.setProgress(100);
                    binding.ProgressoLendario.setProgress(80);

                    binding.ProgressoEpico.getProgress();
                    binding.ProgressoLendario.getProgress();

                }

                if(usuario.getMoedas() >= 4200){
                    binding.ProgressoMitico.setProgress(70);

                    binding.ProgressoMitico.getProgress();
                }

                if(usuario.getMoedas() >= 4500){
                    binding.ProgressoLendario.setProgress(90);

                    binding.ProgressoLendario.getProgress();
                }

                if(usuario.getMoedas() >= 4800){
                    binding.ProgressoMitico.setProgress(80);

                    binding.ProgressoMitico.getProgress();
                }

                if(usuario.getMoedas() >= 5000){
                    binding.ProgressoLendario.setProgress(100);

                    binding.ProgressoLendario.getProgress();
                }

                if(usuario.getMoedas() >= 5400){
                    binding.ProgressoMitico.setProgress(90);

                    binding.ProgressoMitico.getProgress();
                }

                if(usuario.getMoedas() >= 6000){
                    binding.ProgressoMitico.setProgress(100);

                    binding.ProgressoMitico.getProgress();
                }

            }

        });
        return binding.getRoot();
    }
}