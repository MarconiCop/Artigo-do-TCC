package br.com.marconi.discalcmath.Estatistica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class moda_estatistica extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moda_estatistica);

        TextView titulo1_estatistica = (TextView) findViewById(R.id.titulo1_estatistica);
        TextView titulo2_estatistica = (TextView) findViewById(R.id.titulo2_estatistica);
        TextView titulo3_estatistica = (TextView) findViewById(R.id.titulo3_estatistica);
        TextView paragrafo1_estatistica = (TextView) findViewById(R.id.paragrafo1_estatistica);
        TextView paragrafo2_estatistica = (TextView) findViewById(R.id.paragrafo2_estatistica);
        TextView paragrafo3_estatistica = (TextView) findViewById(R.id.paragrafo3_estatistica);
        TextView paragrafo4_estatistica = (TextView) findViewById(R.id.paragrafo4_estatistica);
        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_estatistica);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_estatistica.setText(Html.fromHtml("<font color='red'>Moda</font>"));
                    paragrafo1_estatistica.setText(Html.fromHtml("A <font color='green'>Moda</font> <font color='#EA8240'>(</font><font color='green'>Mo</font><font color='#EA8240'>)</font> representa o valor mais frequente de um conjunto de dados<font color='#EA8240'>,</font> sendo assim<font color='#EA8240'>,</font> para defini-la basta observar a frequência com que os valores aparecem<font color='#EA8240'>.</font>"));

                    titulo2_estatistica.setText(Html.fromHtml("<font color='red'>Conjunto Bimodal</font>"));
                    paragrafo2_estatistica.setText(Html.fromHtml("Um conjunto de dados é chamado de <font color='green'>bimodal</font> quando apresenta duas modas<font color='#EA8240'>,</font> ou seja<font color='#EA8240'>,</font> dois valores são mais frequentes<font color='#EA8240'>.</font>"));

                    titulo3_estatistica.setText(Html.fromHtml("<font color='red'>Exemplo</font>"));
                    paragrafo3_estatistica.setText(Html.fromHtml("Em uma sapataria durante um dia foram vendidos os seguintes números de sapato<font color='#EA8240'>:</font> <font color='blue'>34</font><font color='#EA8240'>,</font> <font color='blue'>39</font><<font color='#EA8240'>,</font> <font color='blue'>36</font><<font color='#EA8240'>,</font> <font color='blue'>35</font><<font color='#EA8240'>,</font> <font color='blue'>37</font><<font color='#EA8240'>,</font> <font color='blue'>40</font><<font color='#EA8240'>,</font> <font color='blue'>36</font><<font color='#EA8240'>,</font> <font color='blue'>38</font><<font color='#EA8240'>,</font> <font color='blue'>36</font><<font color='#EA8240'>,</font> <font color='blue'>38</font> e <font color='blue'>41</font><<font color='#EA8240'>.</font>"));
                    paragrafo4_estatistica.setText(Html.fromHtml("Observando os números vendidos notamos que o número <font color='blue'>36</font> foi o que apresentou maior frequência <font color='#EA8240'>(</font><font color='blue'>3</font> pares<font color='#EA8240'>)</font><font color='#EA8240'>,</font> portanto<font color='#EA8240'>,</font> a moda é igual a<font color='#EA8240'>:</font> <font color='green'>Mo</font> <font color='#EA8240'>=</font> <font color='blue'>36</font><font color='#EA8240'>.</font>"));

                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_estatistica.setText(Html.fromHtml("Moda"));
                    paragrafo1_estatistica.setText(Html.fromHtml("A Moda (Mo) representa o valor mais frequente de um conjunto de dados, sendo assim, para defini-la basta observar a frequência com que os valores aparecem."));

                    titulo2_estatistica.setText(Html.fromHtml("Conjunto Bimodal"));
                    paragrafo2_estatistica.setText(Html.fromHtml("Um conjunto de dados é chamado de bimodal quando apresenta duas modas, ou seja, dois valores são mais frequentes."));

                    titulo3_estatistica.setText(Html.fromHtml("Exemplo"));
                    paragrafo3_estatistica.setText(Html.fromHtml("Em uma sapataria durante um dia foram vendidos os seguintes números de sapato: 34, 39, 36, 35, 37, 40, 36, 38, 36, 38 e 41."));
                    paragrafo4_estatistica.setText(Html.fromHtml("Observando os números vendidos notamos que o número 36 foi o que apresentou maior frequência (3 pares), portanto, a moda é igual a: Mo = 36."));

                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }





            }
        });








        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(moda_estatistica.this, selecao_estatistica.class);
                startActivity(intent);
            }
        });
    }

}
