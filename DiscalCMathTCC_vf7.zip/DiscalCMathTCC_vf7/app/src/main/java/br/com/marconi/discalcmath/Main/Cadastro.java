package br.com.marconi.discalcmath.Main;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import br.com.marconi.discalcmath.R;
import br.com.marconi.discalcmath.Bancos.Usuario;
import br.com.marconi.discalcmath.databinding.ActivityCadastroBinding;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class Cadastro extends AppCompatActivity {

    ActivityCadastroBinding binding;

    //AUTENTICAÇÃO
    FirebaseAuth autenticar;
    //CONEXÃO COM O BANCO DE DADOS
    FirebaseFirestore db;

    ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCadastroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //INSTANCIAR A AUTENTICAÇÃO
        autenticar = FirebaseAuth.getInstance();
        //INSTANCIAR CONEXÃO COM O BANCO DE DADOS
        db = FirebaseFirestore.getInstance();

        dialog = new ProgressDialog(this);
        dialog.setMessage("Criando nova conta");

        Button btVoltar = (Button) findViewById(R.id.btVoltar);

        binding.btConfirmar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //COISAS QUE O USUARIO VAI DIGITAR
                String email, senha, nome, numeroid;

                //PASSAR PARA STRING
                email = binding.txtEmailCadastro.getText().toString();
                senha = binding.txtSenha.getText().toString();
                nome = binding.txtNome.getText().toString();
                numeroid = binding.txtId.getText().toString();

                if (!email.equals("") && !senha.equals("") && !nome.equals("") && !numeroid.equals("")) {


                    if (senha.equals(numeroid)) {


                        //CRIANDO UM USUARIO COM AS INFORMAÇÕES PASSADAS
                        Usuario usuario = new Usuario(nome, email, senha, numeroid);


                        dialog.show();

                        //AUTENTICAÇÃO USANDO EMAIL E SENHA
                        autenticar.createUserWithEmailAndPassword(email, senha).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    //String recebe UID DO USUÁRIO
                                    String uid = task.getResult().getUser().getUid();
                                    //CHAMA O BANCO
                                    db
                                            //COLEÇÃO
                                            .collection("usuarios")
                                            //UID
                                            .document(uid)
                                            //ADICIONA O USUÁRIO
                                            .set(usuario).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                dialog.dismiss();

                                                Toast.makeText(Cadastro.this, "Sucesso ao criar conta!", Toast.LENGTH_SHORT).show();
                                                startActivity(new Intent(Cadastro.this, MainActivity.class));
                                                finish();
                                            } else {
                                                Toast.makeText(Cadastro.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });

                                } else {
                                    dialog.dismiss();
                                    Toast.makeText(Cadastro.this, task.getException().getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    } else {
                        Toast.makeText(Cadastro.this, "As senhas não conferem!", Toast.LENGTH_SHORT).show();
                    }

                } else {
                    Toast.makeText(Cadastro.this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
                }

            }

        });


        btVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Cadastro.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}