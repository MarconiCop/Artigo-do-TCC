package br.com.marconi.discalcmath.Fragmentos;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import br.com.marconi.discalcmath.Adaptadores.CategoriaAdapter;
import br.com.marconi.discalcmath.Bancos.CategoriaModelo;

import br.com.marconi.discalcmath.databinding.FragmentHomeBinding;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;


public class HomeFragment extends Fragment {


    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    FragmentHomeBinding binding;
    FirebaseFirestore db;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        binding  =FragmentHomeBinding.inflate(inflater,container,false);

        db = FirebaseFirestore.getInstance();

        final ArrayList<CategoriaModelo> categorias = new ArrayList<>();


        final CategoriaAdapter adapter = new CategoriaAdapter(getContext(), categorias);


        db.collection("categorias")
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        for(DocumentSnapshot snapshot : value.getDocuments()){
                            CategoriaModelo modelo = snapshot.toObject(CategoriaModelo.class);
                            modelo.setCategoriaId(snapshot.getId());
                            categorias.add(modelo);

                        }
                        adapter.notifyDataSetChanged();
                    }
                });

        binding.categoriaList.setLayoutManager(new GridLayoutManager(getContext(), 2));
        binding.categoriaList.setAdapter(adapter);

        return binding.getRoot();
    }
}
