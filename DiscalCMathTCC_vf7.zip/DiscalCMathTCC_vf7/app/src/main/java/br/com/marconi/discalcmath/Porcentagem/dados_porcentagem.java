package br.com.marconi.discalcmath.Porcentagem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class dados_porcentagem extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dados_porcentagem);

        TextView titulo1_porcentagem = (TextView) findViewById(R.id.titulo1_porcentagem);
        TextView paragrafo1_porcentagem = (TextView) findViewById(R.id.paragrafo1_porcentagem);
        TextView paragrafo2_porcentagem = (TextView) findViewById(R.id.paragrafo2_porcentagem);
        TextView paragrafo3_porcentagem = (TextView) findViewById(R.id.paragrafo3_porcentagem);

        TextView fonte_porcentagem = (TextView) findViewById(R.id.fonte_porcentagem);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);

        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_porcentagem.setText(Html.fromHtml("<font color='red'>Curiosidades</font>"));



                    paragrafo1_porcentagem.setText(Html.fromHtml("Os cálculos de porcentagem se tornam mais fáceis se você utilizar uma <font color='green'>calculadora simples</font> ou a <font color='green'>calculadora no celular</font><font color='#EA8240'>.</font> Basta inserir os valores e rapidamente obterá o resultado<font color='#EA8240'>.</font>"));
                    paragrafo2_porcentagem.setText(Html.fromHtml("Muitos documentos encontrados e registrados apresentam uma forma curiosa de expressar porcentagens<font color='#EA8240'>.</font> Os romanos utilizavam os algarismos do seu sistema de numeração seguido de <font color='green'>siglas</font> como<font color='#EA8240'>,</font> <font color='#EA8240'>'</font><font color='green'>p cento</font><font color='#EA8240'>'</font> e <font color='#EA8240'>'</font><font color='green'>p c</font><font color='#EA8240'>'</font><font color='#EA8240'>.</font> Por exemplo<font color='#EA8240'>,</font> a porcentagem de <font color='blue'>10</font><font color='#EA8240'>%</font> era escrita da seguinte forma<font color='#EA8240'>:</font> <font color='#EA8240'>'</font><font color='blue'>X</font> <font color='green'>p cento</font><font color='#EA8240'>'</font> ou <font color='#EA8240'>'</font><font color='blue'>X</font> <font color='green'>p c</font><font color='#EA8240'>'</font><font color='#EA8240'>.</font>"));
                    paragrafo3_porcentagem.setText(Html.fromHtml("A crescente utilização da porcentagem no comércio e as suas inúmeras formas de escrita representacional originaram o símbolo que conhecemos hoje<font color='#EA8240'>,</font> <font color='#EA8240'>%</font><font color='#EA8240'>.</font> Atualmente<font color='#EA8240'>,</font> a porcentagem é estritamente importante para a <font color='green'>Matemática financeira</font><font color='#EA8240'>,</font> dando suporte às inúmeras movimentações financeiras<font color='#EA8240'>,</font> na representação do mercado de ações envolvendo as operações de compra e venda<font color='#EA8240'>,</font> na construção de gráficos comparativos<font color='#EA8240'>,</font> qualitativos e quantitativos<font color='#EA8240'>,</font> na constituição de alíquotas de diversos impostos entre inúmeras outras situações<font color='#EA8240'>.</font>"));


                    fonte_porcentagem.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>,</font> Brasil Escola<font color='#EA8240'>.</font>"));
                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_porcentagem.setText(Html.fromHtml("Curiosidades"));
                    paragrafo1_porcentagem.setText(Html.fromHtml("Os cálculos de porcentagem se tornam mais fáceis se você utilizar uma calculadora simples ou a calculadora no celular. Basta inserir os valores e rapidamente obterá o resultado."));
                    paragrafo2_porcentagem.setText(Html.fromHtml("Muitos documentos encontrados e registrados apresentam uma forma curiosa de expressar porcentagens. Os romanos utilizavam os algarismos do seu sistema de numeração seguido de siglas como, 'p cento' e 'p c'. Por exemplo, a porcentagem de 10% era escrita da seguinte forma: 'X p cento” ou 'X p c'."));
                    paragrafo3_porcentagem.setText(Html.fromHtml("A crescente utilização da porcentagem no comércio e as suas inúmeras formas de escrita representacional originaram o símbolo que conhecemos hoje, %. Atualmente, a porcentagem é estritamente importante para a Matemática financeira, dando suporte às inúmeras movimentações financeiras, na representação do mercado de ações envolvendo as operações de compra e venda, na construção de gráficos comparativos, qualitativos e quantitativos, na constituição de alíquotas de diversos impostos entre inúmeras outras situações."));


                    fonte_porcentagem.setText(Html.fromHtml("Fonte: Toda Matéria, Brasil Escola."));
                }


            }
        });




        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(dados_porcentagem.this, selecao_porcentagem.class);
                startActivity(intent);
            }
        });
    }
    }
