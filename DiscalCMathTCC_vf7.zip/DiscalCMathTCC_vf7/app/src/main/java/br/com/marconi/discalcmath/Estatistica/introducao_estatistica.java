package br.com.marconi.discalcmath.Estatistica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;

import br.com.marconi.discalcmath.R;

public class introducao_estatistica extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_introducao_estatistica);

        TextView titulo1_estatistica = (TextView) findViewById(R.id.titulo1_estatistica);
        TextView titulo2_estatistica = (TextView) findViewById(R.id.titulo2_estatistica);
        TextView paragrafo1_estatistica = (TextView) findViewById(R.id.paragrafo1_estatistica);
        TextView paragrafo2_estatistica = (TextView) findViewById(R.id.paragrafo2_estatistica);
        TextView paragrafo3_estatistica = (TextView) findViewById(R.id.paragrafo3_estatistica);
        TextView paragrafo4_estatistica = (TextView) findViewById(R.id.paragrafo4_estatistica);
        TextView paragrafo5_estatistica = (TextView) findViewById(R.id.paragrafo5_estatistica);
        TextView paragrafo6_estatistica = (TextView) findViewById(R.id.paragrafo6_estatistica);
        TextView paragrafo7_estatistica = (TextView) findViewById(R.id.paragrafo7_estatistica);
        TextView paragrafo8_estatistica = (TextView) findViewById(R.id.paragrafo8_estatistica);
        TextView fonte_estatistica = (TextView) findViewById(R.id.fonte_estatistica);
        Switch sw_modo_discalculia = (Switch) findViewById(R.id.sw_modo_discalculia);
        Button bt_Voltar = (Button) findViewById(R.id.bt_Voltar);



        sw_modo_discalculia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sw_modo_discalculia.isChecked()==true) {
                    titulo1_estatistica.setText(Html.fromHtml("<font color='red'>Introdução</font>"));
                    titulo2_estatistica.setText(Html.fromHtml("<font color='red'>Fases da Estatística</font>"));
                    paragrafo1_estatistica.setText(Html.fromHtml("<font color='green'>Estatística</font> é uma ciência exata que estuda a coleta<font color='#EA8240'>,</font> a organização<font color='#EA8240'>,</font> a análise e registro de dados por amostras<font color='#EA8240'>.</font>  Utilizada desde a Antiguidade<font color='#EA8240'>,</font> quando se registravam os nascimentos e as mortes das pessoas<font color='#EA8240'>,</font> é um método de pesquisa fundamental para tomar decisões<font color='#EA8240'>.</font> Isso porque fundamenta suas conclusões nos estudos realizados<font color='#EA8240'>.</font>"));
                    paragrafo2_estatistica.setText(Html.fromHtml("<font color='blue'>1</font><font color='#EA8240'>)</font><font color='green'> Definição do problema</font><font color='#EA8240'>:</font> determinar como a recolha de dados pode solucionar um problema<font color='#EA8240'>.</font>"));
                    paragrafo3_estatistica.setText(Html.fromHtml("<font color='blue'>2</font><font color='#EA8240'>)</font><font color='green'> Planejamento</font><font color='#EA8240'>:</font> elaborar como fazer o levantamento dos dados<font color='#EA8240'>.</font>"));
                    paragrafo4_estatistica.setText(Html.fromHtml("<font color='blue'>3</font><font color='#EA8240'>)</font><font color='green'> Coleta de dados</font><font color='#EA8240'>:</font> reunir dados após o planeamento do trabalho pretendido<font color='#EA8240'>,</font> bem como definição da periodicidade da coleta <font color='#EA8240'>(</font>contínua<font color='#EA8240'>,</font> periódica<font color='#EA8240'>,</font> ocasional ou indireta<font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo5_estatistica.setText(Html.fromHtml("<font color='blue'>4</font><font color='#EA8240'>)</font><font color='green'> Correção dos dados coletados</font><font color='#EA8240'>:</font> conferir dados para afastar algum erro por parte da pessoa que os coletou<font color='#EA8240'>.</font>"));
                    paragrafo6_estatistica.setText(Html.fromHtml("<font color='blue'>5</font><font color='#EA8240'>)</font><font color='green'> Apuração dos dados</font><font color='#EA8240'>:</font> organização e contagem dos dados<font color='#EA8240'>.</font>"));
                    paragrafo7_estatistica.setText(Html.fromHtml("<font color='blue'>6</font><font color='#EA8240'>)</font><font color='green'> Apresentação dos dados</font><font color='#EA8240'>:</font> montagem de suportes que demonstrem o resultado da coleta dos dados <font color='#EA8240'>(</font>gráficos e tabelas<font color='#EA8240'>)</font><font color='#EA8240'>.</font>"));
                    paragrafo8_estatistica.setText(Html.fromHtml("<font color='blue'>7</font><font color='#EA8240'>)</font><font color='green'> Análise dos dados</font><font color='#EA8240'>:</font> exame detalhado e interpretação dos dados<font color='#EA8240'>.</font>"));
                    fonte_estatistica.setText(Html.fromHtml("Fonte<font color='#EA8240'>:</font> Toda Matéria<font color='#EA8240'>.</font>"));

                }
                if(sw_modo_discalculia.isChecked()==false) {
                    titulo1_estatistica.setText(Html.fromHtml("Introdução"));
                    titulo2_estatistica.setText(Html.fromHtml("Fases da Estatística"));
                    paragrafo1_estatistica.setText(Html.fromHtml("Estatística é uma ciência exata que estuda a coleta, a organização, a análise e registro de dados por amostras.  Utilizada desde a Antiguidade, quando se registravam os nascimentos e as mortes das pessoas, é um método de pesquisa fundamental para tomar decisões. Isso porque fundamenta suas conclusões nos estudos realizados."));
                    paragrafo2_estatistica.setText(Html.fromHtml("1) Definição do problema: determinar como a recolha de dados pode solucionar um problema."));
                    paragrafo3_estatistica.setText(Html.fromHtml("2) Planejamento: elaborar como fazer o levantamento dos dados."));
                    paragrafo4_estatistica.setText(Html.fromHtml("3) Coleta de dados: reunir dados após o planeamento do trabalho pretendido, bem como definição da periodicidade da coleta (contínua, periódica, ocasional ou indireta)."));
                    paragrafo5_estatistica.setText(Html.fromHtml("4) Correção dos dados coletados: conferir dados para afastar algum erro por parte da pessoa que os coletou."));
                    paragrafo6_estatistica.setText(Html.fromHtml("5) Apuração dos dados: organização e contagem dos dados."));
                    paragrafo7_estatistica.setText(Html.fromHtml("6) Apresentação dos dados: montagem de suportes que demonstrem o resultado da coleta dos dados (gráficos e tabelas)."));
                    paragrafo8_estatistica.setText(Html.fromHtml("7) Análise dos dados: exame detalhado e interpretação dos dados."));
                    fonte_estatistica.setText(Html.fromHtml("Fonte: Toda Matéria."));
                }





            }
        });


        bt_Voltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(introducao_estatistica.this, selecao_estatistica.class);
                startActivity(intent);
            }
        });


    }
}