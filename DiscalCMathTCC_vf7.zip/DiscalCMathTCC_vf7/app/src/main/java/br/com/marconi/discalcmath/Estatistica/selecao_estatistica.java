package br.com.marconi.discalcmath.Estatistica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import br.com.marconi.discalcmath.Painel.materias_painel;
import br.com.marconi.discalcmath.R;

public class selecao_estatistica extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selecao_estatistica);

        LinearLayout introducao_estatistica = (LinearLayout) findViewById(R.id.introducao_funcoes);
        LinearLayout media_estatistica = (LinearLayout) findViewById(R.id.media_estatistica);
        LinearLayout moda_estatistica = (LinearLayout) findViewById(R.id.moda_estatistica);
        LinearLayout mediana_estatistica = (LinearLayout) findViewById(R.id.mediana_estatistica);
        LinearLayout desviopadrao_estatistica = (LinearLayout) findViewById(R.id.desviopadrao_estatistica);
        LinearLayout avaliar_estatistica = (LinearLayout) findViewById(R.id.avaliar_estatistica);
        ImageView ImVoltar = (ImageView) findViewById(R.id.imVoltarEstatistica);

        ImVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_estatistica.this, materias_painel.class);
                startActivity(intent);
            }
        });

        introducao_estatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_estatistica.this, introducao_estatistica.class);
                startActivity(intent);
            }
        });


        media_estatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_estatistica.this, media_estatistica.class);
                startActivity(intent);
            }
        });

        moda_estatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_estatistica.this, moda_estatistica.class);
                startActivity(intent);
            }
        });

        mediana_estatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_estatistica.this, mediana_estatistica.class);
                startActivity(intent);
            }
        });

        desviopadrao_estatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_estatistica.this, desviopadrao_estatistica.class);
                startActivity(intent);
            }
        });

        avaliar_estatistica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(selecao_estatistica.this, avaliar_estatistica.class);
                startActivity(intent);
            }
        });


    }
}