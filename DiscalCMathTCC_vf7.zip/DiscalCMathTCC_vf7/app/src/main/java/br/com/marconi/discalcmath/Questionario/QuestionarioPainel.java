package br.com.marconi.discalcmath.Questionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import br.com.marconi.discalcmath.Painel.Painel;
import br.com.marconi.discalcmath.R;

public class QuestionarioPainel extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questionario_painel);

        Button btir = (Button) findViewById(R.id.btIniciar);
        Button btv = (Button) findViewById(R.id.btVoltar);

        btir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QuestionarioPainel.this, questoes_questionario.class);
                startActivity(intent);
            }
        });

        btv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(QuestionarioPainel.this, Painel.class);
                startActivity(intent);
            }
        });




    }
}